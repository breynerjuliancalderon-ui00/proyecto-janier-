﻿// Archivo: Program.cs
// Punto de entrada de GastroSENA: es lo primero que se ejecuta al presionar F5.
// Prepara el estilo visual de Windows y abre el formulario de inicio de sesión (FrmLogin).

// Trae lo básico de C# (aquí se usa para el atributo [STAThread])
using System;
// Trae la clase Application, que arranca y mantiene viva la aplicación de ventanas
using System.Windows.Forms;
// Trae los formularios del proyecto (carpeta Formularios), entre ellos FrmLogin
using GastroSena.Formularios;

// Espacio de nombres principal del proyecto: agrupa todas las clases de GastroSena
namespace GastroSena
{
    /// <summary>
    /// Clase de arranque del programa. Es "static" porque no se crean objetos de ella:
    /// solo contiene el método Main, que Windows llama al abrir GastroSena.exe.
    /// </summary>
    internal static class Program
    {
        /// <summary>
        /// Punto de entrada principal de la aplicación. Se ejecuta una sola vez al iniciar.
        /// Activa los estilos visuales y muestra el login; el programa sigue abierto
        /// mientras ese formulario principal exista.
        /// </summary>
        // [STAThread] es obligatorio en Windows Forms: hace que las ventanas trabajen en un solo hilo
        [STAThread]
        // Main es el método que se ejecuta primero; "static void" = no necesita objeto y no devuelve nada
        static void Main()
        {
            // Usa el estilo visual moderno de Windows para botones, cajas de texto, etc.
            Application.EnableVisualStyles();
            // Dibuja el texto de los controles con el motor nuevo (GDI), que se ve más nítido
            Application.SetCompatibleTextRenderingDefault(false);
            // Abre el formulario de inicio de sesión; la aplicación termina cuando este formulario se cierra
            Application.Run(new FrmLogin());
        }
    }
}
