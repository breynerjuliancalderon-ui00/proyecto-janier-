﻿// Archivo: Datos/UsuariosDemo.cs
// Usuarios de demostración de GastroSENA (uno por perfil, todos con la contraseña demo123).
// Como el proyecto es solo frontend (sin base de datos), los usuarios viven aquí, en una lista en memoria.

// Trae List<T>, la lista que guarda los usuarios
using System.Collections.Generic;
// Trae las clases Usuario y Rol
using GastroSena.Modelos;

// Espacio de nombres de los datos (carpeta Datos)
namespace GastroSena.Datos
{
    /// <summary>
    /// Guarda los usuarios de demostración y permite buscarlos.
    /// Es "static": no se crean objetos de ella, se usa directo (UsuariosDemo.BuscarPorRol(...)).
    /// </summary>
    public static class UsuariosDemo
    {
        // Lista con los cuatro usuarios de demostración; "readonly" = la lista no se puede reemplazar por otra
        private static readonly List<Usuario> usuarios = new List<Usuario>
        {
            // Aprendiz de demostración: documento 1005678901
            new Usuario { Documento = "1005678901", Contrasena = "demo123", NombreCompleto = "Carlos Ruiz", Rol = Rol.Aprendiz },
            // Instructora de demostración: documento 1098765432
            new Usuario { Documento = "1098765432", Contrasena = "demo123", NombreCompleto = "María Fernanda Gómez", Rol = Rol.Instructor },
            // Encargado de la cafetería de demostración: documento 1012345678
            new Usuario { Documento = "1012345678", Contrasena = "demo123", NombreCompleto = "Encargado General Comedor", Rol = Rol.Encargado },
            // Invitado de demostración: documento 1234567890
            new Usuario { Documento = "1234567890", Contrasena = "demo123", NombreCompleto = "Invitado Particular", Rol = Rol.Invitado }
        };

        /// <summary>
        /// Busca el usuario de demostración de un perfil. El login lo usa para llenar solo
        /// las cajas Usuario y Contraseña cuando se elige un perfil.
        /// </summary>
        /// <param name="rol">El perfil elegido (Aprendiz, Instructor, Encargado o Invitado).</param>
        /// <returns>El usuario de ese perfil, o null si no hay ninguno.</returns>
        public static Usuario BuscarPorRol(Rol rol)
        {
            // Recorre la lista de usuarios uno por uno
            foreach (Usuario usuario in usuarios)
            {
                // Si el perfil de este usuario es el que se busca...
                if (usuario.Rol == rol)
                {
                    // ...lo devuelve y el método termina aquí
                    return usuario;
                }
            }
            // Si terminó el recorrido sin encontrarlo, devuelve null (nada)
            return null;
        }

        /// <summary>
        /// Busca un usuario de demostración que tenga exactamente ese documento, esa contraseña
        /// y ese perfil. El login lo usa al presionar "Iniciar sesión".
        /// </summary>
        /// <param name="documento">Lo que se escribió en la caja Usuario.</param>
        /// <param name="contrasena">Lo que se escribió en la caja Contraseña.</param>
        /// <param name="rol">El perfil que se eligió en el login.</param>
        /// <returns>El usuario encontrado, o null si los datos no coinciden.</returns>
        public static Usuario BuscarPorCredenciales(string documento, string contrasena, Rol rol)
        {
            // Recorre la lista de usuarios uno por uno
            foreach (Usuario usuario in usuarios)
            {
                // Revisa que coincidan el documento, la contraseña y el perfil al mismo tiempo (&& = "y")
                if (usuario.Documento == documento && usuario.Contrasena == contrasena && usuario.Rol == rol)
                {
                    // Coinciden los tres datos: devuelve ese usuario
                    return usuario;
                }
            }
            // Ningún usuario coincide: devuelve null para indicar que los datos están mal
            return null;
        }
    }
}
