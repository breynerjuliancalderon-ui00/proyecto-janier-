﻿// Archivo: Datos/DatosDemoAprendiz.cs
// Datos de demostración del aprendiz Carlos Ruiz (documento 1005678901, ficha 2847251, programa ADSO):
// el menú de hoy, sus reservas de los 4 días anteriores y 2 sugerencias (una pendiente y una atendida).
// Se usan solo la primera vez, cuando todavía no existe el archivo datos.xml (ver AlmacenDatos.cs).

// Trae DateTime (fechas)
using System;
// Trae las clases DatosAprendiz, Usuario, MenuDia, Reserva, Sugerencia y sus estados
using GastroSena.Modelos;

// Espacio de nombres de los datos (carpeta Datos)
namespace GastroSena.Datos
{
    /// <summary>
    /// Arma los datos de demostración del aprendiz. Es "static": se usa directo,
    /// por ejemplo DatosDemoAprendiz.Crear(), sin crear objetos de ella.
    /// </summary>
    public static class DatosDemoAprendiz
    {
        /// <summary>
        /// Crea todos los datos de demostración juntos: perfil, menú de hoy, reservas y sugerencias.
        /// Las fechas se calculan desde hoy, así los datos siempre se ven recientes.
        /// </summary>
        /// <returns>Un objeto DatosAprendiz listo para guardar en datos.xml.</returns>
        public static DatosAprendiz Crear()
        {
            // Crea el objeto vacío que va a guardar todo
            DatosAprendiz datos = new DatosAprendiz();
            // Le pone el perfil de Carlos Ruiz
            datos.Perfil = CrearPerfil();
            // Le pone el menú de hoy
            datos.MenuDelDia = CrearMenuDeHoy();
            // Guarda la fecha de hoy (sin hora) para calcular los días anteriores
            DateTime hoy = DateTime.Today;
            // Ayer: almuerzo todavía pendiente de pago (reservado a las 9:00 a. m.)
            datos.Reservas.Add(CrearReserva(hoy.AddDays(-1).AddHours(9), 5000, EstadoPago.Pendiente));
            // Antier: almuerzo ya pagado
            datos.Reservas.Add(CrearReserva(hoy.AddDays(-2).AddHours(9), 5000, EstadoPago.Pagado));
            // Hace 3 días: almuerzo gratis (vale $0)
            datos.Reservas.Add(CrearReserva(hoy.AddDays(-3).AddHours(9), 0, EstadoPago.Gratis));
            // Hace 4 días: almuerzo ya pagado
            datos.Reservas.Add(CrearReserva(hoy.AddDays(-4).AddHours(9), 5000, EstadoPago.Pagado));
            // Sugerencia de hace 6 días que el comedor ya respondió (atendida)
            datos.Sugerencias.Add(new Sugerencia
            {
                // Enviada hace 6 días a las 10:00 a. m.
                Fecha = hoy.AddDays(-6).AddHours(10),
                // Tema de la sugerencia
                Asunto = "Más opciones vegetarianas",
                // Texto que escribió el aprendiz
                Mensaje = "Sería bueno tener una opción vegetariana por lo menos dos veces por semana.",
                // Ya fue atendida
                Estado = EstadoSugerencia.Atendida,
                // Lo que contestó el comedor
                Respuesta = "¡Gracias por tu idea! Desde la próxima semana habrá menú vegetariano los martes y jueves."
            });
            // Sugerencia de hace 2 días que todavía no tiene respuesta (pendiente)
            datos.Sugerencias.Add(new Sugerencia
            {
                // Enviada hace 2 días a las 12:30 p. m.
                Fecha = hoy.AddDays(-2).AddHours(12).AddMinutes(30),
                // Tema de la sugerencia
                Asunto = "Jugo natural sin azúcar",
                // Texto que escribió el aprendiz
                Mensaje = "¿Podrían ofrecer el jugo natural sin azúcar para quienes lo preferimos así?",
                // Todavía nadie la ha respondido
                Estado = EstadoSugerencia.Pendiente,
                // Sin respuesta todavía
                Respuesta = ""
            });
            // Devuelve los datos completos
            return datos;
        }

        /// <summary>
        /// Crea el perfil de demostración del aprendiz Carlos Ruiz.
        /// </summary>
        /// <returns>Un Usuario con los datos que muestra la sección Perfil.</returns>
        public static Usuario CrearPerfil()
        {
            // Crea y devuelve el usuario con todos sus datos (la contraseña no se guarda en el archivo)
            return new Usuario
            {
                // Documento de identidad (es el mismo usuario del login)
                Documento = "1005678901",
                // Nombre completo
                NombreCompleto = "Carlos Ruiz",
                // Perfil Aprendiz
                Rol = Rol.Aprendiz,
                // Correo institucional de aprendiz del SENA
                Correo = "carlos.ruiz@soy.sena.edu.co",
                // Número de ficha
                Ficha = "2847251",
                // Programa de formación
                Programa = "Análisis y Desarrollo de Software (ADSO)"
            };
        }

        /// <summary>
        /// Crea el menú de demostración para el día de hoy, con todos sus cupos.
        /// AlmacenDatos lo usa también cada día nuevo, para cambiar el menú guardado de un día anterior.
        /// </summary>
        /// <returns>El menú del día de hoy.</returns>
        public static MenuDia CrearMenuDeHoy()
        {
            // Crea y devuelve el menú con sus datos
            return new MenuDia
            {
                // Fecha de hoy (sin hora)
                Fecha = DateTime.Today,
                // Nombre del menú
                Nombre = "Menú Ejecutivo SENA",
                // Qué trae el almuerzo
                Descripcion = "Almuerzo completo: sopa, bandeja con proteína, arroz, ensalada, jugo natural y postre.",
                // Precio para aprendices: $5.000
                Precio = 5000,
                // Almuerzos que se pueden reservar hoy
                CuposDisponibles = 150
            };
        }

        /// <summary>
        /// Crea una reserva del "Menú Ejecutivo SENA" con la fecha, el precio y el estado de pago indicados.
        /// Sirve para no repetir el mismo código en cada reserva de demostración.
        /// </summary>
        /// <param name="fecha">Fecha y hora de la reserva.</param>
        /// <param name="precio">Lo que vale (0 si es gratis).</param>
        /// <param name="estadoPago">Pagado, Pendiente o Gratis.</param>
        /// <returns>La reserva creada.</returns>
        private static Reserva CrearReserva(DateTime fecha, decimal precio, EstadoPago estadoPago)
        {
            // Crea y devuelve la reserva con los datos recibidos
            return new Reserva
            {
                // Cuándo se reservó
                Fecha = fecha,
                // Qué menú se reservó
                NombreMenu = "Menú Ejecutivo SENA",
                // Cuánto vale
                Precio = precio,
                // Si ya se pagó, está pendiente o es gratis
                EstadoPago = estadoPago
            };
        }
    }
}
