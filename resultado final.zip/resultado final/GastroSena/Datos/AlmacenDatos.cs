﻿// Archivo: Datos/AlmacenDatos.cs
// Guarda y lee los datos del aprendiz (perfil, menú de hoy, reservas y sugerencias) en un archivo XML:
// %LOCALAPPDATA%\GastroSena\datos.xml (por ejemplo C:\Users\<usuario>\AppData\Local\GastroSena\datos.xml).
// Así los cambios no se pierden al cerrar la aplicación. Si el archivo no existe, se crea con los
// datos de demostración de DatosDemoAprendiz.cs. Usa XmlSerializer, que ya viene en .NET Framework.

// Trae Environment (para encontrar la carpeta %LOCALAPPDATA%) y DateTime
using System;
// Trae List<T>
using System.Collections.Generic;
// Trae Path, Directory, File y StreamWriter (carpetas y archivos)
using System.IO;
// Trae OrderByDescending y ToList (para ordenar listas)
using System.Linq;
// Trae Encoding (para escribir el archivo en UTF-8, con tildes y eñes)
using System.Text;
// Trae MessageBox (para avisar si no se pudo guardar)
using System.Windows.Forms;
// Trae XmlSerializer (convierte objetos en XML y XML en objetos)
using System.Xml.Serialization;
// Trae las clases DatosAprendiz, Usuario, MenuDia, Reserva y Sugerencia
using GastroSena.Modelos;

// Espacio de nombres de los datos (carpeta Datos)
namespace GastroSena.Datos
{
    /// <summary>
    /// "Almacén" de los datos del aprendiz. Es "static": hay un solo almacén para toda la aplicación
    /// y se usa directo (AlmacenDatos.ReservarAlmuerzo(), AlmacenDatos.ObtenerReservas()...).
    /// Lee el archivo la primera vez que se necesita y lo vuelve a escribir después de cada cambio.
    /// </summary>
    public static class AlmacenDatos
    {
        // Carpeta donde se guarda el archivo: %LOCALAPPDATA%\GastroSena
        private static readonly string carpeta = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "GastroSena");

        /// <summary>
        /// Ruta completa del archivo de datos: %LOCALAPPDATA%\GastroSena\datos.xml.
        /// </summary>
        // "public" para poder mostrarla si hace falta; "readonly" = no se puede cambiar
        public static readonly string RutaArchivo = Path.Combine(carpeta, "datos.xml");

        // El "traductor" entre el objeto DatosAprendiz y el texto XML (se crea una sola vez)
        private static readonly XmlSerializer serializador = new XmlSerializer(typeof(DatosAprendiz));

        // Los datos en memoria; empieza en null y se llena la primera vez que se usan
        private static DatosAprendiz datos;

        /// <summary>
        /// Da los datos en memoria. La primera vez los lee del archivo (o crea los de demostración).
        /// </summary>
        private static DatosAprendiz DatosEnMemoria
        {
            // "get" se ejecuta cada vez que alguien lee la propiedad
            get
            {
                // Si todavía no se han cargado...
                if (datos == null)
                {
                    // ...los carga del archivo
                    Cargar();
                }
                // Devuelve los datos ya cargados
                return datos;
            }
        }

        /// <summary>
        /// El menú del día de hoy. Si el menú guardado es de otro día (por ejemplo, de ayer),
        /// lo cambia por el menú de hoy con todos los cupos y guarda el archivo.
        /// </summary>
        public static MenuDia MenuDelDia
        {
            // "get" se ejecuta cada vez que alguien lee la propiedad
            get
            {
                // Si no hay menú o el menú guardado no es de hoy...
                if (DatosEnMemoria.MenuDelDia == null || DatosEnMemoria.MenuDelDia.Fecha.Date != DateTime.Today)
                {
                    // ...pone el menú de hoy
                    DatosEnMemoria.MenuDelDia = DatosDemoAprendiz.CrearMenuDeHoy();
                    // ...y guarda el cambio en el archivo
                    Guardar();
                }
                // Devuelve el menú de hoy
                return DatosEnMemoria.MenuDelDia;
            }
        }

        /// <summary>
        /// Lee el archivo datos.xml y llena los datos en memoria.
        /// Si el archivo no existe o está dañado, usa los datos de demostración y crea el archivo.
        /// </summary>
        private static void Cargar()
        {
            // Si el archivo ya existe...
            if (File.Exists(RutaArchivo))
            {
                // "try" = intenta leerlo; si algo sale mal, salta al "catch"
                try
                {
                    // Abre el archivo para leer ("using" lo cierra solo al terminar)
                    using (FileStream archivo = File.OpenRead(RutaArchivo))
                    {
                        // Convierte el XML en un objeto DatosAprendiz ("as" deja null si no es de ese tipo)
                        datos = serializador.Deserialize(archivo) as DatosAprendiz;
                    }
                }
                // El XML está dañado (por ejemplo, alguien lo editó a mano y le borró algo)
                catch (InvalidOperationException)
                {
                    // Se descartan los datos leídos; abajo se usan los de demostración
                    datos = null;
                }
                // No se pudo abrir el archivo (por ejemplo, otro programa lo tiene bloqueado)
                catch (IOException)
                {
                    // Se descartan los datos leídos; abajo se usan los de demostración
                    datos = null;
                }
            }
            // Si no había archivo o no se pudo leer...
            if (datos == null)
            {
                // ...usa los datos de demostración
                datos = DatosDemoAprendiz.Crear();
                // ...y crea el archivo con ellos
                Guardar();
                // Termina aquí: los datos de demostración ya vienen completos
                return;
            }
            // Si al archivo le faltaba el perfil, pone el de demostración
            if (datos.Perfil == null)
            {
                // Perfil de Carlos Ruiz
                datos.Perfil = DatosDemoAprendiz.CrearPerfil();
            }
            // Si al archivo le faltaba la lista de reservas, empieza una vacía
            if (datos.Reservas == null)
            {
                // Lista vacía de reservas
                datos.Reservas = new List<Reserva>();
            }
            // Si al archivo le faltaba la lista de sugerencias, empieza una vacía
            if (datos.Sugerencias == null)
            {
                // Lista vacía de sugerencias
                datos.Sugerencias = new List<Sugerencia>();
            }
        }

        /// <summary>
        /// Escribe todos los datos en memoria en el archivo datos.xml (lo reemplaza completo).
        /// Si no se puede escribir, muestra un aviso y la aplicación sigue funcionando.
        /// </summary>
        private static void Guardar()
        {
            // "try" = intenta guardar; si algo sale mal, salta al "catch"
            try
            {
                // Crea la carpeta %LOCALAPPDATA%\GastroSena (si ya existe, no hace nada)
                Directory.CreateDirectory(carpeta);
                // Abre el archivo para escribir desde cero, en UTF-8 ("using" lo cierra solo al terminar)
                using (StreamWriter archivo = new StreamWriter(RutaArchivo, false, Encoding.UTF8))
                {
                    // Convierte los datos en XML y los escribe en el archivo
                    serializador.Serialize(archivo, datos);
                }
            }
            // Error al escribir el archivo (disco lleno, archivo bloqueado...)
            catch (IOException error)
            {
                // Avisa que el cambio solo quedó en memoria
                MessageBox.Show("No se pudieron guardar los cambios en " + RutaArchivo + ".\n\n" + error.Message, "GastroSENA", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            // No hay permiso para escribir en esa carpeta
            catch (UnauthorizedAccessException error)
            {
                // Avisa que el cambio solo quedó en memoria
                MessageBox.Show("No se pudieron guardar los cambios en " + RutaArchivo + ".\n\n" + error.Message, "GastroSENA", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        /// <summary>
        /// Da las reservas del aprendiz ordenadas de la más reciente a la más antigua.
        /// </summary>
        /// <returns>Una lista nueva con las reservas ordenadas.</returns>
        public static List<Reserva> ObtenerReservas()
        {
            // Ordena por fecha de mayor a menor ("reserva => reserva.Fecha" = "ordena usando la fecha de cada reserva")
            return DatosEnMemoria.Reservas.OrderByDescending(reserva => reserva.Fecha).ToList();
        }

        /// <summary>
        /// Revisa si el aprendiz ya reservó su almuerzo hoy.
        /// </summary>
        /// <returns>true si ya hay una reserva con la fecha de hoy; false si no.</returns>
        public static bool ReservoHoy()
        {
            // Recorre todas las reservas una por una
            foreach (Reserva reserva in DatosEnMemoria.Reservas)
            {
                // Si la fecha (sin la hora) de esta reserva es hoy...
                if (reserva.Fecha.Date == DateTime.Today)
                {
                    // ...ya reservó: devuelve true y termina
                    return true;
                }
            }
            // No encontró ninguna reserva de hoy
            return false;
        }

        /// <summary>
        /// Reserva el almuerzo de hoy: crea la reserva como "Pendiente" de pago, descuenta un cupo
        /// del menú y guarda el archivo. Quien la llama debe revisar antes el horario y si ya reservó.
        /// </summary>
        /// <returns>La reserva nueva.</returns>
        public static Reserva ReservarAlmuerzo()
        {
            // Toma el menú de hoy
            MenuDia menu = MenuDelDia;
            // Crea la reserva con los datos del menú
            Reserva reserva = new Reserva
            {
                // Fecha y hora de este momento
                Fecha = DateTime.Now,
                // Nombre del menú de hoy
                NombreMenu = menu.Nombre,
                // Precio del menú de hoy
                Precio = menu.Precio,
                // Queda pendiente hasta que la pague en la ventanilla
                EstadoPago = EstadoPago.Pendiente
            };
            // Agrega la reserva a la lista
            DatosEnMemoria.Reservas.Add(reserva);
            // Descuenta un cupo del menú
            menu.CuposDisponibles = menu.CuposDisponibles - 1;
            // Guarda el archivo
            Guardar();
            // Devuelve la reserva nueva
            return reserva;
        }

        /// <summary>
        /// Da las sugerencias del aprendiz ordenadas de la más reciente a la más antigua.
        /// </summary>
        /// <returns>Una lista nueva con las sugerencias ordenadas.</returns>
        public static List<Sugerencia> ObtenerSugerencias()
        {
            // Ordena por fecha de mayor a menor
            return DatosEnMemoria.Sugerencias.OrderByDescending(sugerencia => sugerencia.Fecha).ToList();
        }

        /// <summary>
        /// Guarda una sugerencia nueva como "Pendiente" (todavía sin respuesta del comedor).
        /// </summary>
        /// <param name="asunto">Tema de la sugerencia (ya validado).</param>
        /// <param name="mensaje">Texto de la sugerencia (ya validado).</param>
        public static void AgregarSugerencia(string asunto, string mensaje)
        {
            // Crea la sugerencia y la agrega a la lista
            DatosEnMemoria.Sugerencias.Add(new Sugerencia
            {
                // Fecha y hora de este momento
                Fecha = DateTime.Now,
                // Tema escrito por el aprendiz
                Asunto = asunto,
                // Mensaje escrito por el aprendiz
                Mensaje = mensaje,
                // Queda pendiente hasta que el comedor la responda
                Estado = EstadoSugerencia.Pendiente,
                // Sin respuesta todavía
                Respuesta = ""
            });
            // Guarda el archivo
            Guardar();
        }

        /// <summary>
        /// Copia en el usuario que inició sesión los datos de perfil guardados en el archivo
        /// (nombre, correo, ficha y programa). FrmPanel lo llama al abrir el panel del aprendiz,
        /// así el nombre editado en Perfil se ve también después de cerrar y abrir la aplicación.
        /// </summary>
        /// <param name="usuario">El usuario que acaba de iniciar sesión.</param>
        public static void CompletarPerfil(Usuario usuario)
        {
            // Toma el perfil guardado
            Usuario perfil = DatosEnMemoria.Perfil;
            // Si el perfil guardado es de otra persona (otro documento), no copia nada
            if (perfil.Documento != usuario.Documento)
            {
                // Sale del método sin hacer cambios
                return;
            }
            // Copia el nombre guardado
            usuario.NombreCompleto = perfil.NombreCompleto;
            // Copia el correo guardado
            usuario.Correo = perfil.Correo;
            // Copia la ficha guardada
            usuario.Ficha = perfil.Ficha;
            // Copia el programa guardado
            usuario.Programa = perfil.Programa;
        }

        /// <summary>
        /// Guarda en el archivo los datos de perfil del usuario (nombre, correo, ficha y programa).
        /// La sección Perfil lo llama al presionar "Guardar cambios".
        /// </summary>
        /// <param name="usuario">El usuario con los datos ya actualizados.</param>
        public static void GuardarPerfil(Usuario usuario)
        {
            // Toma el perfil guardado
            Usuario perfil = DatosEnMemoria.Perfil;
            // Copia el documento (por si el archivo no lo tenía)
            perfil.Documento = usuario.Documento;
            // Copia el nombre nuevo
            perfil.NombreCompleto = usuario.NombreCompleto;
            // Copia el correo nuevo
            perfil.Correo = usuario.Correo;
            // Copia la ficha nueva
            perfil.Ficha = usuario.Ficha;
            // Copia el programa
            perfil.Programa = usuario.Programa;
            // Guarda el archivo
            Guardar();
        }
    }
}
