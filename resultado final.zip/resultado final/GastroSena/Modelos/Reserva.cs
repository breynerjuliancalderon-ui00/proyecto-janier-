﻿// Archivo: Modelos/Reserva.cs
// Modelo de una reserva de almuerzo (una "ficha") del aprendiz.
// Es una clase sencilla, solo con propiedades; no tiene lógica.

// Trae DateTime (fecha y hora)
using System;

// Espacio de nombres de los modelos (carpeta Modelos)
namespace GastroSena.Modelos
{
    /// <summary>
    /// Representa un almuerzo reservado. Se crea al presionar "Reservar almuerzo" en Inicio
    /// y se lista en la sección Mis Fichas.
    /// </summary>
    public class Reserva
    {
        /// <summary>
        /// Fecha y hora en que se hizo la reserva. Si es de hoy, la ficha está "Reservado";
        /// si es de un día anterior, ya está "Consumido".
        /// </summary>
        // Propiedad automática de tipo fecha
        public DateTime Fecha { get; set; }

        /// <summary>
        /// Nombre del menú que se reservó (por ejemplo, "Menú Ejecutivo SENA").
        /// </summary>
        // Propiedad automática de tipo texto
        public string NombreMenu { get; set; }

        /// <summary>
        /// Lo que vale el almuerzo en pesos (0 si es gratis).
        /// </summary>
        // decimal = número para dinero
        public decimal Precio { get; set; }

        /// <summary>
        /// Si la reserva ya se pagó, está pendiente o es gratis.
        /// </summary>
        // Propiedad automática del tipo EstadoPago (la enumeración de EstadoPago.cs)
        public EstadoPago EstadoPago { get; set; }
    }
}
