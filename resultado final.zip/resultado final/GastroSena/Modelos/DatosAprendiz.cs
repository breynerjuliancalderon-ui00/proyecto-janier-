﻿// Archivo: Modelos/DatosAprendiz.cs
// Junta en un solo objeto todo lo que se guarda en el archivo datos.xml:
// el perfil del aprendiz, el menú de hoy, sus reservas y sus sugerencias.
// XmlSerializer convierte este objeto en XML (al guardar) y el XML otra vez en objeto (al abrir).

// Trae List<T>, la lista que guarda las reservas y las sugerencias
using System.Collections.Generic;

// Espacio de nombres de los modelos (carpeta Modelos)
namespace GastroSena.Modelos
{
    /// <summary>
    /// Todo lo que el perfil Aprendiz necesita guardar para que no se pierda al cerrar la aplicación.
    /// Datos/AlmacenDatos.cs lo lee y lo escribe en %LOCALAPPDATA%\GastroSena\datos.xml.
    /// </summary>
    public class DatosAprendiz
    {
        /// <summary>
        /// Datos del aprendiz que se pueden editar en la sección Perfil (nombre, correo, ficha...).
        /// </summary>
        // Propiedad automática del tipo Usuario
        public Usuario Perfil { get; set; }

        /// <summary>
        /// El almuerzo que ofrece el comedor hoy.
        /// </summary>
        // Propiedad automática del tipo MenuDia
        public MenuDia MenuDelDia { get; set; }

        /// <summary>
        /// Todas las reservas de almuerzo del aprendiz.
        /// </summary>
        // Empieza como una lista vacía para que nunca sea null
        public List<Reserva> Reservas { get; set; } = new List<Reserva>();

        /// <summary>
        /// Todas las sugerencias que el aprendiz ha enviado.
        /// </summary>
        // Empieza como una lista vacía para que nunca sea null
        public List<Sugerencia> Sugerencias { get; set; } = new List<Sugerencia>();
    }
}
