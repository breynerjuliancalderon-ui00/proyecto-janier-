﻿// Archivo: Modelos/Usuario.cs
// Modelo de un usuario de GastroSENA: guarda sus datos básicos (documento, contraseña, nombre y perfil)
// y los datos que muestra la sección Perfil del aprendiz (correo, ficha y programa).
// Es una clase sencilla, solo con propiedades; no tiene lógica.

// Trae el atributo [XmlIgnore], que le dice a XmlSerializer qué propiedad NO guardar en el archivo
using System.Xml.Serialization;

// Espacio de nombres de los modelos (carpeta Modelos)
namespace GastroSena.Modelos
{
    /// <summary>
    /// Representa a una persona que puede entrar al sistema.
    /// Los usuarios de demostración se crean en Datos/UsuariosDemo.cs.
    /// El perfil del aprendiz también se guarda en el archivo datos.xml (ver Datos/AlmacenDatos.cs).
    /// </summary>
    public class Usuario
    {
        /// <summary>
        /// Número de documento de identidad. Es lo que se escribe en la caja "Usuario" del login.
        /// </summary>
        // Propiedad automática: C# guarda el valor por nosotros (get = leer, set = cambiar)
        public string Documento { get; set; }

        /// <summary>
        /// Contraseña para entrar (en los usuarios de demostración es demo123).
        /// No se guarda en datos.xml: el archivo solo lleva los datos del perfil.
        /// </summary>
        // [XmlIgnore] = XmlSerializer se salta esta propiedad al escribir el archivo
        [XmlIgnore]
        // Propiedad automática de tipo texto
        public string Contrasena { get; set; }

        /// <summary>
        /// Nombre completo de la persona. Se muestra en el encabezado del panel y en Inicio.
        /// </summary>
        // Propiedad automática de tipo texto
        public string NombreCompleto { get; set; }

        /// <summary>
        /// Perfil del usuario (Aprendiz, Instructor, Encargado o Invitado).
        /// </summary>
        // Propiedad automática del tipo Rol (la enumeración de Rol.cs)
        public Rol Rol { get; set; }

        /// <summary>
        /// Correo electrónico (por ejemplo, el institucional del SENA). Se edita en la sección Perfil.
        /// </summary>
        // Propiedad automática de tipo texto
        public string Correo { get; set; }

        /// <summary>
        /// Número de ficha (el grupo de formación del aprendiz). Se edita en la sección Perfil.
        /// </summary>
        // Propiedad automática de tipo texto (es texto porque no se hacen cuentas con él)
        public string Ficha { get; set; }

        /// <summary>
        /// Programa de formación que estudia el aprendiz (por ejemplo, ADSO).
        /// </summary>
        // Propiedad automática de tipo texto
        public string Programa { get; set; }
    }
}
