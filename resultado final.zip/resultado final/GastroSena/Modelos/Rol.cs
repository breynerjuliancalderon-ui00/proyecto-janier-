﻿// Archivo: Modelos/Rol.cs
// Lista de los perfiles (roles) que puede tener un usuario de GastroSENA.
// El perfil decide qué botones aparecen en el menú lateral del panel.

// Espacio de nombres de los modelos (carpeta Modelos)
namespace GastroSena.Modelos
{
    /// <summary>
    /// Enumeración con los cuatro perfiles posibles. Un "enum" es una lista fija de opciones
    /// con nombre: así se escribe Rol.Aprendiz en vez de un texto que se podría escribir mal.
    /// </summary>
    public enum Rol
    {
        // Aprendiz del SENA: consulta sus fichas de almuerzo y deja sugerencias
        Aprendiz,
        // Instructor: revisa su cuenta y sus consumos en la cafetería
        Instructor,
        // Encargado de la cafetería: administra ventas, menú, inventario y demás
        Encargado,
        // Invitado o visitante: solo ve el inicio y el buzón de sugerencias
        Invitado
    }
}
