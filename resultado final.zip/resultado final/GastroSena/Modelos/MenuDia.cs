﻿// Archivo: Modelos/MenuDia.cs
// Modelo del menú del día: el almuerzo que ofrece el comedor hoy, su precio y cuántos cupos quedan.
// Es una clase sencilla, solo con propiedades; no tiene lógica.

// Trae DateTime (fecha y hora)
using System;

// Espacio de nombres de los modelos (carpeta Modelos)
namespace GastroSena.Modelos
{
    /// <summary>
    /// Representa el almuerzo que el comedor ofrece en un día.
    /// Se muestra en la tarjeta "Menú del día" de la sección Inicio del aprendiz.
    /// </summary>
    public class MenuDia
    {
        /// <summary>
        /// Día en que se sirve este menú.
        /// </summary>
        // Propiedad automática de tipo fecha
        public DateTime Fecha { get; set; }

        /// <summary>
        /// Nombre del menú (por ejemplo, "Menú Ejecutivo SENA").
        /// </summary>
        // Propiedad automática de tipo texto
        public string Nombre { get; set; }

        /// <summary>
        /// Qué trae el almuerzo (sopa, proteína, arroz...).
        /// </summary>
        // Propiedad automática de tipo texto
        public string Descripcion { get; set; }

        /// <summary>
        /// Precio del almuerzo en pesos colombianos (por ejemplo, 5000).
        /// </summary>
        // decimal = número para dinero (no pierde centavos como double)
        public decimal Precio { get; set; }

        /// <summary>
        /// Cuántos almuerzos quedan por reservar hoy. Baja de a uno con cada reserva.
        /// </summary>
        // Propiedad automática de tipo número entero
        public int CuposDisponibles { get; set; }
    }
}
