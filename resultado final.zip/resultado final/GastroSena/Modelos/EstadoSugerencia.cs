﻿// Archivo: Modelos/EstadoSugerencia.cs
// Lista de los estados que puede tener una sugerencia del buzón.

// Espacio de nombres de los modelos (carpeta Modelos)
namespace GastroSena.Modelos
{
    /// <summary>
    /// Enumeración con los dos estados posibles de una sugerencia.
    /// </summary>
    public enum EstadoSugerencia
    {
        // Recién enviada: el encargado del comedor todavía no la ha respondido
        Pendiente,
        // El encargado ya la leyó y escribió una respuesta
        Atendida
    }
}
