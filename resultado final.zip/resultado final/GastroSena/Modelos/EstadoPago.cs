﻿// Archivo: Modelos/EstadoPago.cs
// Lista de los estados de pago que puede tener una reserva de almuerzo.
// Se muestra en la columna "Estado de pago" de Mis Fichas, cada uno con su color.

// Espacio de nombres de los modelos (carpeta Modelos)
namespace GastroSena.Modelos
{
    /// <summary>
    /// Enumeración con los tres estados de pago posibles de una reserva.
    /// Usar un "enum" evita escribir mal el texto ("pagado", "Pagdo"...).
    /// </summary>
    public enum EstadoPago
    {
        // Ya se pagó en la ventanilla del comedor (se pinta de verde)
        Pagado,
        // Todavía no se ha pagado (se pinta de amarillo). Así quedan las reservas nuevas
        Pendiente,
        // No se paga, por ejemplo por un beneficio del SENA (se pinta de azul)
        Gratis
    }
}
