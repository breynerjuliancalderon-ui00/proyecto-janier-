﻿// Archivo: Modelos/Sugerencia.cs
// Modelo de una sugerencia que el aprendiz envía desde el Buzón de Sugerencias.
// Es una clase sencilla, solo con propiedades; no tiene lógica.

// Trae DateTime (fecha y hora)
using System;

// Espacio de nombres de los modelos (carpeta Modelos)
namespace GastroSena.Modelos
{
    /// <summary>
    /// Representa un mensaje que el aprendiz le deja al encargado del comedor,
    /// con la respuesta del comedor cuando ya fue atendido.
    /// </summary>
    public class Sugerencia
    {
        /// <summary>
        /// Fecha y hora en que se envió la sugerencia.
        /// </summary>
        // Propiedad automática de tipo fecha
        public DateTime Fecha { get; set; }

        /// <summary>
        /// Tema corto de la sugerencia (de 3 a 150 caracteres).
        /// </summary>
        // Propiedad automática de tipo texto
        public string Asunto { get; set; }

        /// <summary>
        /// Texto completo de la sugerencia (de 10 a 2000 caracteres).
        /// </summary>
        // Propiedad automática de tipo texto
        public string Mensaje { get; set; }

        /// <summary>
        /// Si la sugerencia está Pendiente o ya fue Atendida.
        /// </summary>
        // Propiedad automática del tipo EstadoSugerencia (la enumeración de EstadoSugerencia.cs)
        public EstadoSugerencia Estado { get; set; }

        /// <summary>
        /// Lo que contestó el comedor. Queda vacío mientras la sugerencia está pendiente.
        /// </summary>
        // Propiedad automática de tipo texto
        public string Respuesta { get; set; }
    }
}
