﻿// Archivo: Utilidades/Formato.cs
// Convierte números y fechas en el texto que se muestra en pantalla, al estilo de Colombia:
// pesos como "$5.000" y fechas como "Viernes, 13 de noviembre de 2026" o "13/11/2026".

// Trae DateTime (fechas)
using System;
// Trae CultureInfo (las reglas de idioma y formato de cada país)
using System.Globalization;

// Espacio de nombres de las utilidades (carpeta Utilidades)
namespace GastroSena.Utilidades
{
    /// <summary>
    /// Métodos pequeños para dar formato a precios y fechas. Es "static": se usa directo,
    /// por ejemplo Formato.Pesos(5000), sin crear objetos de ella.
    /// </summary>
    public static class Formato
    {
        // Reglas de español de Colombia (es-CO): punto para miles, nombres de días y meses en español
        private static readonly CultureInfo culturaColombia = CultureInfo.GetCultureInfo("es-CO");

        /// <summary>
        /// Escribe un valor en pesos sin decimales. Ejemplo: 5000 se vuelve "$5.000".
        /// </summary>
        /// <param name="valor">El valor en pesos.</param>
        /// <returns>El texto con el signo $ y el punto de miles.</returns>
        public static string Pesos(decimal valor)
        {
            // "N0" = número con separador de miles y 0 decimales; delante se pone el signo $
            return "$" + valor.ToString("N0", culturaColombia);
        }

        /// <summary>
        /// Escribe una fecha larga en español con la primera letra en mayúscula.
        /// Ejemplo: "Viernes, 13 de noviembre de 2026".
        /// </summary>
        /// <param name="fecha">La fecha que se quiere mostrar.</param>
        /// <returns>El texto de la fecha.</returns>
        public static string FechaLarga(DateTime fecha)
        {
            // dddd = nombre del día, d = número del día, MMMM = nombre del mes, yyyy = año ('de' va tal cual)
            string texto = fecha.ToString("dddd, d 'de' MMMM 'de' yyyy", culturaColombia);
            // Pone en mayúscula la primera letra y le pega el resto del texto
            return char.ToUpper(texto[0], culturaColombia) + texto.Substring(1);
        }

        /// <summary>
        /// Escribe una fecha corta, por ejemplo "13/11/2026". Se usa en las tablas.
        /// </summary>
        /// <param name="fecha">La fecha que se quiere mostrar.</param>
        /// <returns>El texto de la fecha (día/mes/año).</returns>
        public static string FechaCorta(DateTime fecha)
        {
            // dd = día con dos cifras, MM = mes con dos cifras, yyyy = año
            return fecha.ToString("dd/MM/yyyy", culturaColombia);
        }
    }
}
