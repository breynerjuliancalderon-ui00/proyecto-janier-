﻿// Archivo: Formularios/FrmLogin.cs
// Formulario de inicio de sesión: aquí el usuario elige su perfil y entra a GastroSENA.
// Este archivo tiene la lógica (lo que pasa al hacer clic). Los controles se dibujan en
// FrmLogin.Designer.cs, que se edita desde la vista [Diseño] de Visual Studio.

// Trae lo básico de C# (EventArgs, Math...)
using System;
// Trae los colores (Color) que se usan para resaltar el perfil elegido
using System.Drawing;
// Trae los formularios y controles de Windows Forms (Form, RadioButton, Panel, MessageBox...)
using System.Windows.Forms;
// Trae la clase UsuariosDemo, donde están los usuarios de demostración
using GastroSena.Datos;
// Trae las clases Usuario y Rol
using GastroSena.Modelos;

// Espacio de nombres de los formularios (carpeta Formularios)
namespace GastroSena.Formularios
{
    /// <summary>
    /// Formulario de inicio de sesión. Muestra la foto de la cafetería de fondo y una tarjeta
    /// blanca con el logo, las cajas Usuario y Contraseña, las cuatro opciones de perfil
    /// y el botón "Iniciar sesión". Es el primer formulario que se abre (ver Program.cs).
    /// </summary>
    public partial class FrmLogin : Form
    {
        // Verde SENA (#39A900): fondo de la opción elegida y del botón Iniciar sesión habilitado
        private readonly Color verdeSena = Color.FromArgb(57, 169, 0);
        // Gris muy clarito: fondo de las opciones de perfil que no están elegidas
        private readonly Color grisOpcion = Color.FromArgb(241, 244, 238);
        // Gris del botón Iniciar sesión mientras está deshabilitado
        private readonly Color grisDeshabilitado = Color.FromArgb(197, 206, 192);
        // Casi negro: color del nombre del perfil cuando la opción no está elegida
        private readonly Color textoOscuro = Color.FromArgb(31, 41, 51);
        // Gris: color de la frase corta del perfil cuando la opción no está elegida
        private readonly Color textoGris = Color.FromArgb(107, 114, 128);
        // Guarda el perfil (rol) que el usuario eligió en las opciones grandes
        private Rol rolElegido;

        /// <summary>
        /// Constructor: se ejecuta al crear el formulario (new FrmLogin() en Program.cs).
        /// Llama a InitializeComponent, que crea los controles tal como se ven en [Diseño].
        /// </summary>
        public FrmLogin()
        {
            // Crea y acomoda todos los controles dibujados en el diseñador
            InitializeComponent();
        }

        /// <summary>
        /// Evento Load: se ejecuta una sola vez, justo antes de que el login se vea por primera vez.
        /// Acomoda la foto de fondo al tamaño de la ventana.
        /// </summary>
        /// <param name="sender">El formulario que lanzó el evento (este mismo login).</param>
        /// <param name="e">Datos del evento (aquí no se usan).</param>
        private void FrmLogin_Load(object sender, EventArgs e)
        {
            // Hace que la foto de la cafetería cubra toda la ventana
            AjustarFondo();
        }

        /// <summary>
        /// Evento Resize: se ejecuta cada vez que la ventana cambia de tamaño
        /// (al maximizarla, restaurarla o estirarla con el mouse). Vuelve a acomodar la foto.
        /// La tarjeta blanca no necesita código: su propiedad Anchor = None la mantiene centrada.
        /// </summary>
        /// <param name="sender">El formulario que cambió de tamaño.</param>
        /// <param name="e">Datos del evento (aquí no se usan).</param>
        private void FrmLogin_Resize(object sender, EventArgs e)
        {
            // Acomoda otra vez la foto al nuevo tamaño de la ventana
            AjustarFondo();
        }

        /// <summary>
        /// Agranda la foto de fondo (picFondo) para que cubra toda la ventana sin deformarse.
        /// La foto es 4:3 y la ventana maximizada es más ancha, así que lo que sobra
        /// se recorta por igual arriba y abajo (o a los lados).
        /// </summary>
        private void AjustarFondo()
        {
            // Si la ventana está minimizada su tamaño es 0 y no hay nada que acomodar
            if (ClientSize.Width == 0 || ClientSize.Height == 0)
            {
                // Sale del método sin hacer nada
                return;
            }
            // Cuántas veces hay que agrandar la foto para llenar el ancho de la ventana
            double escalaAncho = (double)ClientSize.Width / picFondo.Image.Width;
            // Cuántas veces hay que agrandar la foto para llenar el alto de la ventana
            double escalaAlto = (double)ClientSize.Height / picFondo.Image.Height;
            // Se usa la escala mayor para que no quede ningún espacio vacío
            double escala = Math.Max(escalaAncho, escalaAlto);
            // Ancho final de la foto (redondeado hacia arriba para no dejar una rayita sin cubrir)
            int ancho = (int)Math.Ceiling(picFondo.Image.Width * escala);
            // Alto final de la foto, con la misma escala para que no se deforme
            int alto = (int)Math.Ceiling(picFondo.Image.Height * escala);
            // Coloca la foto centrada: x, y, ancho y alto (si sobra, queda fuera de la ventana)
            picFondo.SetBounds((ClientSize.Width - ancho) / 2, (ClientSize.Height - alto) / 2, ancho, alto);
        }

        /// <summary>
        /// Evento CheckedChanged de las cuatro opciones de perfil (rbAprendiz, rbInstructor,
        /// rbEncargado y rbInvitado comparten este método). Se ejecuta cuando una opción se marca
        /// o se desmarca. Al marcar una: desmarca las otras, llena el usuario y la contraseña
        /// de demostración, habilita el botón Iniciar sesión y pinta de verde la opción elegida.
        /// </summary>
        /// <param name="sender">La opción (RadioButton) que cambió.</param>
        /// <param name="e">Datos del evento (aquí no se usan).</param>
        private void rbPerfil_CheckedChanged(object sender, EventArgs e)
        {
            // Convierte el sender en RadioButton para saber cuál opción cambió
            RadioButton opcion = (RadioButton)sender;
            // Si la opción se acaba de desmarcar no hay nada que hacer aquí
            if (!opcion.Checked)
            {
                // Sale del método
                return;
            }
            // Cada opción está en su propio panel, por eso las otras no se desmarcan solas:
            // Aprendiz queda marcado solo si fue el elegido
            rbAprendiz.Checked = (opcion == rbAprendiz);
            // Instructor queda marcado solo si fue el elegido
            rbInstructor.Checked = (opcion == rbInstructor);
            // Encargado queda marcado solo si fue el elegido
            rbEncargado.Checked = (opcion == rbEncargado);
            // Invitado queda marcado solo si fue el elegido
            rbInvitado.Checked = (opcion == rbInvitado);
            // Averigua qué perfil corresponde a la opción elegida
            if (opcion == rbAprendiz)
            {
                // Se eligió Aprendiz
                rolElegido = Rol.Aprendiz;
            }
            // Si no fue Aprendiz, revisa si fue Instructor
            else if (opcion == rbInstructor)
            {
                // Se eligió Instructor
                rolElegido = Rol.Instructor;
            }
            // Si tampoco, revisa si fue Encargado
            else if (opcion == rbEncargado)
            {
                // Se eligió Encargado
                rolElegido = Rol.Encargado;
            }
            // Si no fue ninguno de los anteriores, fue Invitado
            else
            {
                // Se eligió Invitado
                rolElegido = Rol.Invitado;
            }
            // Busca el usuario de demostración de ese perfil
            Usuario demo = UsuariosDemo.BuscarPorRol(rolElegido);
            // Escribe su documento en la caja Usuario
            txtUsuario.Text = demo.Documento;
            // Escribe su contraseña (demo123) en la caja Contraseña; se ve con puntos por el PasswordChar
            txtContrasena.Text = demo.Contrasena;
            // Ya hay un perfil elegido, así que se puede presionar Iniciar sesión
            btnEntrar.Enabled = true;
            // Pinta de verde la opción elegida y de gris las demás
            PintarOpciones();
        }

        /// <summary>
        /// Evento Click de los paneles y de las frases de cada opción. Permite elegir el perfil
        /// haciendo clic en cualquier parte del recuadro, no solo en el circulito.
        /// </summary>
        /// <param name="sender">El panel o la frase en la que se hizo clic.</param>
        /// <param name="e">Datos del evento (aquí no se usan).</param>
        private void opcionPerfil_Click(object sender, EventArgs e)
        {
            // Si el clic fue en el recuadro o en la frase de Aprendiz...
            if (sender == pnlAprendiz || sender == lblFraseAprendiz)
            {
                // ...marca la opción Aprendiz (esto dispara rbPerfil_CheckedChanged)
                rbAprendiz.Checked = true;
            }
            // Si fue en el recuadro o en la frase de Instructor...
            else if (sender == pnlInstructor || sender == lblFraseInstructor)
            {
                // ...marca la opción Instructor
                rbInstructor.Checked = true;
            }
            // Si fue en el recuadro o en la frase de Encargado...
            else if (sender == pnlEncargado || sender == lblFraseEncargado)
            {
                // ...marca la opción Encargado
                rbEncargado.Checked = true;
            }
            // Si no, fue en el recuadro o en la frase de Invitado
            else
            {
                // Marca la opción Invitado
                rbInvitado.Checked = true;
            }
        }

        /// <summary>
        /// Pinta las cuatro opciones de perfil según estén elegidas o no.
        /// Se llama cada vez que cambia la opción elegida y al reiniciar el formulario.
        /// </summary>
        private void PintarOpciones()
        {
            // Pinta la opción Aprendiz
            PintarOpcion(pnlAprendiz, rbAprendiz, lblFraseAprendiz);
            // Pinta la opción Instructor
            PintarOpcion(pnlInstructor, rbInstructor, lblFraseInstructor);
            // Pinta la opción Encargado
            PintarOpcion(pnlEncargado, rbEncargado, lblFraseEncargado);
            // Pinta la opción Invitado
            PintarOpcion(pnlInvitado, rbInvitado, lblFraseInvitado);
        }

        /// <summary>
        /// Pinta una opción de perfil: verde SENA con letra blanca si está elegida,
        /// o gris clarito con letra oscura si no lo está.
        /// </summary>
        /// <param name="recuadro">El panel que forma el recuadro de la opción.</param>
        /// <param name="opcion">El RadioButton con el nombre del perfil.</param>
        /// <param name="frase">La etiqueta con la frase corta del perfil.</param>
        private void PintarOpcion(Panel recuadro, RadioButton opcion, Label frase)
        {
            // Si la opción está marcada...
            if (opcion.Checked)
            {
                // ...el recuadro se pone verde SENA
                recuadro.BackColor = verdeSena;
                // El nombre del perfil se pone blanco
                opcion.ForeColor = Color.White;
                // La frase también se pone blanca
                frase.ForeColor = Color.White;
            }
            // Si no está marcada...
            else
            {
                // ...el recuadro queda gris clarito
                recuadro.BackColor = grisOpcion;
                // El nombre del perfil queda oscuro
                opcion.ForeColor = textoOscuro;
                // La frase queda gris
                frase.ForeColor = textoGris;
            }
        }

        /// <summary>
        /// Evento EnabledChanged del botón Iniciar sesión: se ejecuta cuando el botón se habilita
        /// o se deshabilita. Lo pinta verde si se puede usar y gris si todavía no.
        /// </summary>
        /// <param name="sender">El botón Iniciar sesión.</param>
        /// <param name="e">Datos del evento (aquí no se usan).</param>
        private void btnEntrar_EnabledChanged(object sender, EventArgs e)
        {
            // Si el botón quedó habilitado...
            if (btnEntrar.Enabled)
            {
                // ...se pinta de verde SENA
                btnEntrar.BackColor = verdeSena;
            }
            // Si quedó deshabilitado...
            else
            {
                // ...se pinta de gris
                btnEntrar.BackColor = grisDeshabilitado;
            }
        }

        /// <summary>
        /// Evento Click del botón "Iniciar sesión" (también se activa con Enter, porque es el
        /// AcceptButton del formulario). Revisa el usuario y la contraseña: si corresponden a un
        /// usuario de demostración del perfil elegido, abre el panel y oculta el login;
        /// si no, muestra un mensaje de error.
        /// </summary>
        /// <param name="sender">El botón Iniciar sesión.</param>
        /// <param name="e">Datos del evento (aquí no se usan).</param>
        private void btnEntrar_Click(object sender, EventArgs e)
        {
            // Lee el documento escrito, quitando espacios al principio y al final
            string documento = txtUsuario.Text.Trim();
            // Lee la contraseña escrita
            string contrasena = txtContrasena.Text;
            // Busca un usuario de demostración con ese documento, esa contraseña y el perfil elegido
            Usuario usuario = UsuariosDemo.BuscarPorCredenciales(documento, contrasena, rolElegido);
            // Si no encontró ninguno, los datos están mal
            if (usuario == null)
            {
                // Muestra una ventanita de aviso con el error
                MessageBox.Show("Usuario o contraseña incorrectos", "GastroSENA", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                // Sale del método sin abrir el panel
                return;
            }
            // Crea el panel principal y le pasa el usuario que entró y este login (para volver al cerrar sesión)
            FrmPanel panel = new FrmPanel(usuario, this);
            // Muestra el panel
            panel.Show();
            // Oculta el login (no se cierra porque es el formulario principal: si se cerrara, se cerraría todo)
            this.Hide();
        }

        /// <summary>
        /// Deja el login como recién abierto: sin perfil elegido, con las cajas vacías y el botón
        /// deshabilitado. FrmPanel lo llama cuando el usuario presiona "Cerrar sesión".
        /// </summary>
        public void ReiniciarFormulario()
        {
            // Desmarca la opción Aprendiz
            rbAprendiz.Checked = false;
            // Desmarca la opción Instructor
            rbInstructor.Checked = false;
            // Desmarca la opción Encargado
            rbEncargado.Checked = false;
            // Desmarca la opción Invitado
            rbInvitado.Checked = false;
            // Borra el documento escrito
            txtUsuario.Clear();
            // Borra la contraseña escrita
            txtContrasena.Clear();
            // Deshabilita el botón hasta que se elija otra vez un perfil (se pone gris solo)
            btnEntrar.Enabled = false;
            // Pinta todas las opciones de gris
            PintarOpciones();
            // Pone el cursor en la caja Usuario
            txtUsuario.Focus();
        }
    }
}
