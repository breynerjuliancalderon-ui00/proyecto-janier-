﻿// Archivo: Formularios/FrmPanel.cs
// Panel principal de GastroSENA: se abre después de iniciar sesión.
// Tiene el menú lateral verde (un botón por sección), el encabezado con el usuario y el botón
// "Cerrar sesión", y el área de contenido donde se carga la sección (UserControl) elegida.
// Este archivo tiene la lógica; los controles se dibujan en FrmPanel.Designer.cs ([Diseño]).

// Trae lo básico de C# (EventArgs)
using System;
// Trae los colores (Color) para resaltar el botón activo del menú
using System.Drawing;
// Trae los formularios y controles de Windows Forms
using System.Windows.Forms;
// Trae AlmacenDatos (el perfil del aprendiz guardado en datos.xml)
using GastroSena.Datos;
// Trae las clases Usuario y Rol
using GastroSena.Modelos;
// Trae las secciones (UcInicio, UcMisFichas, UcVentas...)
using GastroSena.Secciones;

// Espacio de nombres de los formularios (carpeta Formularios)
namespace GastroSena.Formularios
{
    /// <summary>
    /// Panel principal. Recibe el usuario que inició sesión, muestra en el menú solo los botones
    /// de su perfil y carga en el área de contenido la sección que se elija (al abrir, Inicio).
    /// </summary>
    public partial class FrmPanel : Form
    {
        // Verde SENA (#39A900): fondo de los botones del menú
        private readonly Color verdeSena = Color.FromArgb(57, 169, 0);
        // Verde oscuro: color de un botón del menú cuando el mouse pasa por encima
        private readonly Color verdeOscuro = Color.FromArgb(46, 139, 0);
        // El usuario que inició sesión (llega desde el login)
        private readonly Usuario usuario;
        // El formulario de login, para volver a mostrarlo al cerrar sesión
        private readonly FrmLogin formularioLogin;
        // La sección (UserControl) que se está mostrando en el área de contenido
        private UserControl seccionActual;
        // Se pone en true al presionar "Cerrar sesión", para saber que no hay que cerrar toda la aplicación
        private bool cerrandoSesion;

        /// <summary>
        /// Constructor: se ejecuta cuando el login crea el panel (new FrmPanel(usuario, this)).
        /// Crea los controles del diseñador y guarda los datos que recibe.
        /// </summary>
        /// <param name="usuario">El usuario que acaba de iniciar sesión.</param>
        /// <param name="formularioLogin">El formulario de login, que queda oculto mientras el panel está abierto.</param>
        public FrmPanel(Usuario usuario, FrmLogin formularioLogin)
        {
            // Crea y acomoda todos los controles dibujados en el diseñador
            InitializeComponent();
            // Guarda el usuario en el campo de la clase ("this." distingue el campo del parámetro)
            this.usuario = usuario;
            // Guarda el login para poder mostrarlo otra vez al cerrar sesión
            this.formularioLogin = formularioLogin;
        }

        /// <summary>
        /// Evento Load: se ejecuta una vez, justo antes de que el panel se vea.
        /// Si es aprendiz, trae su perfil guardado en datos.xml. Luego escribe el nombre y el perfil
        /// en el encabezado, deja en el menú solo los botones del perfil y muestra la sección Inicio.
        /// </summary>
        /// <param name="sender">El formulario que lanzó el evento (este panel).</param>
        /// <param name="e">Datos del evento (aquí no se usan).</param>
        private void FrmPanel_Load(object sender, EventArgs e)
        {
            // Si el usuario es aprendiz...
            if (usuario.Rol == Rol.Aprendiz)
            {
                // ...copia su nombre, correo, ficha y programa guardados (por si los cambió en Perfil)
                AlmacenDatos.CompletarPerfil(usuario);
            }
            // Muestra el nombre del usuario en el encabezado
            lblNombreUsuario.Text = usuario.NombreCompleto;
            // Muestra el perfil en el encabezado (por ejemplo "Perfil: Aprendiz")
            lblPerfil.Text = "Perfil: " + usuario.Rol;
            // Deja visibles solo los botones que corresponden al perfil
            ConfigurarMenuSegunPerfil();
            // Al abrir, muestra la sección Inicio
            MostrarInicio();
        }

        /// <summary>
        /// Muestra u oculta cada botón del menú según el perfil del usuario.
        /// En [Diseño] se ven todos los botones; aquí se ocultan los que no le tocan.
        /// Como el menú es un FlowLayoutPanel, los botones ocultos no dejan huecos.
        /// </summary>
        private void ConfigurarMenuSegunPerfil()
        {
            // Guarda el perfil en una variable corta para escribir menos
            Rol rol = usuario.Rol;
            // Inicio: lo ven todos los perfiles
            btnInicio.Visible = true;
            // Mis Fichas: solo el aprendiz
            btnMisFichas.Visible = (rol == Rol.Aprendiz);
            // Mi Cuenta: solo el instructor
            btnMiCuenta.Visible = (rol == Rol.Instructor);
            // Consumos: solo el instructor
            btnConsumos.Visible = (rol == Rol.Instructor);
            // Ventas: solo el encargado
            btnVentas.Visible = (rol == Rol.Encargado);
            // Menú del Día: solo el encargado
            btnMenuDelDia.Visible = (rol == Rol.Encargado);
            // Beneficiarios: solo el encargado
            btnBeneficiarios.Visible = (rol == Rol.Encargado);
            // Cartera de Deudas: solo el encargado
            btnCarteraDeudas.Visible = (rol == Rol.Encargado);
            // Inventario: solo el encargado
            btnInventario.Visible = (rol == Rol.Encargado);
            // Grupos: solo el encargado
            btnGrupos.Visible = (rol == Rol.Encargado);
            // Visitas Institucionales: solo el encargado
            btnVisitasInstitucionales.Visible = (rol == Rol.Encargado);
            // Solicitudes de Cuenta: solo el encargado
            btnSolicitudesCuenta.Visible = (rol == Rol.Encargado);
            // Buzón de Sugerencias: lo ven todos los perfiles
            btnBuzonSugerencias.Visible = true;
            // Perfil: el aprendiz y el instructor (|| significa "o")
            btnPerfil.Visible = (rol == Rol.Aprendiz || rol == Rol.Instructor);
        }

        /// <summary>
        /// Cambia la sección que se ve en el área de contenido y resalta su botón en el menú.
        /// </summary>
        /// <param name="seccion">La sección nueva (un UserControl de la carpeta Secciones).</param>
        /// <param name="boton">El botón del menú que corresponde a esa sección.</param>
        private void MostrarSeccion(UserControl seccion, Button boton)
        {
            // Si ya había una sección en pantalla...
            if (seccionActual != null)
            {
                // ...la saca del área de contenido
                pnlContenido.Controls.Remove(seccionActual);
                // ...y libera la memoria que usaba
                seccionActual.Dispose();
            }
            // La sección nueva ocupa todo el espacio del área de contenido
            seccion.Dock = DockStyle.Fill;
            // Agrega la sección dentro del área de contenido para que se vea
            pnlContenido.Controls.Add(seccion);
            // Recuerda cuál sección se está mostrando ahora
            seccionActual = seccion;
            // Resalta el botón de esa sección en el menú
            MarcarBotonActivo(boton);
        }

        /// <summary>
        /// Pinta todos los botones del menú con su color normal (verde con letra blanca)
        /// y deja el botón activo resaltado (blanco con letra verde).
        /// </summary>
        /// <param name="botonActivo">El botón de la sección que se está mostrando.</param>
        private void MarcarBotonActivo(Button botonActivo)
        {
            // Recorre todos los botones que hay dentro del menú lateral
            foreach (Button boton in flpMenu.Controls)
            {
                // Fondo verde SENA, igual al menú
                boton.BackColor = verdeSena;
                // Letra blanca
                boton.ForeColor = Color.White;
                // Verde oscuro al pasar el mouse
                boton.FlatAppearance.MouseOverBackColor = verdeOscuro;
            }
            // El botón activo queda con fondo blanco
            botonActivo.BackColor = Color.White;
            // y con letra verde SENA
            botonActivo.ForeColor = verdeSena;
            // Al pasar el mouse sobre el botón activo sigue blanco (no cambia de color)
            botonActivo.FlatAppearance.MouseOverBackColor = Color.White;
        }

        /// <summary>
        /// Crea la sección Inicio que le toca al perfil y la muestra: el aprendiz ve UcInicio
        /// (menú del día y reservas) y los demás perfiles ven UcInicioGeneral (bienvenida).
        /// Se usa al abrir el panel y al presionar el botón Inicio.
        /// </summary>
        private void MostrarInicio()
        {
            // Si el usuario es aprendiz...
            if (usuario.Rol == Rol.Aprendiz)
            {
                // ...crea la sección Inicio del aprendiz
                UcInicio inicio = new UcInicio();
                // ...le pasa el usuario para que llene la bienvenida, el menú y el resumen
                inicio.CargarDatos(usuario);
                // ...y la muestra en el área de contenido, resaltando el botón Inicio
                MostrarSeccion(inicio, btnInicio);
            }
            // Si es otro perfil...
            else
            {
                // ...crea la sección Inicio general
                UcInicioGeneral inicio = new UcInicioGeneral();
                // ...le pasa el usuario para que muestre "Bienvenido, <nombre>" y su perfil
                inicio.MostrarBienvenida(usuario);
                // ...y la muestra en el área de contenido, resaltando el botón Inicio
                MostrarSeccion(inicio, btnInicio);
            }
        }

        /// <summary>
        /// Clic en el botón "Inicio" del menú: muestra la sección de bienvenida.
        /// </summary>
        /// <param name="sender">El botón Inicio.</param>
        /// <param name="e">Datos del evento (aquí no se usan).</param>
        private void btnInicio_Click(object sender, EventArgs e)
        {
            // Muestra la sección Inicio
            MostrarInicio();
        }

        /// <summary>
        /// Clic en el botón "Mis Fichas" (aprendiz): muestra la sección UcMisFichas.
        /// </summary>
        /// <param name="sender">El botón Mis Fichas.</param>
        /// <param name="e">Datos del evento (aquí no se usan).</param>
        private void btnMisFichas_Click(object sender, EventArgs e)
        {
            // Crea la sección Mis Fichas y la muestra, resaltando su botón
            MostrarSeccion(new UcMisFichas(), btnMisFichas);
        }

        /// <summary>
        /// Clic en el botón "Mi Cuenta" (instructor): muestra la sección UcMiCuenta.
        /// </summary>
        /// <param name="sender">El botón Mi Cuenta.</param>
        /// <param name="e">Datos del evento (aquí no se usan).</param>
        private void btnMiCuenta_Click(object sender, EventArgs e)
        {
            // Crea la sección Mi Cuenta y la muestra, resaltando su botón
            MostrarSeccion(new UcMiCuenta(), btnMiCuenta);
        }

        /// <summary>
        /// Clic en el botón "Consumos" (instructor): muestra la sección UcConsumos.
        /// </summary>
        /// <param name="sender">El botón Consumos.</param>
        /// <param name="e">Datos del evento (aquí no se usan).</param>
        private void btnConsumos_Click(object sender, EventArgs e)
        {
            // Crea la sección Consumos y la muestra, resaltando su botón
            MostrarSeccion(new UcConsumos(), btnConsumos);
        }

        /// <summary>
        /// Clic en el botón "Ventas" (encargado): muestra la sección UcVentas.
        /// </summary>
        /// <param name="sender">El botón Ventas.</param>
        /// <param name="e">Datos del evento (aquí no se usan).</param>
        private void btnVentas_Click(object sender, EventArgs e)
        {
            // Crea la sección Ventas y la muestra, resaltando su botón
            MostrarSeccion(new UcVentas(), btnVentas);
        }

        /// <summary>
        /// Clic en el botón "Menú del Día" (encargado): muestra la sección UcMenuDelDia.
        /// </summary>
        /// <param name="sender">El botón Menú del Día.</param>
        /// <param name="e">Datos del evento (aquí no se usan).</param>
        private void btnMenuDelDia_Click(object sender, EventArgs e)
        {
            // Crea la sección Menú del Día y la muestra, resaltando su botón
            MostrarSeccion(new UcMenuDelDia(), btnMenuDelDia);
        }

        /// <summary>
        /// Clic en el botón "Beneficiarios" (encargado): muestra la sección UcBeneficiarios.
        /// </summary>
        /// <param name="sender">El botón Beneficiarios.</param>
        /// <param name="e">Datos del evento (aquí no se usan).</param>
        private void btnBeneficiarios_Click(object sender, EventArgs e)
        {
            // Crea la sección Beneficiarios y la muestra, resaltando su botón
            MostrarSeccion(new UcBeneficiarios(), btnBeneficiarios);
        }

        /// <summary>
        /// Clic en el botón "Cartera de Deudas" (encargado): muestra la sección UcCarteraDeudas.
        /// </summary>
        /// <param name="sender">El botón Cartera de Deudas.</param>
        /// <param name="e">Datos del evento (aquí no se usan).</param>
        private void btnCarteraDeudas_Click(object sender, EventArgs e)
        {
            // Crea la sección Cartera de Deudas y la muestra, resaltando su botón
            MostrarSeccion(new UcCarteraDeudas(), btnCarteraDeudas);
        }

        /// <summary>
        /// Clic en el botón "Inventario" (encargado): muestra la sección UcInventario.
        /// </summary>
        /// <param name="sender">El botón Inventario.</param>
        /// <param name="e">Datos del evento (aquí no se usan).</param>
        private void btnInventario_Click(object sender, EventArgs e)
        {
            // Crea la sección Inventario y la muestra, resaltando su botón
            MostrarSeccion(new UcInventario(), btnInventario);
        }

        /// <summary>
        /// Clic en el botón "Grupos" (encargado): muestra la sección UcGrupos.
        /// </summary>
        /// <param name="sender">El botón Grupos.</param>
        /// <param name="e">Datos del evento (aquí no se usan).</param>
        private void btnGrupos_Click(object sender, EventArgs e)
        {
            // Crea la sección Grupos y la muestra, resaltando su botón
            MostrarSeccion(new UcGrupos(), btnGrupos);
        }

        /// <summary>
        /// Clic en el botón "Visitas Institucionales" (encargado): muestra la sección UcVisitasInstitucionales.
        /// </summary>
        /// <param name="sender">El botón Visitas Institucionales.</param>
        /// <param name="e">Datos del evento (aquí no se usan).</param>
        private void btnVisitasInstitucionales_Click(object sender, EventArgs e)
        {
            // Crea la sección Visitas Institucionales y la muestra, resaltando su botón
            MostrarSeccion(new UcVisitasInstitucionales(), btnVisitasInstitucionales);
        }

        /// <summary>
        /// Clic en el botón "Solicitudes de Cuenta" (encargado): muestra la sección UcSolicitudesCuenta.
        /// </summary>
        /// <param name="sender">El botón Solicitudes de Cuenta.</param>
        /// <param name="e">Datos del evento (aquí no se usan).</param>
        private void btnSolicitudesCuenta_Click(object sender, EventArgs e)
        {
            // Crea la sección Solicitudes de Cuenta y la muestra, resaltando su botón
            MostrarSeccion(new UcSolicitudesCuenta(), btnSolicitudesCuenta);
        }

        /// <summary>
        /// Clic en el botón "Buzón de Sugerencias" (todos los perfiles): el aprendiz ve UcBuzonSugerencias
        /// (formulario y sus sugerencias) y los demás perfiles ven UcBuzonSugerenciasGeneral.
        /// </summary>
        /// <param name="sender">El botón Buzón de Sugerencias.</param>
        /// <param name="e">Datos del evento (aquí no se usan).</param>
        private void btnBuzonSugerencias_Click(object sender, EventArgs e)
        {
            // Si el usuario es aprendiz...
            if (usuario.Rol == Rol.Aprendiz)
            {
                // ...crea el buzón del aprendiz y lo muestra, resaltando su botón
                MostrarSeccion(new UcBuzonSugerencias(), btnBuzonSugerencias);
            }
            // Si es otro perfil...
            else
            {
                // ...crea el buzón general y lo muestra, resaltando su botón
                MostrarSeccion(new UcBuzonSugerenciasGeneral(), btnBuzonSugerencias);
            }
        }

        /// <summary>
        /// Clic en el botón "Perfil" (aprendiz e instructor): el aprendiz ve UcPerfil (datos editables)
        /// y el instructor ve UcPerfilGeneral.
        /// </summary>
        /// <param name="sender">El botón Perfil.</param>
        /// <param name="e">Datos del evento (aquí no se usan).</param>
        private void btnPerfil_Click(object sender, EventArgs e)
        {
            // Si el usuario es aprendiz...
            if (usuario.Rol == Rol.Aprendiz)
            {
                // ...crea la sección Perfil del aprendiz
                UcPerfil perfil = new UcPerfil();
                // ...le pasa el usuario para que muestre sus datos
                perfil.CargarDatos(usuario);
                // ...se suscribe a su evento PerfilGuardado para actualizar el encabezado al guardar
                perfil.PerfilGuardado += new EventHandler(this.UcPerfil_PerfilGuardado);
                // ...y la muestra, resaltando su botón
                MostrarSeccion(perfil, btnPerfil);
            }
            // Si es otro perfil (instructor)...
            else
            {
                // ...crea la sección Perfil general y la muestra, resaltando su botón
                MostrarSeccion(new UcPerfilGeneral(), btnPerfil);
            }
        }

        /// <summary>
        /// Se ejecuta cuando el aprendiz guarda su perfil en UcPerfil:
        /// escribe el nombre nuevo en el encabezado del panel.
        /// </summary>
        /// <param name="sender">La sección UcPerfil que guardó los cambios.</param>
        /// <param name="e">Datos del evento (aquí no se usan).</param>
        private void UcPerfil_PerfilGuardado(object sender, EventArgs e)
        {
            // Muestra el nombre actualizado en el encabezado
            lblNombreUsuario.Text = usuario.NombreCompleto;
        }

        /// <summary>
        /// Clic en el botón "Cerrar sesión" del encabezado: cierra el panel y vuelve al login.
        /// </summary>
        /// <param name="sender">El botón Cerrar sesión.</param>
        /// <param name="e">Datos del evento (aquí no se usan).</param>
        private void btnCerrarSesion_Click(object sender, EventArgs e)
        {
            // Marca que se está cerrando sesión (así FrmPanel_FormClosed sabe que debe volver al login)
            cerrandoSesion = true;
            // Cierra este panel (esto dispara el evento FormClosed)
            this.Close();
        }

        /// <summary>
        /// Evento FormClosed: se ejecuta cuando el panel ya se cerró.
        /// Si fue por "Cerrar sesión", vuelve a mostrar el login limpio;
        /// si fue con la X de la ventana, cierra toda la aplicación.
        /// </summary>
        /// <param name="sender">El panel que se cerró.</param>
        /// <param name="e">Datos del cierre (por ejemplo, quién lo pidió).</param>
        private void FrmPanel_FormClosed(object sender, FormClosedEventArgs e)
        {
            // Si se presionó "Cerrar sesión"...
            if (cerrandoSesion)
            {
                // ...vuelve a mostrar el login, que estaba oculto
                formularioLogin.Show();
                // ...y lo deja como nuevo (sin perfil elegido y con las cajas vacías)
                formularioLogin.ReiniciarFormulario();
            }
            // Si se cerró con la X...
            else
            {
                // ...cierra toda la aplicación (también el login oculto)
                Application.Exit();
            }
        }
    }
}
