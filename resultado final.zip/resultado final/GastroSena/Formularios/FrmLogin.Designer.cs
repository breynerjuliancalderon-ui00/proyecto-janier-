﻿// Visual Studio regenera este archivo cuando se edita en [Diseño], y los comentarios de adentro se pueden borrar.
// Archivo: Formularios/FrmLogin.Designer.cs
// Parte "de diseño" del formulario de inicio de sesión: aquí se crean los controles (foto de fondo,
// tarjeta blanca, logo, cajas de texto, opciones de perfil y botón) y se les ponen sus propiedades.
// Para cambiar cómo se ve el login, abre FrmLogin.cs en la vista [Diseño] en vez de editar este archivo a mano.

// Espacio de nombres de los formularios (carpeta Formularios)
namespace GastroSena.Formularios
{
    /// <summary>
    /// Segunda parte (partial) de la clase FrmLogin: contiene el código que escribe el diseñador.
    /// La otra parte, con la lógica, está en FrmLogin.cs.
    /// </summary>
    partial class FrmLogin
    {
        /// <summary>
        /// Variable del diseñador necesaria: guarda los componentes que hay que liberar al cerrar.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpia los recursos que se estén usando. Se ejecuta cuando el formulario se cierra.
        /// </summary>
        /// <param name="disposing">true si se deben liberar los recursos administrados; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            // Si se están liberando recursos y hay componentes guardados...
            if (disposing && (components != null))
            {
                // ...los libera
                components.Dispose();
            }
            // Llama al Dispose de la clase base (Form) para que termine de limpiar
            base.Dispose(disposing);
        }

        // Región con el código que escribe el Diseñador de Windows Forms
        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// Crea cada control, le asigna sus propiedades, lo agrega a su contenedor y conecta sus eventos.
        /// </summary>
        private void InitializeComponent()
        {
            // Administrador de recursos: lee del archivo FrmLogin.resx el ícono de la ventana
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmLogin));
            // Crea la imagen de fondo (foto de la cafetería)
            this.picFondo = new System.Windows.Forms.PictureBox();
            // Crea la tarjeta blanca del centro
            this.pnlTarjeta = new System.Windows.Forms.Panel();
            // Crea la franja verde de arriba de la tarjeta
            this.pnlFranjaVerde = new System.Windows.Forms.Panel();
            // Crea la imagen del logo
            this.picLogo = new System.Windows.Forms.PictureBox();
            // Crea la etiqueta del título "GastroSENA"
            this.lblTitulo = new System.Windows.Forms.Label();
            // Crea la etiqueta del subtítulo
            this.lblSubtitulo = new System.Windows.Forms.Label();
            // Crea la etiqueta "Usuario (documento)"
            this.lblUsuario = new System.Windows.Forms.Label();
            // Crea la caja de texto del usuario
            this.txtUsuario = new System.Windows.Forms.TextBox();
            // Crea la etiqueta "Contraseña"
            this.lblContrasena = new System.Windows.Forms.Label();
            // Crea la caja de texto de la contraseña
            this.txtContrasena = new System.Windows.Forms.TextBox();
            // Crea la etiqueta "Selecciona tu perfil"
            this.lblSeleccionPerfil = new System.Windows.Forms.Label();
            // Crea la tabla de 2 x 2 que ordena las cuatro opciones de perfil
            this.tlpPerfiles = new System.Windows.Forms.TableLayoutPanel();
            // Crea el recuadro de la opción Aprendiz
            this.pnlAprendiz = new System.Windows.Forms.Panel();
            // Crea el botón de opción Aprendiz
            this.rbAprendiz = new System.Windows.Forms.RadioButton();
            // Crea la frase corta de Aprendiz
            this.lblFraseAprendiz = new System.Windows.Forms.Label();
            // Crea el recuadro de la opción Instructor
            this.pnlInstructor = new System.Windows.Forms.Panel();
            // Crea el botón de opción Instructor
            this.rbInstructor = new System.Windows.Forms.RadioButton();
            // Crea la frase corta de Instructor
            this.lblFraseInstructor = new System.Windows.Forms.Label();
            // Crea el recuadro de la opción Encargado
            this.pnlEncargado = new System.Windows.Forms.Panel();
            // Crea el botón de opción Encargado
            this.rbEncargado = new System.Windows.Forms.RadioButton();
            // Crea la frase corta de Encargado
            this.lblFraseEncargado = new System.Windows.Forms.Label();
            // Crea el recuadro de la opción Invitado
            this.pnlInvitado = new System.Windows.Forms.Panel();
            // Crea el botón de opción Invitado
            this.rbInvitado = new System.Windows.Forms.RadioButton();
            // Crea la frase corta de Invitado
            this.lblFraseInvitado = new System.Windows.Forms.Label();
            // Crea el botón "Iniciar sesión"
            this.btnEntrar = new System.Windows.Forms.Button();
            // Avisa a la foto de fondo que empieza su configuración
            ((System.ComponentModel.ISupportInitialize)(this.picFondo)).BeginInit();
            // Pausa el acomodo de la tarjeta mientras se configura (así se dibuja una sola vez)
            this.pnlTarjeta.SuspendLayout();
            // Avisa al logo que empieza su configuración
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).BeginInit();
            // Pausa el acomodo de la tabla de perfiles
            this.tlpPerfiles.SuspendLayout();
            // Pausa el acomodo del recuadro Aprendiz
            this.pnlAprendiz.SuspendLayout();
            // Pausa el acomodo del recuadro Instructor
            this.pnlInstructor.SuspendLayout();
            // Pausa el acomodo del recuadro Encargado
            this.pnlEncargado.SuspendLayout();
            // Pausa el acomodo del recuadro Invitado
            this.pnlInvitado.SuspendLayout();
            // Pausa el acomodo del formulario completo
            this.SuspendLayout();
            //
            // picFondo
            // Foto de la cafetería: cubre todo el formulario y queda detrás de la tarjeta.
            // Al maximizar, el método AjustarFondo (en FrmLogin.cs) la agranda sin deformarla.
            //
            // Anclada a los cuatro bordes: en [Diseño] crece junto con el formulario
            this.picFondo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) | System.Windows.Forms.AnchorStyles.Left) | System.Windows.Forms.AnchorStyles.Right)));
            // Imagen que muestra: la foto guardada en Properties > Resources
            this.picFondo.Image = global::GastroSena.Properties.Resources.cafeteria_bg;
            // Posición: esquina superior izquierda del formulario
            this.picFondo.Location = new System.Drawing.Point(0, 0);
            // Nombre del control (con este nombre se usa en el código)
            this.picFondo.Name = "picFondo";
            // Tamaño: igual al del formulario en [Diseño]
            this.picFondo.Size = new System.Drawing.Size(1200, 720);
            // Estira la foto para llenar todo el control
            this.picFondo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            // Orden de tabulación (no recibe el foco, es solo una imagen)
            this.picFondo.TabIndex = 1;
            // La tecla Tab no se detiene en la foto
            this.picFondo.TabStop = false;
            //
            // pnlTarjeta
            // Tarjeta blanca centrada: contiene el logo, el título, los campos, los perfiles y el botón.
            //
            // Ancla "ninguna": la tarjeta se mantiene centrada cuando la ventana cambia de tamaño o se maximiza
            this.pnlTarjeta.Anchor = System.Windows.Forms.AnchorStyles.None;
            // Fondo blanco
            this.pnlTarjeta.BackColor = System.Drawing.Color.White;
            // Agrega el botón Iniciar sesión dentro de la tarjeta
            this.pnlTarjeta.Controls.Add(this.btnEntrar);
            // Agrega la tabla de perfiles dentro de la tarjeta
            this.pnlTarjeta.Controls.Add(this.tlpPerfiles);
            // Agrega la etiqueta "Selecciona tu perfil"
            this.pnlTarjeta.Controls.Add(this.lblSeleccionPerfil);
            // Agrega la caja de la contraseña
            this.pnlTarjeta.Controls.Add(this.txtContrasena);
            // Agrega la etiqueta "Contraseña"
            this.pnlTarjeta.Controls.Add(this.lblContrasena);
            // Agrega la caja del usuario
            this.pnlTarjeta.Controls.Add(this.txtUsuario);
            // Agrega la etiqueta "Usuario (documento)"
            this.pnlTarjeta.Controls.Add(this.lblUsuario);
            // Agrega el subtítulo
            this.pnlTarjeta.Controls.Add(this.lblSubtitulo);
            // Agrega el título
            this.pnlTarjeta.Controls.Add(this.lblTitulo);
            // Agrega el logo
            this.pnlTarjeta.Controls.Add(this.picLogo);
            // Agrega la franja verde de arriba
            this.pnlTarjeta.Controls.Add(this.pnlFranjaVerde);
            // Posición: centrada en el formulario de 1200 x 720
            this.pnlTarjeta.Location = new System.Drawing.Point(350, 54);
            // Nombre del control
            this.pnlTarjeta.Name = "pnlTarjeta";
            // Tamaño de la tarjeta: 500 de ancho y 612 de alto
            this.pnlTarjeta.Size = new System.Drawing.Size(500, 612);
            // Primera en el orden de tabulación (el foco empieza dentro de la tarjeta)
            this.pnlTarjeta.TabIndex = 0;
            //
            // pnlFranjaVerde
            // Franja verde SENA delgada en el borde de arriba de la tarjeta (solo decoración).
            //
            // Color verde SENA (#39A900)
            this.pnlFranjaVerde.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(169)))), ((int)(((byte)(0)))));
            // Pegada arriba, ocupando todo el ancho de la tarjeta
            this.pnlFranjaVerde.Dock = System.Windows.Forms.DockStyle.Top;
            // Posición: arriba a la izquierda de la tarjeta
            this.pnlFranjaVerde.Location = new System.Drawing.Point(0, 0);
            // Nombre del control
            this.pnlFranjaVerde.Name = "pnlFranjaVerde";
            // Alto de 6 píxeles
            this.pnlFranjaVerde.Size = new System.Drawing.Size(500, 6);
            // Orden de tabulación (no recibe el foco)
            this.pnlFranjaVerde.TabIndex = 0;
            //
            // picLogo
            // Logo de GastroSENA arriba y al centro de la tarjeta.
            //
            // Imagen: el logo guardado en Properties > Resources
            this.picLogo.Image = global::GastroSena.Properties.Resources.logo;
            // Posición: centrado horizontalmente en la tarjeta
            this.picLogo.Location = new System.Drawing.Point(206, 22);
            // Nombre del control
            this.picLogo.Name = "picLogo";
            // Tamaño: 88 x 88 píxeles
            this.picLogo.Size = new System.Drawing.Size(88, 88);
            // Zoom: achica el logo para que quepa completo sin deformarse
            this.picLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            // Orden de tabulación
            this.picLogo.TabIndex = 1;
            // La tecla Tab no se detiene en el logo
            this.picLogo.TabStop = false;
            //
            // lblTitulo
            // Título "GastroSENA": grande, en negrita y verde, centrado debajo del logo.
            //
            // Letra Segoe UI de 20 puntos en negrita
            this.lblTitulo.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Color verde SENA
            this.lblTitulo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(169)))), ((int)(((byte)(0)))));
            // Posición: debajo del logo, con 20 píxeles de margen a cada lado
            this.lblTitulo.Location = new System.Drawing.Point(20, 112);
            // Nombre del control
            this.lblTitulo.Name = "lblTitulo";
            // Tamaño: casi todo el ancho de la tarjeta
            this.lblTitulo.Size = new System.Drawing.Size(460, 40);
            // Orden de tabulación (las etiquetas no reciben el foco)
            this.lblTitulo.TabIndex = 2;
            // Texto que se muestra
            this.lblTitulo.Text = "GastroSENA";
            // Texto centrado
            this.lblTitulo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            //
            // lblSubtitulo
            // Subtítulo gris centrado debajo del título.
            //
            // Color gris
            this.lblSubtitulo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(114)))), ((int)(((byte)(128)))));
            // Posición: justo debajo del título
            this.lblSubtitulo.Location = new System.Drawing.Point(20, 152);
            // Nombre del control
            this.lblSubtitulo.Name = "lblSubtitulo";
            // Tamaño: el mismo ancho del título
            this.lblSubtitulo.Size = new System.Drawing.Size(460, 22);
            // Orden de tabulación
            this.lblSubtitulo.TabIndex = 3;
            // Texto que se muestra
            this.lblSubtitulo.Text = "Sistema de almuerzos - SENA Yamboró";
            // Texto centrado
            this.lblSubtitulo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            //
            // lblUsuario
            // Etiqueta "Usuario (documento)" encima de la caja del usuario.
            //
            // El tamaño se ajusta solo al texto
            this.lblUsuario.AutoSize = true;
            // Letra Segoe UI Semibold (un poco más gruesa que la normal)
            this.lblUsuario.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Color casi negro
            this.lblUsuario.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(41)))), ((int)(((byte)(51)))));
            // Posición: a 40 píxeles del borde izquierdo de la tarjeta
            this.lblUsuario.Location = new System.Drawing.Point(40, 192);
            // Nombre del control
            this.lblUsuario.Name = "lblUsuario";
            // Tamaño calculado por el AutoSize
            this.lblUsuario.Size = new System.Drawing.Size(134, 17);
            // Orden de tabulación
            this.lblUsuario.TabIndex = 4;
            // Texto que se muestra
            this.lblUsuario.Text = "Usuario (documento)";
            //
            // txtUsuario
            // Caja donde se escribe el número de documento. Se llena sola al elegir un perfil.
            //
            // Borde sencillo de una línea (se ve más moderno que el borde 3D)
            this.txtUsuario.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            // Letra un poco más grande para que sea fácil de leer
            this.txtUsuario.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Posición: debajo de su etiqueta
            this.txtUsuario.Location = new System.Drawing.Point(40, 212);
            // Máximo 15 caracteres (un documento no es más largo)
            this.txtUsuario.MaxLength = 15;
            // Nombre del control
            this.txtUsuario.Name = "txtUsuario";
            // Tamaño: 420 de ancho
            this.txtUsuario.Size = new System.Drawing.Size(420, 27);
            // Orden de tabulación: es el primer campo que recibe el foco
            this.txtUsuario.TabIndex = 5;
            //
            // lblContrasena
            // Etiqueta "Contraseña" encima de la caja de la contraseña.
            //
            // El tamaño se ajusta solo al texto
            this.lblContrasena.AutoSize = true;
            // Letra Segoe UI Semibold
            this.lblContrasena.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Color casi negro
            this.lblContrasena.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(41)))), ((int)(((byte)(51)))));
            // Posición: debajo de la caja del usuario
            this.lblContrasena.Location = new System.Drawing.Point(40, 252);
            // Nombre del control
            this.lblContrasena.Name = "lblContrasena";
            // Tamaño calculado por el AutoSize
            this.lblContrasena.Size = new System.Drawing.Size(73, 17);
            // Orden de tabulación
            this.lblContrasena.TabIndex = 6;
            // Texto que se muestra
            this.lblContrasena.Text = "Contraseña";
            //
            // txtContrasena
            // Caja de la contraseña: muestra puntos en vez de las letras (PasswordChar).
            //
            // Borde sencillo de una línea
            this.txtContrasena.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            // Letra un poco más grande
            this.txtContrasena.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Posición: debajo de su etiqueta
            this.txtContrasena.Location = new System.Drawing.Point(40, 272);
            // Máximo 30 caracteres
            this.txtContrasena.MaxLength = 30;
            // Nombre del control
            this.txtContrasena.Name = "txtContrasena";
            // Carácter que se muestra en lugar de cada letra de la contraseña
            this.txtContrasena.PasswordChar = '●';
            // Tamaño: 420 de ancho
            this.txtContrasena.Size = new System.Drawing.Size(420, 27);
            // Orden de tabulación
            this.txtContrasena.TabIndex = 7;
            //
            // lblSeleccionPerfil
            // Etiqueta "Selecciona tu perfil" encima de las cuatro opciones.
            //
            // El tamaño se ajusta solo al texto
            this.lblSeleccionPerfil.AutoSize = true;
            // Letra Segoe UI Semibold
            this.lblSeleccionPerfil.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Color casi negro
            this.lblSeleccionPerfil.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(41)))), ((int)(((byte)(51)))));
            // Posición: debajo de la caja de la contraseña
            this.lblSeleccionPerfil.Location = new System.Drawing.Point(40, 314);
            // Nombre del control
            this.lblSeleccionPerfil.Name = "lblSeleccionPerfil";
            // Tamaño calculado por el AutoSize
            this.lblSeleccionPerfil.Size = new System.Drawing.Size(126, 17);
            // Orden de tabulación
            this.lblSeleccionPerfil.TabIndex = 8;
            // Texto que se muestra
            this.lblSeleccionPerfil.Text = "Selecciona tu perfil";
            //
            // tlpPerfiles
            // Tabla de 2 columnas y 2 filas: ordena las cuatro opciones grandes de perfil.
            //
            // Dos columnas
            this.tlpPerfiles.ColumnCount = 2;
            // Columna 1: la mitad del ancho
            this.tlpPerfiles.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            // Columna 2: la otra mitad
            this.tlpPerfiles.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            // Aprendiz: columna 0, fila 0 (arriba a la izquierda)
            this.tlpPerfiles.Controls.Add(this.pnlAprendiz, 0, 0);
            // Instructor: columna 1, fila 0 (arriba a la derecha)
            this.tlpPerfiles.Controls.Add(this.pnlInstructor, 1, 0);
            // Encargado: columna 0, fila 1 (abajo a la izquierda)
            this.tlpPerfiles.Controls.Add(this.pnlEncargado, 0, 1);
            // Invitado: columna 1, fila 1 (abajo a la derecha)
            this.tlpPerfiles.Controls.Add(this.pnlInvitado, 1, 1);
            // Posición: debajo de "Selecciona tu perfil" (36 porque cada recuadro tiene 4 de margen)
            this.tlpPerfiles.Location = new System.Drawing.Point(36, 335);
            // Nombre del control
            this.tlpPerfiles.Name = "tlpPerfiles";
            // Dos filas
            this.tlpPerfiles.RowCount = 2;
            // Fila 1: la mitad del alto
            this.tlpPerfiles.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            // Fila 2: la otra mitad
            this.tlpPerfiles.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            // Tamaño de la tabla completa
            this.tlpPerfiles.Size = new System.Drawing.Size(428, 196);
            // Orden de tabulación
            this.tlpPerfiles.TabIndex = 9;
            //
            // pnlAprendiz
            // Recuadro de la opción Aprendiz. Al hacerle clic se elige este perfil.
            //
            // Fondo gris clarito (se pone verde al elegirlo)
            this.pnlAprendiz.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(244)))), ((int)(((byte)(238)))));
            // Agrega la frase corta dentro del recuadro
            this.pnlAprendiz.Controls.Add(this.lblFraseAprendiz);
            // Agrega el botón de opción dentro del recuadro
            this.pnlAprendiz.Controls.Add(this.rbAprendiz);
            // Puntero de mano: indica que se puede hacer clic
            this.pnlAprendiz.Cursor = System.Windows.Forms.Cursors.Hand;
            // Llena toda su celda de la tabla
            this.pnlAprendiz.Dock = System.Windows.Forms.DockStyle.Fill;
            // Posición dentro de la tabla (la calcula la tabla)
            this.pnlAprendiz.Location = new System.Drawing.Point(4, 4);
            // Separación de 4 píxeles con los otros recuadros
            this.pnlAprendiz.Margin = new System.Windows.Forms.Padding(4);
            // Nombre del control
            this.pnlAprendiz.Name = "pnlAprendiz";
            // Tamaño (lo calcula la tabla)
            this.pnlAprendiz.Size = new System.Drawing.Size(206, 90);
            // Orden de tabulación
            this.pnlAprendiz.TabIndex = 0;
            // Conecta el clic del recuadro con el método opcionPerfil_Click (en FrmLogin.cs)
            this.pnlAprendiz.Click += new System.EventHandler(this.opcionPerfil_Click);
            //
            // rbAprendiz
            // Botón de opción "Aprendiz" (nombre del perfil, en negrita).
            //
            // El tamaño se ajusta solo al texto
            this.rbAprendiz.AutoSize = true;
            // Puntero de mano
            this.rbAprendiz.Cursor = System.Windows.Forms.Cursors.Hand;
            // Letra Segoe UI de 11 puntos en negrita
            this.rbAprendiz.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Color casi negro (se pone blanco al elegirlo)
            this.rbAprendiz.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(41)))), ((int)(((byte)(51)))));
            // Posición: arriba a la izquierda del recuadro
            this.rbAprendiz.Location = new System.Drawing.Point(12, 10);
            // Nombre del control
            this.rbAprendiz.Name = "rbAprendiz";
            // Tamaño calculado por el AutoSize
            this.rbAprendiz.Size = new System.Drawing.Size(92, 24);
            // Orden de tabulación
            this.rbAprendiz.TabIndex = 0;
            // La tecla Tab se puede detener aquí
            this.rbAprendiz.TabStop = true;
            // Texto que se muestra
            this.rbAprendiz.Text = "Aprendiz";
            // Usa el estilo visual de Windows para el circulito
            this.rbAprendiz.UseVisualStyleBackColor = true;
            // Conecta el cambio de marcado con el método rbPerfil_CheckedChanged (en FrmLogin.cs)
            this.rbAprendiz.CheckedChanged += new System.EventHandler(this.rbPerfil_CheckedChanged);
            //
            // lblFraseAprendiz
            // Frase corta que explica el perfil Aprendiz. Al hacerle clic también se elige.
            //
            // Puntero de mano
            this.lblFraseAprendiz.Cursor = System.Windows.Forms.Cursors.Hand;
            // Letra Segoe UI de 9 puntos
            this.lblFraseAprendiz.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Color gris (se pone blanco al elegirlo)
            this.lblFraseAprendiz.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(114)))), ((int)(((byte)(128)))));
            // Posición: debajo del nombre del perfil
            this.lblFraseAprendiz.Location = new System.Drawing.Point(14, 38);
            // Nombre del control
            this.lblFraseAprendiz.Name = "lblFraseAprendiz";
            // Tamaño fijo: si la frase es larga, pasa a una segunda línea
            this.lblFraseAprendiz.Size = new System.Drawing.Size(182, 44);
            // Orden de tabulación
            this.lblFraseAprendiz.TabIndex = 1;
            // Texto que se muestra
            this.lblFraseAprendiz.Text = "Consulta tus fichas y deja sugerencias";
            // Conecta el clic de la frase con el método opcionPerfil_Click
            this.lblFraseAprendiz.Click += new System.EventHandler(this.opcionPerfil_Click);
            //
            // pnlInstructor
            // Recuadro de la opción Instructor. Al hacerle clic se elige este perfil.
            //
            // Fondo gris clarito (se pone verde al elegirlo)
            this.pnlInstructor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(244)))), ((int)(((byte)(238)))));
            // Agrega la frase corta dentro del recuadro
            this.pnlInstructor.Controls.Add(this.lblFraseInstructor);
            // Agrega el botón de opción dentro del recuadro
            this.pnlInstructor.Controls.Add(this.rbInstructor);
            // Puntero de mano
            this.pnlInstructor.Cursor = System.Windows.Forms.Cursors.Hand;
            // Llena toda su celda de la tabla
            this.pnlInstructor.Dock = System.Windows.Forms.DockStyle.Fill;
            // Posición dentro de la tabla (la calcula la tabla)
            this.pnlInstructor.Location = new System.Drawing.Point(218, 4);
            // Separación de 4 píxeles con los otros recuadros
            this.pnlInstructor.Margin = new System.Windows.Forms.Padding(4);
            // Nombre del control
            this.pnlInstructor.Name = "pnlInstructor";
            // Tamaño (lo calcula la tabla)
            this.pnlInstructor.Size = new System.Drawing.Size(206, 90);
            // Orden de tabulación
            this.pnlInstructor.TabIndex = 1;
            // Conecta el clic del recuadro con el método opcionPerfil_Click
            this.pnlInstructor.Click += new System.EventHandler(this.opcionPerfil_Click);
            //
            // rbInstructor
            // Botón de opción "Instructor".
            //
            // El tamaño se ajusta solo al texto
            this.rbInstructor.AutoSize = true;
            // Puntero de mano
            this.rbInstructor.Cursor = System.Windows.Forms.Cursors.Hand;
            // Letra Segoe UI de 11 puntos en negrita
            this.rbInstructor.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Color casi negro (se pone blanco al elegirlo)
            this.rbInstructor.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(41)))), ((int)(((byte)(51)))));
            // Posición: arriba a la izquierda del recuadro
            this.rbInstructor.Location = new System.Drawing.Point(12, 10);
            // Nombre del control
            this.rbInstructor.Name = "rbInstructor";
            // Tamaño calculado por el AutoSize
            this.rbInstructor.Size = new System.Drawing.Size(104, 24);
            // Orden de tabulación
            this.rbInstructor.TabIndex = 0;
            // La tecla Tab se puede detener aquí
            this.rbInstructor.TabStop = true;
            // Texto que se muestra
            this.rbInstructor.Text = "Instructor";
            // Usa el estilo visual de Windows para el circulito
            this.rbInstructor.UseVisualStyleBackColor = true;
            // Conecta el cambio de marcado con el método rbPerfil_CheckedChanged
            this.rbInstructor.CheckedChanged += new System.EventHandler(this.rbPerfil_CheckedChanged);
            //
            // lblFraseInstructor
            // Frase corta que explica el perfil Instructor.
            //
            // Puntero de mano
            this.lblFraseInstructor.Cursor = System.Windows.Forms.Cursors.Hand;
            // Letra Segoe UI de 9 puntos
            this.lblFraseInstructor.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Color gris (se pone blanco al elegirlo)
            this.lblFraseInstructor.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(114)))), ((int)(((byte)(128)))));
            // Posición: debajo del nombre del perfil
            this.lblFraseInstructor.Location = new System.Drawing.Point(14, 38);
            // Nombre del control
            this.lblFraseInstructor.Name = "lblFraseInstructor";
            // Tamaño fijo con espacio para dos líneas
            this.lblFraseInstructor.Size = new System.Drawing.Size(182, 44);
            // Orden de tabulación
            this.lblFraseInstructor.TabIndex = 1;
            // Texto que se muestra
            this.lblFraseInstructor.Text = "Revisa tu cuenta y tus consumos";
            // Conecta el clic de la frase con el método opcionPerfil_Click
            this.lblFraseInstructor.Click += new System.EventHandler(this.opcionPerfil_Click);
            //
            // pnlEncargado
            // Recuadro de la opción Encargado. Al hacerle clic se elige este perfil.
            //
            // Fondo gris clarito (se pone verde al elegirlo)
            this.pnlEncargado.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(244)))), ((int)(((byte)(238)))));
            // Agrega la frase corta dentro del recuadro
            this.pnlEncargado.Controls.Add(this.lblFraseEncargado);
            // Agrega el botón de opción dentro del recuadro
            this.pnlEncargado.Controls.Add(this.rbEncargado);
            // Puntero de mano
            this.pnlEncargado.Cursor = System.Windows.Forms.Cursors.Hand;
            // Llena toda su celda de la tabla
            this.pnlEncargado.Dock = System.Windows.Forms.DockStyle.Fill;
            // Posición dentro de la tabla (la calcula la tabla)
            this.pnlEncargado.Location = new System.Drawing.Point(4, 102);
            // Separación de 4 píxeles con los otros recuadros
            this.pnlEncargado.Margin = new System.Windows.Forms.Padding(4);
            // Nombre del control
            this.pnlEncargado.Name = "pnlEncargado";
            // Tamaño (lo calcula la tabla)
            this.pnlEncargado.Size = new System.Drawing.Size(206, 90);
            // Orden de tabulación
            this.pnlEncargado.TabIndex = 2;
            // Conecta el clic del recuadro con el método opcionPerfil_Click
            this.pnlEncargado.Click += new System.EventHandler(this.opcionPerfil_Click);
            //
            // rbEncargado
            // Botón de opción "Encargado".
            //
            // El tamaño se ajusta solo al texto
            this.rbEncargado.AutoSize = true;
            // Puntero de mano
            this.rbEncargado.Cursor = System.Windows.Forms.Cursors.Hand;
            // Letra Segoe UI de 11 puntos en negrita
            this.rbEncargado.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Color casi negro (se pone blanco al elegirlo)
            this.rbEncargado.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(41)))), ((int)(((byte)(51)))));
            // Posición: arriba a la izquierda del recuadro
            this.rbEncargado.Location = new System.Drawing.Point(12, 10);
            // Nombre del control
            this.rbEncargado.Name = "rbEncargado";
            // Tamaño calculado por el AutoSize
            this.rbEncargado.Size = new System.Drawing.Size(106, 24);
            // Orden de tabulación
            this.rbEncargado.TabIndex = 0;
            // La tecla Tab se puede detener aquí
            this.rbEncargado.TabStop = true;
            // Texto que se muestra
            this.rbEncargado.Text = "Encargado";
            // Usa el estilo visual de Windows para el circulito
            this.rbEncargado.UseVisualStyleBackColor = true;
            // Conecta el cambio de marcado con el método rbPerfil_CheckedChanged
            this.rbEncargado.CheckedChanged += new System.EventHandler(this.rbPerfil_CheckedChanged);
            //
            // lblFraseEncargado
            // Frase corta que explica el perfil Encargado.
            //
            // Puntero de mano
            this.lblFraseEncargado.Cursor = System.Windows.Forms.Cursors.Hand;
            // Letra Segoe UI de 9 puntos
            this.lblFraseEncargado.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Color gris (se pone blanco al elegirlo)
            this.lblFraseEncargado.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(114)))), ((int)(((byte)(128)))));
            // Posición: debajo del nombre del perfil
            this.lblFraseEncargado.Location = new System.Drawing.Point(14, 38);
            // Nombre del control
            this.lblFraseEncargado.Name = "lblFraseEncargado";
            // Tamaño fijo con espacio para dos líneas
            this.lblFraseEncargado.Size = new System.Drawing.Size(182, 44);
            // Orden de tabulación
            this.lblFraseEncargado.TabIndex = 1;
            // Texto que se muestra
            this.lblFraseEncargado.Text = "Administra ventas, menú e inventario";
            // Conecta el clic de la frase con el método opcionPerfil_Click
            this.lblFraseEncargado.Click += new System.EventHandler(this.opcionPerfil_Click);
            //
            // pnlInvitado
            // Recuadro de la opción Invitado. Al hacerle clic se elige este perfil.
            //
            // Fondo gris clarito (se pone verde al elegirlo)
            this.pnlInvitado.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(244)))), ((int)(((byte)(238)))));
            // Agrega la frase corta dentro del recuadro
            this.pnlInvitado.Controls.Add(this.lblFraseInvitado);
            // Agrega el botón de opción dentro del recuadro
            this.pnlInvitado.Controls.Add(this.rbInvitado);
            // Puntero de mano
            this.pnlInvitado.Cursor = System.Windows.Forms.Cursors.Hand;
            // Llena toda su celda de la tabla
            this.pnlInvitado.Dock = System.Windows.Forms.DockStyle.Fill;
            // Posición dentro de la tabla (la calcula la tabla)
            this.pnlInvitado.Location = new System.Drawing.Point(218, 102);
            // Separación de 4 píxeles con los otros recuadros
            this.pnlInvitado.Margin = new System.Windows.Forms.Padding(4);
            // Nombre del control
            this.pnlInvitado.Name = "pnlInvitado";
            // Tamaño (lo calcula la tabla)
            this.pnlInvitado.Size = new System.Drawing.Size(206, 90);
            // Orden de tabulación
            this.pnlInvitado.TabIndex = 3;
            // Conecta el clic del recuadro con el método opcionPerfil_Click
            this.pnlInvitado.Click += new System.EventHandler(this.opcionPerfil_Click);
            //
            // rbInvitado
            // Botón de opción "Invitado".
            //
            // El tamaño se ajusta solo al texto
            this.rbInvitado.AutoSize = true;
            // Puntero de mano
            this.rbInvitado.Cursor = System.Windows.Forms.Cursors.Hand;
            // Letra Segoe UI de 11 puntos en negrita
            this.rbInvitado.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Color casi negro (se pone blanco al elegirlo)
            this.rbInvitado.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(41)))), ((int)(((byte)(51)))));
            // Posición: arriba a la izquierda del recuadro
            this.rbInvitado.Location = new System.Drawing.Point(12, 10);
            // Nombre del control
            this.rbInvitado.Name = "rbInvitado";
            // Tamaño calculado por el AutoSize
            this.rbInvitado.Size = new System.Drawing.Size(88, 24);
            // Orden de tabulación
            this.rbInvitado.TabIndex = 0;
            // La tecla Tab se puede detener aquí
            this.rbInvitado.TabStop = true;
            // Texto que se muestra
            this.rbInvitado.Text = "Invitado";
            // Usa el estilo visual de Windows para el circulito
            this.rbInvitado.UseVisualStyleBackColor = true;
            // Conecta el cambio de marcado con el método rbPerfil_CheckedChanged
            this.rbInvitado.CheckedChanged += new System.EventHandler(this.rbPerfil_CheckedChanged);
            //
            // lblFraseInvitado
            // Frase corta que explica el perfil Invitado.
            //
            // Puntero de mano
            this.lblFraseInvitado.Cursor = System.Windows.Forms.Cursors.Hand;
            // Letra Segoe UI de 9 puntos
            this.lblFraseInvitado.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Color gris (se pone blanco al elegirlo)
            this.lblFraseInvitado.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(114)))), ((int)(((byte)(128)))));
            // Posición: debajo del nombre del perfil
            this.lblFraseInvitado.Location = new System.Drawing.Point(14, 38);
            // Nombre del control
            this.lblFraseInvitado.Name = "lblFraseInvitado";
            // Tamaño fijo con espacio para dos líneas
            this.lblFraseInvitado.Size = new System.Drawing.Size(182, 44);
            // Orden de tabulación
            this.lblFraseInvitado.TabIndex = 1;
            // Texto que se muestra
            this.lblFraseInvitado.Text = "Entra como visitante y deja sugerencias";
            // Conecta el clic de la frase con el método opcionPerfil_Click
            this.lblFraseInvitado.Click += new System.EventHandler(this.opcionPerfil_Click);
            //
            // btnEntrar
            // Botón "Iniciar sesión": ancho, abajo de la tarjeta. Empieza deshabilitado y gris;
            // se habilita y se pone verde SENA cuando se elige un perfil (ver btnEntrar_EnabledChanged).
            //
            // Fondo gris de botón deshabilitado
            this.btnEntrar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(206)))), ((int)(((byte)(192)))));
            // Puntero de mano
            this.btnEntrar.Cursor = System.Windows.Forms.Cursors.Hand;
            // Empieza deshabilitado: no se puede presionar hasta elegir un perfil
            this.btnEntrar.Enabled = false;
            // Sin borde
            this.btnEntrar.FlatAppearance.BorderSize = 0;
            // Verde más oscuro mientras se mantiene presionado
            this.btnEntrar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(115)))), ((int)(((byte)(0)))));
            // Verde oscuro al pasar el mouse por encima
            this.btnEntrar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(0)))));
            // Estilo plano (Flat): sin el relieve de los botones normales de Windows
            this.btnEntrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            // Letra Segoe UI de 11 puntos en negrita
            this.btnEntrar.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Letra blanca
            this.btnEntrar.ForeColor = System.Drawing.Color.White;
            // Posición: debajo de las opciones de perfil
            this.btnEntrar.Location = new System.Drawing.Point(40, 545);
            // Nombre del control
            this.btnEntrar.Name = "btnEntrar";
            // Tamaño: mismo ancho que las cajas de texto y 44 de alto
            this.btnEntrar.Size = new System.Drawing.Size(420, 44);
            // Orden de tabulación: último de la tarjeta
            this.btnEntrar.TabIndex = 10;
            // Texto del botón
            this.btnEntrar.Text = "Iniciar sesión";
            // Usa el BackColor que pusimos, no el color del tema de Windows
            this.btnEntrar.UseVisualStyleBackColor = false;
            // Conecta el clic del botón con el método btnEntrar_Click (en FrmLogin.cs)
            this.btnEntrar.Click += new System.EventHandler(this.btnEntrar_Click);
            // Conecta el cambio de habilitado con el método btnEntrar_EnabledChanged (lo pinta verde o gris)
            this.btnEntrar.EnabledChanged += new System.EventHandler(this.btnEntrar_EnabledChanged);
            //
            // FrmLogin
            // El formulario de inicio de sesión: abre maximizado, con el ícono del logo y el título "GastroSENA".
            //
            // Al presionar Enter se hace clic en Iniciar sesión
            this.AcceptButton = this.btnEntrar;
            // Tamaño de letra con el que se diseñó (sirve para escalar si cambia la fuente o el DPI)
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            // Escala los controles según la fuente
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            // Fondo gris muy claro (casi no se ve, porque la foto lo cubre)
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(245)))), ((int)(((byte)(241)))));
            // Tamaño del área interior cuando la ventana no está maximizada
            this.ClientSize = new System.Drawing.Size(1200, 720);
            // Agrega la tarjeta al formulario (queda delante de la foto)
            this.Controls.Add(this.pnlTarjeta);
            // Agrega la foto de fondo al formulario (queda detrás de todo)
            this.Controls.Add(this.picFondo);
            // Dibuja en memoria antes de mostrar, para evitar parpadeos al cambiar de tamaño
            this.DoubleBuffered = true;
            // Fuente de todo el formulario: Segoe UI de 9.75 puntos (los controles la heredan)
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Ícono de la ventana (hecho con el logo), leído de FrmLogin.resx
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            // Tamaño mínimo: así la tarjeta siempre cabe completa
            this.MinimumSize = new System.Drawing.Size(600, 700);
            // Nombre del formulario
            this.Name = "FrmLogin";
            // Si se restaura, aparece en el centro de la pantalla
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            // Título de la ventana
            this.Text = "GastroSENA";
            // Abre maximizado
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            // Conecta el evento Load con el método FrmLogin_Load (en FrmLogin.cs)
            this.Load += new System.EventHandler(this.FrmLogin_Load);
            // Conecta el evento Resize con el método FrmLogin_Resize (acomoda la foto al cambiar de tamaño)
            this.Resize += new System.EventHandler(this.FrmLogin_Resize);
            // Termina la configuración de la foto de fondo
            ((System.ComponentModel.ISupportInitialize)(this.picFondo)).EndInit();
            // Reanuda el acomodo de la tarjeta
            this.pnlTarjeta.ResumeLayout(false);
            // Acomoda ya los controles de la tarjeta
            this.pnlTarjeta.PerformLayout();
            // Termina la configuración del logo
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).EndInit();
            // Reanuda el acomodo de la tabla de perfiles
            this.tlpPerfiles.ResumeLayout(false);
            // Reanuda el acomodo del recuadro Aprendiz
            this.pnlAprendiz.ResumeLayout(false);
            // Acomoda ya los controles del recuadro Aprendiz
            this.pnlAprendiz.PerformLayout();
            // Reanuda el acomodo del recuadro Instructor
            this.pnlInstructor.ResumeLayout(false);
            // Acomoda ya los controles del recuadro Instructor
            this.pnlInstructor.PerformLayout();
            // Reanuda el acomodo del recuadro Encargado
            this.pnlEncargado.ResumeLayout(false);
            // Acomoda ya los controles del recuadro Encargado
            this.pnlEncargado.PerformLayout();
            // Reanuda el acomodo del recuadro Invitado
            this.pnlInvitado.ResumeLayout(false);
            // Acomoda ya los controles del recuadro Invitado
            this.pnlInvitado.PerformLayout();
            // Reanuda el acomodo del formulario completo
            this.ResumeLayout(false);

        }

        // Fin de la región del diseñador
        #endregion

        // Foto de la cafetería que cubre el fondo
        private System.Windows.Forms.PictureBox picFondo;
        // Tarjeta blanca centrada
        private System.Windows.Forms.Panel pnlTarjeta;
        // Franja verde decorativa arriba de la tarjeta
        private System.Windows.Forms.Panel pnlFranjaVerde;
        // Logo de GastroSENA
        private System.Windows.Forms.PictureBox picLogo;
        // Título "GastroSENA"
        private System.Windows.Forms.Label lblTitulo;
        // Subtítulo "Sistema de almuerzos - SENA Yamboró"
        private System.Windows.Forms.Label lblSubtitulo;
        // Etiqueta "Usuario (documento)"
        private System.Windows.Forms.Label lblUsuario;
        // Caja de texto del usuario (documento)
        private System.Windows.Forms.TextBox txtUsuario;
        // Etiqueta "Contraseña"
        private System.Windows.Forms.Label lblContrasena;
        // Caja de texto de la contraseña
        private System.Windows.Forms.TextBox txtContrasena;
        // Etiqueta "Selecciona tu perfil"
        private System.Windows.Forms.Label lblSeleccionPerfil;
        // Tabla de 2 x 2 con las opciones de perfil
        private System.Windows.Forms.TableLayoutPanel tlpPerfiles;
        // Recuadro de la opción Aprendiz
        private System.Windows.Forms.Panel pnlAprendiz;
        // Botón de opción Aprendiz
        private System.Windows.Forms.RadioButton rbAprendiz;
        // Frase corta de Aprendiz
        private System.Windows.Forms.Label lblFraseAprendiz;
        // Recuadro de la opción Instructor
        private System.Windows.Forms.Panel pnlInstructor;
        // Botón de opción Instructor
        private System.Windows.Forms.RadioButton rbInstructor;
        // Frase corta de Instructor
        private System.Windows.Forms.Label lblFraseInstructor;
        // Recuadro de la opción Encargado
        private System.Windows.Forms.Panel pnlEncargado;
        // Botón de opción Encargado
        private System.Windows.Forms.RadioButton rbEncargado;
        // Frase corta de Encargado
        private System.Windows.Forms.Label lblFraseEncargado;
        // Recuadro de la opción Invitado
        private System.Windows.Forms.Panel pnlInvitado;
        // Botón de opción Invitado
        private System.Windows.Forms.RadioButton rbInvitado;
        // Frase corta de Invitado
        private System.Windows.Forms.Label lblFraseInvitado;
        // Botón "Iniciar sesión"
        private System.Windows.Forms.Button btnEntrar;
    }
}
