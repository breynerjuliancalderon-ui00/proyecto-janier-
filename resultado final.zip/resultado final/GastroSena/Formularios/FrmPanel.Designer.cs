﻿// Visual Studio regenera este archivo cuando se edita en [Diseño], y los comentarios de adentro se pueden borrar.
// Archivo: Formularios/FrmPanel.Designer.cs
// Parte "de diseño" del panel principal: aquí se crean el menú lateral verde con sus botones,
// el encabezado (nombre, perfil y "Cerrar sesión") y el área de contenido donde se cargan las secciones.
// Para cambiar cómo se ve el panel, abre FrmPanel.cs en la vista [Diseño].

// Espacio de nombres de los formularios (carpeta Formularios)
namespace GastroSena.Formularios
{
    /// <summary>
    /// Segunda parte (partial) de la clase FrmPanel: contiene el código que escribe el diseñador.
    /// La otra parte, con la lógica, está en FrmPanel.cs.
    /// </summary>
    partial class FrmPanel
    {
        /// <summary>
        /// Variable del diseñador necesaria: guarda los componentes que hay que liberar al cerrar.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpia los recursos que se estén usando. Se ejecuta cuando el panel se cierra.
        /// </summary>
        /// <param name="disposing">true si se deben liberar los recursos administrados; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            // Si se están liberando recursos y hay componentes guardados...
            if (disposing && (components != null))
            {
                // ...los libera
                components.Dispose();
            }
            // Llama al Dispose de la clase base (Form) para que termine de limpiar
            base.Dispose(disposing);
        }

        // Región con el código que escribe el Diseñador de Windows Forms
        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// Crea cada control, le asigna sus propiedades, lo agrega a su contenedor y conecta sus eventos.
        /// </summary>
        private void InitializeComponent()
        {
            // Administrador de recursos: lee del archivo FrmPanel.resx el ícono de la ventana
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmPanel));
            // Crea el menú lateral verde
            this.pnlMenu = new System.Windows.Forms.Panel();
            // Crea la lista de botones del menú (los acomoda uno debajo del otro)
            this.flpMenu = new System.Windows.Forms.FlowLayoutPanel();
            // Crea el botón "Inicio" del menú
            this.btnInicio = new System.Windows.Forms.Button();
            // Crea el botón "Mis Fichas" del menú
            this.btnMisFichas = new System.Windows.Forms.Button();
            // Crea el botón "Mi Cuenta" del menú
            this.btnMiCuenta = new System.Windows.Forms.Button();
            // Crea el botón "Consumos" del menú
            this.btnConsumos = new System.Windows.Forms.Button();
            // Crea el botón "Ventas" del menú
            this.btnVentas = new System.Windows.Forms.Button();
            // Crea el botón "Menú del Día" del menú
            this.btnMenuDelDia = new System.Windows.Forms.Button();
            // Crea el botón "Beneficiarios" del menú
            this.btnBeneficiarios = new System.Windows.Forms.Button();
            // Crea el botón "Cartera de Deudas" del menú
            this.btnCarteraDeudas = new System.Windows.Forms.Button();
            // Crea el botón "Inventario" del menú
            this.btnInventario = new System.Windows.Forms.Button();
            // Crea el botón "Grupos" del menú
            this.btnGrupos = new System.Windows.Forms.Button();
            // Crea el botón "Visitas Institucionales" del menú
            this.btnVisitasInstitucionales = new System.Windows.Forms.Button();
            // Crea el botón "Solicitudes de Cuenta" del menú
            this.btnSolicitudesCuenta = new System.Windows.Forms.Button();
            // Crea el botón "Buzón de Sugerencias" del menú
            this.btnBuzonSugerencias = new System.Windows.Forms.Button();
            // Crea el botón "Perfil" del menú
            this.btnPerfil = new System.Windows.Forms.Button();
            // Crea el recuadro blanco de la marca (arriba del menú)
            this.pnlMarca = new System.Windows.Forms.Panel();
            // Crea la línea gris de abajo de la marca
            this.pnlLineaMarca = new System.Windows.Forms.Panel();
            // Crea la etiqueta "SENA Yamboró"
            this.lblMarcaSubtitulo = new System.Windows.Forms.Label();
            // Crea la etiqueta "GastroSENA"
            this.lblMarca = new System.Windows.Forms.Label();
            // Crea el logo pequeño del menú
            this.picLogoMenu = new System.Windows.Forms.PictureBox();
            // Crea el encabezado blanco de arriba
            this.pnlEncabezado = new System.Windows.Forms.Panel();
            // Crea el botón "Cerrar sesión"
            this.btnCerrarSesion = new System.Windows.Forms.Button();
            // Crea la etiqueta del perfil
            this.lblPerfil = new System.Windows.Forms.Label();
            // Crea la etiqueta del nombre del usuario
            this.lblNombreUsuario = new System.Windows.Forms.Label();
            // Crea la línea gris de abajo del encabezado
            this.pnlLineaEncabezado = new System.Windows.Forms.Panel();
            // Crea el área de contenido donde se cargan las secciones
            this.pnlContenido = new System.Windows.Forms.Panel();
            // Pausa el acomodo del menú lateral mientras se configura
            this.pnlMenu.SuspendLayout();
            // Pausa el acomodo de la lista de botones
            this.flpMenu.SuspendLayout();
            // Pausa el acomodo del recuadro de la marca
            this.pnlMarca.SuspendLayout();
            // Avisa al logo que empieza su configuración
            ((System.ComponentModel.ISupportInitialize)(this.picLogoMenu)).BeginInit();
            // Pausa el acomodo del encabezado
            this.pnlEncabezado.SuspendLayout();
            // Pausa el acomodo del formulario completo
            this.SuspendLayout();
            //
            // pnlMenu
            // Menú lateral verde SENA a la izquierda, de arriba a abajo. Contiene la marca y los botones.
            //
            // Color verde SENA (#39A900)
            this.pnlMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(169)))), ((int)(((byte)(0)))));
            // Agrega la lista de botones (primero, para que su Dock Fill se acomode al final)
            this.pnlMenu.Controls.Add(this.flpMenu);
            // Agrega el recuadro de la marca (queda arriba con Dock Top)
            this.pnlMenu.Controls.Add(this.pnlMarca);
            // Pegado a la izquierda, ocupando todo el alto
            this.pnlMenu.Dock = System.Windows.Forms.DockStyle.Left;
            // Posición: esquina superior izquierda
            this.pnlMenu.Location = new System.Drawing.Point(0, 0);
            // Nombre del control
            this.pnlMenu.Name = "pnlMenu";
            // Ancho de 240 píxeles
            this.pnlMenu.Size = new System.Drawing.Size(240, 720);
            // Orden de tabulación: primero el menú
            this.pnlMenu.TabIndex = 0;
            //
            // flpMenu
            // Lista de botones del menú: los pone uno debajo del otro. Los botones ocultos no dejan hueco.
            //
            // Muestra una barra de desplazamiento si los botones no caben
            this.flpMenu.AutoScroll = true;
            // Agrega el botón "Inicio" al menú (los botones se acomodan en este orden)
            this.flpMenu.Controls.Add(this.btnInicio);
            // Agrega el botón "Mis Fichas" al menú (los botones se acomodan en este orden)
            this.flpMenu.Controls.Add(this.btnMisFichas);
            // Agrega el botón "Mi Cuenta" al menú (los botones se acomodan en este orden)
            this.flpMenu.Controls.Add(this.btnMiCuenta);
            // Agrega el botón "Consumos" al menú (los botones se acomodan en este orden)
            this.flpMenu.Controls.Add(this.btnConsumos);
            // Agrega el botón "Ventas" al menú (los botones se acomodan en este orden)
            this.flpMenu.Controls.Add(this.btnVentas);
            // Agrega el botón "Menú del Día" al menú (los botones se acomodan en este orden)
            this.flpMenu.Controls.Add(this.btnMenuDelDia);
            // Agrega el botón "Beneficiarios" al menú (los botones se acomodan en este orden)
            this.flpMenu.Controls.Add(this.btnBeneficiarios);
            // Agrega el botón "Cartera de Deudas" al menú (los botones se acomodan en este orden)
            this.flpMenu.Controls.Add(this.btnCarteraDeudas);
            // Agrega el botón "Inventario" al menú (los botones se acomodan en este orden)
            this.flpMenu.Controls.Add(this.btnInventario);
            // Agrega el botón "Grupos" al menú (los botones se acomodan en este orden)
            this.flpMenu.Controls.Add(this.btnGrupos);
            // Agrega el botón "Visitas Institucionales" al menú (los botones se acomodan en este orden)
            this.flpMenu.Controls.Add(this.btnVisitasInstitucionales);
            // Agrega el botón "Solicitudes de Cuenta" al menú (los botones se acomodan en este orden)
            this.flpMenu.Controls.Add(this.btnSolicitudesCuenta);
            // Agrega el botón "Buzón de Sugerencias" al menú (los botones se acomodan en este orden)
            this.flpMenu.Controls.Add(this.btnBuzonSugerencias);
            // Agrega el botón "Perfil" al menú (los botones se acomodan en este orden)
            this.flpMenu.Controls.Add(this.btnPerfil);
            // Ocupa todo el espacio del menú debajo de la marca
            this.flpMenu.Dock = System.Windows.Forms.DockStyle.Fill;
            // De arriba hacia abajo
            this.flpMenu.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            // Posición: debajo de la marca
            this.flpMenu.Location = new System.Drawing.Point(0, 72);
            // Nombre del control
            this.flpMenu.Name = "flpMenu";
            // Margen interior: 12 a los lados, 16 arriba y 12 abajo
            this.flpMenu.Padding = new System.Windows.Forms.Padding(12, 16, 12, 12);
            // Tamaño (lo calcula el Dock)
            this.flpMenu.Size = new System.Drawing.Size(240, 648);
            // Orden de tabulación
            this.flpMenu.TabIndex = 1;
            // No pasa los botones a otra columna: todos quedan en una sola
            this.flpMenu.WrapContents = false;
            //
            // btnInicio
            // Botón "Inicio" del menú lateral (lo ven todos los perfiles; abre la bienvenida). Verde y plano; el activo se pone blanco.
            //
            // Fondo verde SENA, igual al menú
            this.btnInicio.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(169)))), ((int)(((byte)(0)))));
            // Puntero de mano al pasar por encima
            this.btnInicio.Cursor = System.Windows.Forms.Cursors.Hand;
            // Sin borde
            this.btnInicio.FlatAppearance.BorderSize = 0;
            // Verde más oscuro mientras se mantiene presionado
            this.btnInicio.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(115)))), ((int)(((byte)(0)))));
            // Verde oscuro al pasar el mouse
            this.btnInicio.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(0)))));
            // Estilo plano (Flat): sin el relieve de los botones normales de Windows
            this.btnInicio.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            // Letra Segoe UI de 11 puntos
            this.btnInicio.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Letra blanca
            this.btnInicio.ForeColor = System.Drawing.Color.White;
            // Posición: el primero del menú (el FlowLayoutPanel la calcula solo)
            this.btnInicio.Location = new System.Drawing.Point(12, 16);
            // Separación de 4 píxeles con el botón de abajo
            this.btnInicio.Margin = new System.Windows.Forms.Padding(0, 0, 0, 4);
            // Nombre del control (con este nombre se usa en FrmPanel.cs)
            this.btnInicio.Name = "btnInicio";
            // Espacio a la izquierda para que el texto no quede pegado al borde
            this.btnInicio.Padding = new System.Windows.Forms.Padding(14, 0, 0, 0);
            // Tamaño: 216 de ancho y 44 de alto
            this.btnInicio.Size = new System.Drawing.Size(216, 44);
            // Orden de tabulación dentro del menú
            this.btnInicio.TabIndex = 0;
            // Texto del botón
            this.btnInicio.Text = "Inicio";
            // Texto a la izquierda y centrado de arriba a abajo
            this.btnInicio.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // Usa el BackColor que pusimos, no el color del tema de Windows
            this.btnInicio.UseVisualStyleBackColor = false;
            // Conecta el clic con el método btnInicio_Click (en FrmPanel.cs)
            this.btnInicio.Click += new System.EventHandler(this.btnInicio_Click);
            //
            // btnMisFichas
            // Botón "Mis Fichas" del menú lateral (solo el aprendiz). Verde y plano; el activo se pone blanco.
            //
            // Fondo verde SENA, igual al menú
            this.btnMisFichas.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(169)))), ((int)(((byte)(0)))));
            // Puntero de mano al pasar por encima
            this.btnMisFichas.Cursor = System.Windows.Forms.Cursors.Hand;
            // Sin borde
            this.btnMisFichas.FlatAppearance.BorderSize = 0;
            // Verde más oscuro mientras se mantiene presionado
            this.btnMisFichas.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(115)))), ((int)(((byte)(0)))));
            // Verde oscuro al pasar el mouse
            this.btnMisFichas.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(0)))));
            // Estilo plano (Flat): sin el relieve de los botones normales de Windows
            this.btnMisFichas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            // Letra Segoe UI de 11 puntos
            this.btnMisFichas.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Letra blanca
            this.btnMisFichas.ForeColor = System.Drawing.Color.White;
            // Posición: debajo del botón anterior (el FlowLayoutPanel la calcula solo)
            this.btnMisFichas.Location = new System.Drawing.Point(12, 64);
            // Separación de 4 píxeles con el botón de abajo
            this.btnMisFichas.Margin = new System.Windows.Forms.Padding(0, 0, 0, 4);
            // Nombre del control (con este nombre se usa en FrmPanel.cs)
            this.btnMisFichas.Name = "btnMisFichas";
            // Espacio a la izquierda para que el texto no quede pegado al borde
            this.btnMisFichas.Padding = new System.Windows.Forms.Padding(14, 0, 0, 0);
            // Tamaño: 216 de ancho y 44 de alto
            this.btnMisFichas.Size = new System.Drawing.Size(216, 44);
            // Orden de tabulación dentro del menú
            this.btnMisFichas.TabIndex = 1;
            // Texto del botón
            this.btnMisFichas.Text = "Mis Fichas";
            // Texto a la izquierda y centrado de arriba a abajo
            this.btnMisFichas.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // Usa el BackColor que pusimos, no el color del tema de Windows
            this.btnMisFichas.UseVisualStyleBackColor = false;
            // Conecta el clic con el método btnMisFichas_Click (en FrmPanel.cs)
            this.btnMisFichas.Click += new System.EventHandler(this.btnMisFichas_Click);
            //
            // btnMiCuenta
            // Botón "Mi Cuenta" del menú lateral (solo el instructor). Verde y plano; el activo se pone blanco.
            //
            // Fondo verde SENA, igual al menú
            this.btnMiCuenta.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(169)))), ((int)(((byte)(0)))));
            // Puntero de mano al pasar por encima
            this.btnMiCuenta.Cursor = System.Windows.Forms.Cursors.Hand;
            // Sin borde
            this.btnMiCuenta.FlatAppearance.BorderSize = 0;
            // Verde más oscuro mientras se mantiene presionado
            this.btnMiCuenta.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(115)))), ((int)(((byte)(0)))));
            // Verde oscuro al pasar el mouse
            this.btnMiCuenta.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(0)))));
            // Estilo plano (Flat): sin el relieve de los botones normales de Windows
            this.btnMiCuenta.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            // Letra Segoe UI de 11 puntos
            this.btnMiCuenta.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Letra blanca
            this.btnMiCuenta.ForeColor = System.Drawing.Color.White;
            // Posición: debajo del botón anterior (el FlowLayoutPanel la calcula solo)
            this.btnMiCuenta.Location = new System.Drawing.Point(12, 112);
            // Separación de 4 píxeles con el botón de abajo
            this.btnMiCuenta.Margin = new System.Windows.Forms.Padding(0, 0, 0, 4);
            // Nombre del control (con este nombre se usa en FrmPanel.cs)
            this.btnMiCuenta.Name = "btnMiCuenta";
            // Espacio a la izquierda para que el texto no quede pegado al borde
            this.btnMiCuenta.Padding = new System.Windows.Forms.Padding(14, 0, 0, 0);
            // Tamaño: 216 de ancho y 44 de alto
            this.btnMiCuenta.Size = new System.Drawing.Size(216, 44);
            // Orden de tabulación dentro del menú
            this.btnMiCuenta.TabIndex = 2;
            // Texto del botón
            this.btnMiCuenta.Text = "Mi Cuenta";
            // Texto a la izquierda y centrado de arriba a abajo
            this.btnMiCuenta.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // Usa el BackColor que pusimos, no el color del tema de Windows
            this.btnMiCuenta.UseVisualStyleBackColor = false;
            // Conecta el clic con el método btnMiCuenta_Click (en FrmPanel.cs)
            this.btnMiCuenta.Click += new System.EventHandler(this.btnMiCuenta_Click);
            //
            // btnConsumos
            // Botón "Consumos" del menú lateral (solo el instructor). Verde y plano; el activo se pone blanco.
            //
            // Fondo verde SENA, igual al menú
            this.btnConsumos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(169)))), ((int)(((byte)(0)))));
            // Puntero de mano al pasar por encima
            this.btnConsumos.Cursor = System.Windows.Forms.Cursors.Hand;
            // Sin borde
            this.btnConsumos.FlatAppearance.BorderSize = 0;
            // Verde más oscuro mientras se mantiene presionado
            this.btnConsumos.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(115)))), ((int)(((byte)(0)))));
            // Verde oscuro al pasar el mouse
            this.btnConsumos.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(0)))));
            // Estilo plano (Flat): sin el relieve de los botones normales de Windows
            this.btnConsumos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            // Letra Segoe UI de 11 puntos
            this.btnConsumos.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Letra blanca
            this.btnConsumos.ForeColor = System.Drawing.Color.White;
            // Posición: debajo del botón anterior (el FlowLayoutPanel la calcula solo)
            this.btnConsumos.Location = new System.Drawing.Point(12, 160);
            // Separación de 4 píxeles con el botón de abajo
            this.btnConsumos.Margin = new System.Windows.Forms.Padding(0, 0, 0, 4);
            // Nombre del control (con este nombre se usa en FrmPanel.cs)
            this.btnConsumos.Name = "btnConsumos";
            // Espacio a la izquierda para que el texto no quede pegado al borde
            this.btnConsumos.Padding = new System.Windows.Forms.Padding(14, 0, 0, 0);
            // Tamaño: 216 de ancho y 44 de alto
            this.btnConsumos.Size = new System.Drawing.Size(216, 44);
            // Orden de tabulación dentro del menú
            this.btnConsumos.TabIndex = 3;
            // Texto del botón
            this.btnConsumos.Text = "Consumos";
            // Texto a la izquierda y centrado de arriba a abajo
            this.btnConsumos.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // Usa el BackColor que pusimos, no el color del tema de Windows
            this.btnConsumos.UseVisualStyleBackColor = false;
            // Conecta el clic con el método btnConsumos_Click (en FrmPanel.cs)
            this.btnConsumos.Click += new System.EventHandler(this.btnConsumos_Click);
            //
            // btnVentas
            // Botón "Ventas" del menú lateral (solo el encargado). Verde y plano; el activo se pone blanco.
            //
            // Fondo verde SENA, igual al menú
            this.btnVentas.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(169)))), ((int)(((byte)(0)))));
            // Puntero de mano al pasar por encima
            this.btnVentas.Cursor = System.Windows.Forms.Cursors.Hand;
            // Sin borde
            this.btnVentas.FlatAppearance.BorderSize = 0;
            // Verde más oscuro mientras se mantiene presionado
            this.btnVentas.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(115)))), ((int)(((byte)(0)))));
            // Verde oscuro al pasar el mouse
            this.btnVentas.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(0)))));
            // Estilo plano (Flat): sin el relieve de los botones normales de Windows
            this.btnVentas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            // Letra Segoe UI de 11 puntos
            this.btnVentas.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Letra blanca
            this.btnVentas.ForeColor = System.Drawing.Color.White;
            // Posición: debajo del botón anterior (el FlowLayoutPanel la calcula solo)
            this.btnVentas.Location = new System.Drawing.Point(12, 208);
            // Separación de 4 píxeles con el botón de abajo
            this.btnVentas.Margin = new System.Windows.Forms.Padding(0, 0, 0, 4);
            // Nombre del control (con este nombre se usa en FrmPanel.cs)
            this.btnVentas.Name = "btnVentas";
            // Espacio a la izquierda para que el texto no quede pegado al borde
            this.btnVentas.Padding = new System.Windows.Forms.Padding(14, 0, 0, 0);
            // Tamaño: 216 de ancho y 44 de alto
            this.btnVentas.Size = new System.Drawing.Size(216, 44);
            // Orden de tabulación dentro del menú
            this.btnVentas.TabIndex = 4;
            // Texto del botón
            this.btnVentas.Text = "Ventas";
            // Texto a la izquierda y centrado de arriba a abajo
            this.btnVentas.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // Usa el BackColor que pusimos, no el color del tema de Windows
            this.btnVentas.UseVisualStyleBackColor = false;
            // Conecta el clic con el método btnVentas_Click (en FrmPanel.cs)
            this.btnVentas.Click += new System.EventHandler(this.btnVentas_Click);
            //
            // btnMenuDelDia
            // Botón "Menú del Día" del menú lateral (solo el encargado). Verde y plano; el activo se pone blanco.
            //
            // Fondo verde SENA, igual al menú
            this.btnMenuDelDia.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(169)))), ((int)(((byte)(0)))));
            // Puntero de mano al pasar por encima
            this.btnMenuDelDia.Cursor = System.Windows.Forms.Cursors.Hand;
            // Sin borde
            this.btnMenuDelDia.FlatAppearance.BorderSize = 0;
            // Verde más oscuro mientras se mantiene presionado
            this.btnMenuDelDia.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(115)))), ((int)(((byte)(0)))));
            // Verde oscuro al pasar el mouse
            this.btnMenuDelDia.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(0)))));
            // Estilo plano (Flat): sin el relieve de los botones normales de Windows
            this.btnMenuDelDia.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            // Letra Segoe UI de 11 puntos
            this.btnMenuDelDia.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Letra blanca
            this.btnMenuDelDia.ForeColor = System.Drawing.Color.White;
            // Posición: debajo del botón anterior (el FlowLayoutPanel la calcula solo)
            this.btnMenuDelDia.Location = new System.Drawing.Point(12, 256);
            // Separación de 4 píxeles con el botón de abajo
            this.btnMenuDelDia.Margin = new System.Windows.Forms.Padding(0, 0, 0, 4);
            // Nombre del control (con este nombre se usa en FrmPanel.cs)
            this.btnMenuDelDia.Name = "btnMenuDelDia";
            // Espacio a la izquierda para que el texto no quede pegado al borde
            this.btnMenuDelDia.Padding = new System.Windows.Forms.Padding(14, 0, 0, 0);
            // Tamaño: 216 de ancho y 44 de alto
            this.btnMenuDelDia.Size = new System.Drawing.Size(216, 44);
            // Orden de tabulación dentro del menú
            this.btnMenuDelDia.TabIndex = 5;
            // Texto del botón
            this.btnMenuDelDia.Text = "Menú del Día";
            // Texto a la izquierda y centrado de arriba a abajo
            this.btnMenuDelDia.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // Usa el BackColor que pusimos, no el color del tema de Windows
            this.btnMenuDelDia.UseVisualStyleBackColor = false;
            // Conecta el clic con el método btnMenuDelDia_Click (en FrmPanel.cs)
            this.btnMenuDelDia.Click += new System.EventHandler(this.btnMenuDelDia_Click);
            //
            // btnBeneficiarios
            // Botón "Beneficiarios" del menú lateral (solo el encargado). Verde y plano; el activo se pone blanco.
            //
            // Fondo verde SENA, igual al menú
            this.btnBeneficiarios.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(169)))), ((int)(((byte)(0)))));
            // Puntero de mano al pasar por encima
            this.btnBeneficiarios.Cursor = System.Windows.Forms.Cursors.Hand;
            // Sin borde
            this.btnBeneficiarios.FlatAppearance.BorderSize = 0;
            // Verde más oscuro mientras se mantiene presionado
            this.btnBeneficiarios.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(115)))), ((int)(((byte)(0)))));
            // Verde oscuro al pasar el mouse
            this.btnBeneficiarios.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(0)))));
            // Estilo plano (Flat): sin el relieve de los botones normales de Windows
            this.btnBeneficiarios.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            // Letra Segoe UI de 11 puntos
            this.btnBeneficiarios.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Letra blanca
            this.btnBeneficiarios.ForeColor = System.Drawing.Color.White;
            // Posición: debajo del botón anterior (el FlowLayoutPanel la calcula solo)
            this.btnBeneficiarios.Location = new System.Drawing.Point(12, 304);
            // Separación de 4 píxeles con el botón de abajo
            this.btnBeneficiarios.Margin = new System.Windows.Forms.Padding(0, 0, 0, 4);
            // Nombre del control (con este nombre se usa en FrmPanel.cs)
            this.btnBeneficiarios.Name = "btnBeneficiarios";
            // Espacio a la izquierda para que el texto no quede pegado al borde
            this.btnBeneficiarios.Padding = new System.Windows.Forms.Padding(14, 0, 0, 0);
            // Tamaño: 216 de ancho y 44 de alto
            this.btnBeneficiarios.Size = new System.Drawing.Size(216, 44);
            // Orden de tabulación dentro del menú
            this.btnBeneficiarios.TabIndex = 6;
            // Texto del botón
            this.btnBeneficiarios.Text = "Beneficiarios";
            // Texto a la izquierda y centrado de arriba a abajo
            this.btnBeneficiarios.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // Usa el BackColor que pusimos, no el color del tema de Windows
            this.btnBeneficiarios.UseVisualStyleBackColor = false;
            // Conecta el clic con el método btnBeneficiarios_Click (en FrmPanel.cs)
            this.btnBeneficiarios.Click += new System.EventHandler(this.btnBeneficiarios_Click);
            //
            // btnCarteraDeudas
            // Botón "Cartera de Deudas" del menú lateral (solo el encargado). Verde y plano; el activo se pone blanco.
            //
            // Fondo verde SENA, igual al menú
            this.btnCarteraDeudas.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(169)))), ((int)(((byte)(0)))));
            // Puntero de mano al pasar por encima
            this.btnCarteraDeudas.Cursor = System.Windows.Forms.Cursors.Hand;
            // Sin borde
            this.btnCarteraDeudas.FlatAppearance.BorderSize = 0;
            // Verde más oscuro mientras se mantiene presionado
            this.btnCarteraDeudas.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(115)))), ((int)(((byte)(0)))));
            // Verde oscuro al pasar el mouse
            this.btnCarteraDeudas.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(0)))));
            // Estilo plano (Flat): sin el relieve de los botones normales de Windows
            this.btnCarteraDeudas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            // Letra Segoe UI de 11 puntos
            this.btnCarteraDeudas.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Letra blanca
            this.btnCarteraDeudas.ForeColor = System.Drawing.Color.White;
            // Posición: debajo del botón anterior (el FlowLayoutPanel la calcula solo)
            this.btnCarteraDeudas.Location = new System.Drawing.Point(12, 352);
            // Separación de 4 píxeles con el botón de abajo
            this.btnCarteraDeudas.Margin = new System.Windows.Forms.Padding(0, 0, 0, 4);
            // Nombre del control (con este nombre se usa en FrmPanel.cs)
            this.btnCarteraDeudas.Name = "btnCarteraDeudas";
            // Espacio a la izquierda para que el texto no quede pegado al borde
            this.btnCarteraDeudas.Padding = new System.Windows.Forms.Padding(14, 0, 0, 0);
            // Tamaño: 216 de ancho y 44 de alto
            this.btnCarteraDeudas.Size = new System.Drawing.Size(216, 44);
            // Orden de tabulación dentro del menú
            this.btnCarteraDeudas.TabIndex = 7;
            // Texto del botón
            this.btnCarteraDeudas.Text = "Cartera de Deudas";
            // Texto a la izquierda y centrado de arriba a abajo
            this.btnCarteraDeudas.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // Usa el BackColor que pusimos, no el color del tema de Windows
            this.btnCarteraDeudas.UseVisualStyleBackColor = false;
            // Conecta el clic con el método btnCarteraDeudas_Click (en FrmPanel.cs)
            this.btnCarteraDeudas.Click += new System.EventHandler(this.btnCarteraDeudas_Click);
            //
            // btnInventario
            // Botón "Inventario" del menú lateral (solo el encargado). Verde y plano; el activo se pone blanco.
            //
            // Fondo verde SENA, igual al menú
            this.btnInventario.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(169)))), ((int)(((byte)(0)))));
            // Puntero de mano al pasar por encima
            this.btnInventario.Cursor = System.Windows.Forms.Cursors.Hand;
            // Sin borde
            this.btnInventario.FlatAppearance.BorderSize = 0;
            // Verde más oscuro mientras se mantiene presionado
            this.btnInventario.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(115)))), ((int)(((byte)(0)))));
            // Verde oscuro al pasar el mouse
            this.btnInventario.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(0)))));
            // Estilo plano (Flat): sin el relieve de los botones normales de Windows
            this.btnInventario.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            // Letra Segoe UI de 11 puntos
            this.btnInventario.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Letra blanca
            this.btnInventario.ForeColor = System.Drawing.Color.White;
            // Posición: debajo del botón anterior (el FlowLayoutPanel la calcula solo)
            this.btnInventario.Location = new System.Drawing.Point(12, 400);
            // Separación de 4 píxeles con el botón de abajo
            this.btnInventario.Margin = new System.Windows.Forms.Padding(0, 0, 0, 4);
            // Nombre del control (con este nombre se usa en FrmPanel.cs)
            this.btnInventario.Name = "btnInventario";
            // Espacio a la izquierda para que el texto no quede pegado al borde
            this.btnInventario.Padding = new System.Windows.Forms.Padding(14, 0, 0, 0);
            // Tamaño: 216 de ancho y 44 de alto
            this.btnInventario.Size = new System.Drawing.Size(216, 44);
            // Orden de tabulación dentro del menú
            this.btnInventario.TabIndex = 8;
            // Texto del botón
            this.btnInventario.Text = "Inventario";
            // Texto a la izquierda y centrado de arriba a abajo
            this.btnInventario.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // Usa el BackColor que pusimos, no el color del tema de Windows
            this.btnInventario.UseVisualStyleBackColor = false;
            // Conecta el clic con el método btnInventario_Click (en FrmPanel.cs)
            this.btnInventario.Click += new System.EventHandler(this.btnInventario_Click);
            //
            // btnGrupos
            // Botón "Grupos" del menú lateral (solo el encargado). Verde y plano; el activo se pone blanco.
            //
            // Fondo verde SENA, igual al menú
            this.btnGrupos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(169)))), ((int)(((byte)(0)))));
            // Puntero de mano al pasar por encima
            this.btnGrupos.Cursor = System.Windows.Forms.Cursors.Hand;
            // Sin borde
            this.btnGrupos.FlatAppearance.BorderSize = 0;
            // Verde más oscuro mientras se mantiene presionado
            this.btnGrupos.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(115)))), ((int)(((byte)(0)))));
            // Verde oscuro al pasar el mouse
            this.btnGrupos.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(0)))));
            // Estilo plano (Flat): sin el relieve de los botones normales de Windows
            this.btnGrupos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            // Letra Segoe UI de 11 puntos
            this.btnGrupos.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Letra blanca
            this.btnGrupos.ForeColor = System.Drawing.Color.White;
            // Posición: debajo del botón anterior (el FlowLayoutPanel la calcula solo)
            this.btnGrupos.Location = new System.Drawing.Point(12, 448);
            // Separación de 4 píxeles con el botón de abajo
            this.btnGrupos.Margin = new System.Windows.Forms.Padding(0, 0, 0, 4);
            // Nombre del control (con este nombre se usa en FrmPanel.cs)
            this.btnGrupos.Name = "btnGrupos";
            // Espacio a la izquierda para que el texto no quede pegado al borde
            this.btnGrupos.Padding = new System.Windows.Forms.Padding(14, 0, 0, 0);
            // Tamaño: 216 de ancho y 44 de alto
            this.btnGrupos.Size = new System.Drawing.Size(216, 44);
            // Orden de tabulación dentro del menú
            this.btnGrupos.TabIndex = 9;
            // Texto del botón
            this.btnGrupos.Text = "Grupos";
            // Texto a la izquierda y centrado de arriba a abajo
            this.btnGrupos.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // Usa el BackColor que pusimos, no el color del tema de Windows
            this.btnGrupos.UseVisualStyleBackColor = false;
            // Conecta el clic con el método btnGrupos_Click (en FrmPanel.cs)
            this.btnGrupos.Click += new System.EventHandler(this.btnGrupos_Click);
            //
            // btnVisitasInstitucionales
            // Botón "Visitas Institucionales" del menú lateral (solo el encargado). Verde y plano; el activo se pone blanco.
            //
            // Fondo verde SENA, igual al menú
            this.btnVisitasInstitucionales.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(169)))), ((int)(((byte)(0)))));
            // Puntero de mano al pasar por encima
            this.btnVisitasInstitucionales.Cursor = System.Windows.Forms.Cursors.Hand;
            // Sin borde
            this.btnVisitasInstitucionales.FlatAppearance.BorderSize = 0;
            // Verde más oscuro mientras se mantiene presionado
            this.btnVisitasInstitucionales.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(115)))), ((int)(((byte)(0)))));
            // Verde oscuro al pasar el mouse
            this.btnVisitasInstitucionales.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(0)))));
            // Estilo plano (Flat): sin el relieve de los botones normales de Windows
            this.btnVisitasInstitucionales.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            // Letra Segoe UI de 11 puntos
            this.btnVisitasInstitucionales.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Letra blanca
            this.btnVisitasInstitucionales.ForeColor = System.Drawing.Color.White;
            // Posición: debajo del botón anterior (el FlowLayoutPanel la calcula solo)
            this.btnVisitasInstitucionales.Location = new System.Drawing.Point(12, 496);
            // Separación de 4 píxeles con el botón de abajo
            this.btnVisitasInstitucionales.Margin = new System.Windows.Forms.Padding(0, 0, 0, 4);
            // Nombre del control (con este nombre se usa en FrmPanel.cs)
            this.btnVisitasInstitucionales.Name = "btnVisitasInstitucionales";
            // Espacio a la izquierda para que el texto no quede pegado al borde
            this.btnVisitasInstitucionales.Padding = new System.Windows.Forms.Padding(14, 0, 0, 0);
            // Tamaño: 216 de ancho y 44 de alto
            this.btnVisitasInstitucionales.Size = new System.Drawing.Size(216, 44);
            // Orden de tabulación dentro del menú
            this.btnVisitasInstitucionales.TabIndex = 10;
            // Texto del botón
            this.btnVisitasInstitucionales.Text = "Visitas Institucionales";
            // Texto a la izquierda y centrado de arriba a abajo
            this.btnVisitasInstitucionales.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // Usa el BackColor que pusimos, no el color del tema de Windows
            this.btnVisitasInstitucionales.UseVisualStyleBackColor = false;
            // Conecta el clic con el método btnVisitasInstitucionales_Click (en FrmPanel.cs)
            this.btnVisitasInstitucionales.Click += new System.EventHandler(this.btnVisitasInstitucionales_Click);
            //
            // btnSolicitudesCuenta
            // Botón "Solicitudes de Cuenta" del menú lateral (solo el encargado). Verde y plano; el activo se pone blanco.
            //
            // Fondo verde SENA, igual al menú
            this.btnSolicitudesCuenta.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(169)))), ((int)(((byte)(0)))));
            // Puntero de mano al pasar por encima
            this.btnSolicitudesCuenta.Cursor = System.Windows.Forms.Cursors.Hand;
            // Sin borde
            this.btnSolicitudesCuenta.FlatAppearance.BorderSize = 0;
            // Verde más oscuro mientras se mantiene presionado
            this.btnSolicitudesCuenta.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(115)))), ((int)(((byte)(0)))));
            // Verde oscuro al pasar el mouse
            this.btnSolicitudesCuenta.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(0)))));
            // Estilo plano (Flat): sin el relieve de los botones normales de Windows
            this.btnSolicitudesCuenta.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            // Letra Segoe UI de 11 puntos
            this.btnSolicitudesCuenta.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Letra blanca
            this.btnSolicitudesCuenta.ForeColor = System.Drawing.Color.White;
            // Posición: debajo del botón anterior (el FlowLayoutPanel la calcula solo)
            this.btnSolicitudesCuenta.Location = new System.Drawing.Point(12, 544);
            // Separación de 4 píxeles con el botón de abajo
            this.btnSolicitudesCuenta.Margin = new System.Windows.Forms.Padding(0, 0, 0, 4);
            // Nombre del control (con este nombre se usa en FrmPanel.cs)
            this.btnSolicitudesCuenta.Name = "btnSolicitudesCuenta";
            // Espacio a la izquierda para que el texto no quede pegado al borde
            this.btnSolicitudesCuenta.Padding = new System.Windows.Forms.Padding(14, 0, 0, 0);
            // Tamaño: 216 de ancho y 44 de alto
            this.btnSolicitudesCuenta.Size = new System.Drawing.Size(216, 44);
            // Orden de tabulación dentro del menú
            this.btnSolicitudesCuenta.TabIndex = 11;
            // Texto del botón
            this.btnSolicitudesCuenta.Text = "Solicitudes de Cuenta";
            // Texto a la izquierda y centrado de arriba a abajo
            this.btnSolicitudesCuenta.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // Usa el BackColor que pusimos, no el color del tema de Windows
            this.btnSolicitudesCuenta.UseVisualStyleBackColor = false;
            // Conecta el clic con el método btnSolicitudesCuenta_Click (en FrmPanel.cs)
            this.btnSolicitudesCuenta.Click += new System.EventHandler(this.btnSolicitudesCuenta_Click);
            //
            // btnBuzonSugerencias
            // Botón "Buzón de Sugerencias" del menú lateral (lo ven todos los perfiles). Verde y plano; el activo se pone blanco.
            //
            // Fondo verde SENA, igual al menú
            this.btnBuzonSugerencias.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(169)))), ((int)(((byte)(0)))));
            // Puntero de mano al pasar por encima
            this.btnBuzonSugerencias.Cursor = System.Windows.Forms.Cursors.Hand;
            // Sin borde
            this.btnBuzonSugerencias.FlatAppearance.BorderSize = 0;
            // Verde más oscuro mientras se mantiene presionado
            this.btnBuzonSugerencias.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(115)))), ((int)(((byte)(0)))));
            // Verde oscuro al pasar el mouse
            this.btnBuzonSugerencias.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(0)))));
            // Estilo plano (Flat): sin el relieve de los botones normales de Windows
            this.btnBuzonSugerencias.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            // Letra Segoe UI de 11 puntos
            this.btnBuzonSugerencias.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Letra blanca
            this.btnBuzonSugerencias.ForeColor = System.Drawing.Color.White;
            // Posición: debajo del botón anterior (el FlowLayoutPanel la calcula solo)
            this.btnBuzonSugerencias.Location = new System.Drawing.Point(12, 592);
            // Separación de 4 píxeles con el botón de abajo
            this.btnBuzonSugerencias.Margin = new System.Windows.Forms.Padding(0, 0, 0, 4);
            // Nombre del control (con este nombre se usa en FrmPanel.cs)
            this.btnBuzonSugerencias.Name = "btnBuzonSugerencias";
            // Espacio a la izquierda para que el texto no quede pegado al borde
            this.btnBuzonSugerencias.Padding = new System.Windows.Forms.Padding(14, 0, 0, 0);
            // Tamaño: 216 de ancho y 44 de alto
            this.btnBuzonSugerencias.Size = new System.Drawing.Size(216, 44);
            // Orden de tabulación dentro del menú
            this.btnBuzonSugerencias.TabIndex = 12;
            // Texto del botón
            this.btnBuzonSugerencias.Text = "Buzón de Sugerencias";
            // Texto a la izquierda y centrado de arriba a abajo
            this.btnBuzonSugerencias.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // Usa el BackColor que pusimos, no el color del tema de Windows
            this.btnBuzonSugerencias.UseVisualStyleBackColor = false;
            // Conecta el clic con el método btnBuzonSugerencias_Click (en FrmPanel.cs)
            this.btnBuzonSugerencias.Click += new System.EventHandler(this.btnBuzonSugerencias_Click);
            //
            // btnPerfil
            // Botón "Perfil" del menú lateral (el aprendiz y el instructor). Verde y plano; el activo se pone blanco.
            //
            // Fondo verde SENA, igual al menú
            this.btnPerfil.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(169)))), ((int)(((byte)(0)))));
            // Puntero de mano al pasar por encima
            this.btnPerfil.Cursor = System.Windows.Forms.Cursors.Hand;
            // Sin borde
            this.btnPerfil.FlatAppearance.BorderSize = 0;
            // Verde más oscuro mientras se mantiene presionado
            this.btnPerfil.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(115)))), ((int)(((byte)(0)))));
            // Verde oscuro al pasar el mouse
            this.btnPerfil.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(0)))));
            // Estilo plano (Flat): sin el relieve de los botones normales de Windows
            this.btnPerfil.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            // Letra Segoe UI de 11 puntos
            this.btnPerfil.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Letra blanca
            this.btnPerfil.ForeColor = System.Drawing.Color.White;
            // Posición: debajo del botón anterior (el FlowLayoutPanel la calcula solo)
            this.btnPerfil.Location = new System.Drawing.Point(12, 640);
            // Separación de 4 píxeles con el botón de abajo
            this.btnPerfil.Margin = new System.Windows.Forms.Padding(0, 0, 0, 4);
            // Nombre del control (con este nombre se usa en FrmPanel.cs)
            this.btnPerfil.Name = "btnPerfil";
            // Espacio a la izquierda para que el texto no quede pegado al borde
            this.btnPerfil.Padding = new System.Windows.Forms.Padding(14, 0, 0, 0);
            // Tamaño: 216 de ancho y 44 de alto
            this.btnPerfil.Size = new System.Drawing.Size(216, 44);
            // Orden de tabulación dentro del menú
            this.btnPerfil.TabIndex = 13;
            // Texto del botón
            this.btnPerfil.Text = "Perfil";
            // Texto a la izquierda y centrado de arriba a abajo
            this.btnPerfil.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // Usa el BackColor que pusimos, no el color del tema de Windows
            this.btnPerfil.UseVisualStyleBackColor = false;
            // Conecta el clic con el método btnPerfil_Click (en FrmPanel.cs)
            this.btnPerfil.Click += new System.EventHandler(this.btnPerfil_Click);
            //
            // pnlMarca
            // Recuadro blanco arriba del menú con el logo, "GastroSENA" y "SENA Yamboró".
            // Tiene el mismo alto que el encabezado, para que formen una sola franja blanca.
            //
            // Fondo blanco
            this.pnlMarca.BackColor = System.Drawing.Color.White;
            // Agrega la línea gris de abajo
            this.pnlMarca.Controls.Add(this.pnlLineaMarca);
            // Agrega "SENA Yamboró"
            this.pnlMarca.Controls.Add(this.lblMarcaSubtitulo);
            // Agrega "GastroSENA"
            this.pnlMarca.Controls.Add(this.lblMarca);
            // Agrega el logo
            this.pnlMarca.Controls.Add(this.picLogoMenu);
            // Pegado arriba del menú
            this.pnlMarca.Dock = System.Windows.Forms.DockStyle.Top;
            // Posición: arriba del menú
            this.pnlMarca.Location = new System.Drawing.Point(0, 0);
            // Nombre del control
            this.pnlMarca.Name = "pnlMarca";
            // Tamaño: 240 de ancho y 72 de alto
            this.pnlMarca.Size = new System.Drawing.Size(240, 72);
            // Orden de tabulación
            this.pnlMarca.TabIndex = 0;
            //
            // pnlLineaMarca
            // Línea gris de 1 píxel en el borde de abajo de la marca.
            //
            // Color gris claro
            this.pnlLineaMarca.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(230)))), ((int)(((byte)(221)))));
            // Pegada abajo
            this.pnlLineaMarca.Dock = System.Windows.Forms.DockStyle.Bottom;
            // Posición: borde de abajo
            this.pnlLineaMarca.Location = new System.Drawing.Point(0, 71);
            // Nombre del control
            this.pnlLineaMarca.Name = "pnlLineaMarca";
            // Alto de 1 píxel
            this.pnlLineaMarca.Size = new System.Drawing.Size(240, 1);
            // Orden de tabulación
            this.pnlLineaMarca.TabIndex = 3;
            //
            // lblMarcaSubtitulo
            // Texto pequeño "SENA Yamboró" debajo de "GastroSENA".
            //
            // El tamaño se ajusta solo al texto
            this.lblMarcaSubtitulo.AutoSize = true;
            // Letra Segoe UI de 9 puntos
            this.lblMarcaSubtitulo.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Color gris
            this.lblMarcaSubtitulo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(114)))), ((int)(((byte)(128)))));
            // Posición: a la derecha del logo, abajo
            this.lblMarcaSubtitulo.Location = new System.Drawing.Point(75, 40);
            // Nombre del control
            this.lblMarcaSubtitulo.Name = "lblMarcaSubtitulo";
            // Tamaño calculado por el AutoSize
            this.lblMarcaSubtitulo.Size = new System.Drawing.Size(80, 15);
            // Orden de tabulación
            this.lblMarcaSubtitulo.TabIndex = 2;
            // Texto que se muestra
            this.lblMarcaSubtitulo.Text = "SENA Yamboró";
            //
            // lblMarca
            // Nombre "GastroSENA" en verde y negrita, a la derecha del logo.
            //
            // El tamaño se ajusta solo al texto
            this.lblMarca.AutoSize = true;
            // Letra Segoe UI de 14 puntos en negrita
            this.lblMarca.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Color verde SENA
            this.lblMarca.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(169)))), ((int)(((byte)(0)))));
            // Posición: a la derecha del logo, arriba
            this.lblMarca.Location = new System.Drawing.Point(72, 13);
            // Nombre del control
            this.lblMarca.Name = "lblMarca";
            // Tamaño calculado por el AutoSize
            this.lblMarca.Size = new System.Drawing.Size(117, 25);
            // Orden de tabulación
            this.lblMarca.TabIndex = 1;
            // Texto que se muestra
            this.lblMarca.Text = "GastroSENA";
            //
            // picLogoMenu
            // Logo pequeño de GastroSENA arriba a la izquierda del menú.
            //
            // Imagen: el logo guardado en Properties > Resources
            this.picLogoMenu.Image = global::GastroSena.Properties.Resources.logo;
            // Posición: con 10 píxeles de margen arriba
            this.picLogoMenu.Location = new System.Drawing.Point(16, 10);
            // Nombre del control
            this.picLogoMenu.Name = "picLogoMenu";
            // Tamaño: 52 x 52 píxeles
            this.picLogoMenu.Size = new System.Drawing.Size(52, 52);
            // Zoom: achica el logo para que quepa completo sin deformarse
            this.picLogoMenu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            // Orden de tabulación
            this.picLogoMenu.TabIndex = 0;
            // La tecla Tab no se detiene en el logo
            this.picLogoMenu.TabStop = false;
            //
            // pnlEncabezado
            // Encabezado blanco arriba, a la derecha del menú: nombre del usuario, perfil y "Cerrar sesión".
            //
            // Fondo blanco
            this.pnlEncabezado.BackColor = System.Drawing.Color.White;
            // Agrega el botón Cerrar sesión
            this.pnlEncabezado.Controls.Add(this.btnCerrarSesion);
            // Agrega la etiqueta del perfil
            this.pnlEncabezado.Controls.Add(this.lblPerfil);
            // Agrega la etiqueta del nombre
            this.pnlEncabezado.Controls.Add(this.lblNombreUsuario);
            // Agrega la línea gris de abajo
            this.pnlEncabezado.Controls.Add(this.pnlLineaEncabezado);
            // Pegado arriba (al lado del menú, porque el menú se acomodó primero)
            this.pnlEncabezado.Dock = System.Windows.Forms.DockStyle.Top;
            // Posición: a la derecha del menú
            this.pnlEncabezado.Location = new System.Drawing.Point(240, 0);
            // Nombre del control
            this.pnlEncabezado.Name = "pnlEncabezado";
            // Tamaño: el resto del ancho y 72 de alto
            this.pnlEncabezado.Size = new System.Drawing.Size(1040, 72);
            // Orden de tabulación
            this.pnlEncabezado.TabIndex = 1;
            //
            // btnCerrarSesion
            // Botón "Cerrar sesión": verde y plano, a la derecha del encabezado. Vuelve al login.
            //
            // Anclado arriba a la derecha: se queda en la esquina aunque la ventana crezca
            this.btnCerrarSesion.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            // Fondo verde SENA
            this.btnCerrarSesion.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(169)))), ((int)(((byte)(0)))));
            // Puntero de mano
            this.btnCerrarSesion.Cursor = System.Windows.Forms.Cursors.Hand;
            // Sin borde
            this.btnCerrarSesion.FlatAppearance.BorderSize = 0;
            // Verde más oscuro mientras se mantiene presionado
            this.btnCerrarSesion.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(115)))), ((int)(((byte)(0)))));
            // Verde oscuro al pasar el mouse
            this.btnCerrarSesion.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(0)))));
            // Estilo plano (Flat)
            this.btnCerrarSesion.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            // Letra Segoe UI Semibold
            this.btnCerrarSesion.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Letra blanca
            this.btnCerrarSesion.ForeColor = System.Drawing.Color.White;
            // Posición: a 24 píxeles del borde derecho
            this.btnCerrarSesion.Location = new System.Drawing.Point(876, 17);
            // Nombre del control
            this.btnCerrarSesion.Name = "btnCerrarSesion";
            // Tamaño: 140 de ancho y 38 de alto
            this.btnCerrarSesion.Size = new System.Drawing.Size(140, 38);
            // Orden de tabulación
            this.btnCerrarSesion.TabIndex = 2;
            // Texto del botón
            this.btnCerrarSesion.Text = "Cerrar sesión";
            // Usa el BackColor que pusimos, no el color del tema de Windows
            this.btnCerrarSesion.UseVisualStyleBackColor = false;
            // Conecta el clic con el método btnCerrarSesion_Click (en FrmPanel.cs)
            this.btnCerrarSesion.Click += new System.EventHandler(this.btnCerrarSesion_Click);
            //
            // lblPerfil
            // Perfil del usuario en verde, debajo del nombre (lo escribe FrmPanel_Load).
            //
            // El tamaño se ajusta solo al texto
            this.lblPerfil.AutoSize = true;
            // Letra Segoe UI Semibold
            this.lblPerfil.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Color verde SENA
            this.lblPerfil.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(169)))), ((int)(((byte)(0)))));
            // Posición: debajo del nombre
            this.lblPerfil.Location = new System.Drawing.Point(26, 41);
            // Nombre del control
            this.lblPerfil.Name = "lblPerfil";
            // Tamaño calculado por el AutoSize
            this.lblPerfil.Size = new System.Drawing.Size(40, 17);
            // Orden de tabulación
            this.lblPerfil.TabIndex = 1;
            // Texto de ejemplo (se reemplaza con el perfil real)
            this.lblPerfil.Text = "Perfil";
            //
            // lblNombreUsuario
            // Nombre del usuario en negrita, arriba a la izquierda del encabezado (lo escribe FrmPanel_Load).
            //
            // El tamaño se ajusta solo al texto
            this.lblNombreUsuario.AutoSize = true;
            // Letra Segoe UI de 14 puntos en negrita
            this.lblNombreUsuario.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Color casi negro
            this.lblNombreUsuario.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(41)))), ((int)(((byte)(51)))));
            // Posición: arriba a la izquierda del encabezado
            this.lblNombreUsuario.Location = new System.Drawing.Point(24, 12);
            // Nombre del control
            this.lblNombreUsuario.Name = "lblNombreUsuario";
            // Tamaño calculado por el AutoSize
            this.lblNombreUsuario.Size = new System.Drawing.Size(187, 25);
            // Orden de tabulación
            this.lblNombreUsuario.TabIndex = 0;
            // Texto de ejemplo (se reemplaza con el nombre real)
            this.lblNombreUsuario.Text = "Nombre del usuario";
            //
            // pnlLineaEncabezado
            // Línea gris de 1 píxel en el borde de abajo del encabezado.
            //
            // Color gris claro
            this.pnlLineaEncabezado.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(230)))), ((int)(((byte)(221)))));
            // Pegada abajo
            this.pnlLineaEncabezado.Dock = System.Windows.Forms.DockStyle.Bottom;
            // Posición: borde de abajo
            this.pnlLineaEncabezado.Location = new System.Drawing.Point(0, 71);
            // Nombre del control
            this.pnlLineaEncabezado.Name = "pnlLineaEncabezado";
            // Alto de 1 píxel
            this.pnlLineaEncabezado.Size = new System.Drawing.Size(1040, 1);
            // Orden de tabulación
            this.pnlLineaEncabezado.TabIndex = 3;
            //
            // pnlContenido
            // Área de contenido: aquí FrmPanel.cs carga el UserControl de la sección elegida.
            //
            // Ocupa todo el espacio que sobra (a la derecha del menú y debajo del encabezado)
            this.pnlContenido.Dock = System.Windows.Forms.DockStyle.Fill;
            // Posición: debajo del encabezado
            this.pnlContenido.Location = new System.Drawing.Point(240, 72);
            // Nombre del control
            this.pnlContenido.Name = "pnlContenido";
            // Margen interior: 28 a los lados, 24 arriba y 28 abajo
            this.pnlContenido.Padding = new System.Windows.Forms.Padding(28, 24, 28, 28);
            // Tamaño (lo calcula el Dock)
            this.pnlContenido.Size = new System.Drawing.Size(1040, 648);
            // Orden de tabulación
            this.pnlContenido.TabIndex = 2;
            //
            // FrmPanel
            // El panel principal: abre maximizado, con el ícono del logo y el título "GastroSENA".
            //
            // Tamaño de letra con el que se diseñó (sirve para escalar si cambia la fuente o el DPI)
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            // Escala los controles según la fuente
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            // Fondo gris muy claro
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(245)))), ((int)(((byte)(241)))));
            // Tamaño del área interior cuando la ventana no está maximizada
            this.ClientSize = new System.Drawing.Size(1280, 720);
            // Agrega el área de contenido (primero, para que su Dock Fill se acomode al final)
            this.Controls.Add(this.pnlContenido);
            // Agrega el encabezado
            this.Controls.Add(this.pnlEncabezado);
            // Agrega el menú (el último agregado se acomoda primero: ocupa todo el alto a la izquierda)
            this.Controls.Add(this.pnlMenu);
            // Fuente de todo el formulario: Segoe UI de 9.75 puntos
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Ícono de la ventana (hecho con el logo), leído de FrmPanel.resx
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            // Tamaño mínimo para que el menú y el encabezado siempre quepan
            this.MinimumSize = new System.Drawing.Size(1000, 660);
            // Nombre del formulario
            this.Name = "FrmPanel";
            // Si se restaura, aparece en el centro de la pantalla
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            // Título de la ventana
            this.Text = "GastroSENA";
            // Abre maximizado
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            // Conecta el evento FormClosed con FrmPanel_FormClosed (vuelve al login o cierra todo)
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FrmPanel_FormClosed);
            // Conecta el evento Load con FrmPanel_Load (llena el encabezado, el menú y muestra Inicio)
            this.Load += new System.EventHandler(this.FrmPanel_Load);
            // Reanuda el acomodo del menú lateral
            this.pnlMenu.ResumeLayout(false);
            // Reanuda el acomodo de la lista de botones
            this.flpMenu.ResumeLayout(false);
            // Reanuda el acomodo del recuadro de la marca
            this.pnlMarca.ResumeLayout(false);
            // Acomoda ya los controles de la marca
            this.pnlMarca.PerformLayout();
            // Termina la configuración del logo
            ((System.ComponentModel.ISupportInitialize)(this.picLogoMenu)).EndInit();
            // Reanuda el acomodo del encabezado
            this.pnlEncabezado.ResumeLayout(false);
            // Acomoda ya los controles del encabezado
            this.pnlEncabezado.PerformLayout();
            // Reanuda el acomodo del formulario completo
            this.ResumeLayout(false);

        }

        // Fin de la región del diseñador
        #endregion

        // Menú lateral verde
        private System.Windows.Forms.Panel pnlMenu;
        // Lista de botones del menú
        private System.Windows.Forms.FlowLayoutPanel flpMenu;
        // Botón "Inicio" del menú lateral
        private System.Windows.Forms.Button btnInicio;
        // Botón "Mis Fichas" del menú lateral
        private System.Windows.Forms.Button btnMisFichas;
        // Botón "Mi Cuenta" del menú lateral
        private System.Windows.Forms.Button btnMiCuenta;
        // Botón "Consumos" del menú lateral
        private System.Windows.Forms.Button btnConsumos;
        // Botón "Ventas" del menú lateral
        private System.Windows.Forms.Button btnVentas;
        // Botón "Menú del Día" del menú lateral
        private System.Windows.Forms.Button btnMenuDelDia;
        // Botón "Beneficiarios" del menú lateral
        private System.Windows.Forms.Button btnBeneficiarios;
        // Botón "Cartera de Deudas" del menú lateral
        private System.Windows.Forms.Button btnCarteraDeudas;
        // Botón "Inventario" del menú lateral
        private System.Windows.Forms.Button btnInventario;
        // Botón "Grupos" del menú lateral
        private System.Windows.Forms.Button btnGrupos;
        // Botón "Visitas Institucionales" del menú lateral
        private System.Windows.Forms.Button btnVisitasInstitucionales;
        // Botón "Solicitudes de Cuenta" del menú lateral
        private System.Windows.Forms.Button btnSolicitudesCuenta;
        // Botón "Buzón de Sugerencias" del menú lateral
        private System.Windows.Forms.Button btnBuzonSugerencias;
        // Botón "Perfil" del menú lateral
        private System.Windows.Forms.Button btnPerfil;
        // Recuadro blanco de la marca
        private System.Windows.Forms.Panel pnlMarca;
        // Línea gris de abajo de la marca
        private System.Windows.Forms.Panel pnlLineaMarca;
        // Texto "SENA Yamboró"
        private System.Windows.Forms.Label lblMarcaSubtitulo;
        // Texto "GastroSENA"
        private System.Windows.Forms.Label lblMarca;
        // Logo pequeño del menú
        private System.Windows.Forms.PictureBox picLogoMenu;
        // Encabezado blanco de arriba
        private System.Windows.Forms.Panel pnlEncabezado;
        // Botón "Cerrar sesión"
        private System.Windows.Forms.Button btnCerrarSesion;
        // Perfil del usuario
        private System.Windows.Forms.Label lblPerfil;
        // Nombre del usuario
        private System.Windows.Forms.Label lblNombreUsuario;
        // Línea gris de abajo del encabezado
        private System.Windows.Forms.Panel pnlLineaEncabezado;
        // Área de contenido donde se cargan las secciones
        private System.Windows.Forms.Panel pnlContenido;
    }
}
