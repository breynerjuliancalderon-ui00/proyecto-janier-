﻿// Visual Studio regenera este archivo cuando se edita en [Diseño], y los comentarios de adentro se pueden borrar.
// Archivo: Secciones/UcPerfil.Designer.cs
// Parte "de diseño" de la sección "Perfil" del aprendiz: aquí se crean el título, la tarjeta blanca con
// los seis campos (Nombre, Documento, Correo, Ficha, Programa y Perfil), los botones "Editar",
// "Guardar cambios" y "Cancelar", y el ErrorProvider que marca los errores junto a cada campo.
// Para cambiarla, abre UcPerfil.cs en la vista [Diseño].

// Espacio de nombres de las secciones (carpeta Secciones)
namespace GastroSena.Secciones
{
    /// <summary>
    /// Segunda parte (partial) de la clase UcPerfil: contiene el código que escribe el diseñador.
    /// La otra parte, con la lógica, está en UcPerfil.cs.
    /// </summary>
    partial class UcPerfil
    {
        /// <summary>
        /// Variable del diseñador necesaria: guarda los componentes que hay que liberar al cerrar (aquí, el ErrorProvider).
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpia los recursos que se estén usando. Se ejecuta cuando la sección se cambia por otra.
        /// </summary>
        /// <param name="disposing">true si se deben liberar los recursos administrados; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            // Si se están liberando recursos y hay componentes guardados...
            if (disposing && (components != null))
            {
                // ...los libera
                components.Dispose();
            }
            // Llama al Dispose de la clase base (UserControl) para que termine de limpiar
            base.Dispose(disposing);
        }

        // Región con el código que escribe el Diseñador de componentes
        #region Código generado por el Diseñador de componentes

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// Crea los controles de la sección, les pone sus propiedades, los agrega y conecta sus eventos.
        /// </summary>
        private void InitializeComponent()
        {
            // Crea el contenedor de componentes (aquí se guarda el ErrorProvider)
            this.components = new System.ComponentModel.Container();
            // Crea la etiqueta del título grande
            this.lblTitulo = new System.Windows.Forms.Label();
            // Crea la etiqueta de la descripción
            this.lblDescripcion = new System.Windows.Forms.Label();
            // Crea la tarjeta blanca
            this.pnlTarjeta = new System.Windows.Forms.Panel();
            // Crea la franja de los botones
            this.flpBotones = new System.Windows.Forms.FlowLayoutPanel();
            // Crea el botón "Editar"
            this.btnEditar = new System.Windows.Forms.Button();
            // Crea el botón "Guardar cambios"
            this.btnGuardar = new System.Windows.Forms.Button();
            // Crea el botón "Cancelar"
            this.btnCancelar = new System.Windows.Forms.Button();
            // Crea la tabla de los campos (dos columnas)
            this.tlpCampos = new System.Windows.Forms.TableLayoutPanel();
            // Crea la etiqueta "Nombre completo"
            this.lblNombre = new System.Windows.Forms.Label();
            // Crea la etiqueta "Documento"
            this.lblDocumento = new System.Windows.Forms.Label();
            // Crea la caja del nombre
            this.txtNombre = new System.Windows.Forms.TextBox();
            // Crea la caja del documento
            this.txtDocumento = new System.Windows.Forms.TextBox();
            // Crea la etiqueta "Correo"
            this.lblCorreo = new System.Windows.Forms.Label();
            // Crea la etiqueta "Ficha"
            this.lblFicha = new System.Windows.Forms.Label();
            // Crea la caja del correo
            this.txtCorreo = new System.Windows.Forms.TextBox();
            // Crea la caja de la ficha
            this.txtFicha = new System.Windows.Forms.TextBox();
            // Crea la etiqueta "Programa"
            this.lblPrograma = new System.Windows.Forms.Label();
            // Crea la etiqueta "Perfil"
            this.lblRol = new System.Windows.Forms.Label();
            // Crea la caja del programa
            this.txtPrograma = new System.Windows.Forms.TextBox();
            // Crea la caja del perfil
            this.txtRol = new System.Windows.Forms.TextBox();
            // Crea el ErrorProvider: muestra un ícono rojo junto al campo que tiene un error
            this.errorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            // Pausa el acomodo de la tarjeta mientras se configura
            this.pnlTarjeta.SuspendLayout();
            // Pausa el acomodo de la franja de botones
            this.flpBotones.SuspendLayout();
            // Pausa el acomodo de la tabla de campos
            this.tlpCampos.SuspendLayout();
            // Avisa al ErrorProvider que empieza su configuración
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).BeginInit();
            // Pausa el acomodo de la sección mientras se configura
            this.SuspendLayout();
            //
            // lblTitulo
            // Título grande "Mi Perfil": arriba de todo, Segoe UI de 20 puntos en negrita.
            //
            // Pegada arriba, ocupando todo el ancho
            this.lblTitulo.Dock = System.Windows.Forms.DockStyle.Top;
            // Letra Segoe UI de 20 puntos en negrita
            this.lblTitulo.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Color casi negro
            this.lblTitulo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(41)))), ((int)(((byte)(51)))));
            // Posición: arriba a la izquierda
            this.lblTitulo.Location = new System.Drawing.Point(0, 0);
            // Nombre del control
            this.lblTitulo.Name = "lblTitulo";
            // Tamaño: todo el ancho y 48 de alto
            this.lblTitulo.Size = new System.Drawing.Size(980, 48);
            // Orden de tabulación
            this.lblTitulo.TabIndex = 0;
            // Texto que se muestra
            this.lblTitulo.Text = "Mi Perfil";
            // Texto alineado a la izquierda y centrado de arriba a abajo
            this.lblTitulo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            //
            // lblDescripcion
            // Descripción gris de para qué sirve la sección, debajo del título.
            //
            // Pegada arriba, debajo del título
            this.lblDescripcion.Dock = System.Windows.Forms.DockStyle.Top;
            // Letra Segoe UI de 11 puntos
            this.lblDescripcion.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Color gris
            this.lblDescripcion.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(114)))), ((int)(((byte)(128)))));
            // Posición: debajo del título
            this.lblDescripcion.Location = new System.Drawing.Point(0, 48);
            // Nombre del control
            this.lblDescripcion.Name = "lblDescripcion";
            // Tamaño: todo el ancho; el alto deja un espacio antes de la tarjeta
            this.lblDescripcion.Size = new System.Drawing.Size(980, 44);
            // Orden de tabulación
            this.lblDescripcion.TabIndex = 1;
            // Texto que se muestra
            this.lblDescripcion.Text = "Mantén tu información personal actualizada. Presiona \"Editar\" para cambiar tu nombre, correo o ficha.";
            //
            // pnlTarjeta
            // Tarjeta blanca que ocupa el resto del espacio: los campos arriba y los botones debajo.
            //
            // Fondo blanco
            this.pnlTarjeta.BackColor = System.Drawing.Color.White;
            // Agrega la franja de botones (el primero agregado queda más abajo con Dock Top)
            this.pnlTarjeta.Controls.Add(this.flpBotones);
            // Agrega la tabla de campos (la última agregada queda más arriba con Dock Top)
            this.pnlTarjeta.Controls.Add(this.tlpCampos);
            // Ocupa todo el espacio que sobra debajo de las etiquetas
            this.pnlTarjeta.Dock = System.Windows.Forms.DockStyle.Fill;
            // Posición: debajo de la descripción
            this.pnlTarjeta.Location = new System.Drawing.Point(0, 92);
            // Nombre del control
            this.pnlTarjeta.Name = "pnlTarjeta";
            // Margen interior de 24 píxeles
            this.pnlTarjeta.Padding = new System.Windows.Forms.Padding(24);
            // Tamaño (lo calcula el Dock)
            this.pnlTarjeta.Size = new System.Drawing.Size(980, 508);
            // Orden de tabulación
            this.pnlTarjeta.TabIndex = 2;
            //
            // flpBotones
            // Franja que pone los botones uno al lado del otro. Los botones ocultos no dejan hueco.
            //
            // Agrega el botón Editar
            this.flpBotones.Controls.Add(this.btnEditar);
            // Agrega el botón Guardar cambios
            this.flpBotones.Controls.Add(this.btnGuardar);
            // Agrega el botón Cancelar
            this.flpBotones.Controls.Add(this.btnCancelar);
            // Pegada arriba, debajo de los campos
            this.flpBotones.Dock = System.Windows.Forms.DockStyle.Top;
            // Posición: debajo de los campos
            this.flpBotones.Location = new System.Drawing.Point(24, 252);
            // Nombre del control
            this.flpBotones.Name = "flpBotones";
            // Margen interior: 12 arriba para separar los botones de los campos
            this.flpBotones.Padding = new System.Windows.Forms.Padding(0, 12, 0, 0);
            // Tamaño: todo el ancho y 56 de alto
            this.flpBotones.Size = new System.Drawing.Size(932, 56);
            // Orden de tabulación
            this.flpBotones.TabIndex = 1;
            //
            // btnEditar
            // Botón verde "Editar": habilita Nombre, Correo y Ficha. Se ejecuta btnEditar_Click (en UcPerfil.cs).
            //
            // Fondo verde SENA
            this.btnEditar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(169)))), ((int)(((byte)(0)))));
            // Puntero de mano
            this.btnEditar.Cursor = System.Windows.Forms.Cursors.Hand;
            // Sin borde
            this.btnEditar.FlatAppearance.BorderSize = 0;
            // Verde más oscuro mientras se mantiene presionado
            this.btnEditar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(115)))), ((int)(((byte)(0)))));
            // Verde oscuro al pasar el mouse
            this.btnEditar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(0)))));
            // Estilo plano (Flat)
            this.btnEditar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            // Letra Segoe UI Semibold de 11 puntos
            this.btnEditar.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Letra blanca
            this.btnEditar.ForeColor = System.Drawing.Color.White;
            // Posición: primer botón de la franja
            this.btnEditar.Location = new System.Drawing.Point(0, 12);
            // Margen: 12 a la derecha para separarlo del siguiente botón
            this.btnEditar.Margin = new System.Windows.Forms.Padding(0, 0, 12, 0);
            // Nombre del control
            this.btnEditar.Name = "btnEditar";
            // Tamaño: 140 de ancho y 40 de alto
            this.btnEditar.Size = new System.Drawing.Size(140, 40);
            // Orden de tabulación
            this.btnEditar.TabIndex = 0;
            // Texto del botón
            this.btnEditar.Text = "Editar";
            // Usa el BackColor que pusimos, no el color del tema de Windows
            this.btnEditar.UseVisualStyleBackColor = false;
            // Conecta el clic con el método btnEditar_Click (en UcPerfil.cs)
            this.btnEditar.Click += new System.EventHandler(this.btnEditar_Click);
            //
            // btnGuardar
            // Botón verde "Guardar cambios": valida y guarda. Empieza oculto; aparece al presionar "Editar".
            //
            // Fondo verde SENA
            this.btnGuardar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(169)))), ((int)(((byte)(0)))));
            // Puntero de mano
            this.btnGuardar.Cursor = System.Windows.Forms.Cursors.Hand;
            // Sin borde
            this.btnGuardar.FlatAppearance.BorderSize = 0;
            // Verde más oscuro mientras se mantiene presionado
            this.btnGuardar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(115)))), ((int)(((byte)(0)))));
            // Verde oscuro al pasar el mouse
            this.btnGuardar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(0)))));
            // Estilo plano (Flat)
            this.btnGuardar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            // Letra Segoe UI Semibold de 11 puntos
            this.btnGuardar.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Letra blanca
            this.btnGuardar.ForeColor = System.Drawing.Color.White;
            // Posición: segundo botón de la franja
            this.btnGuardar.Location = new System.Drawing.Point(152, 12);
            // Margen: 12 a la derecha para separarlo del siguiente botón
            this.btnGuardar.Margin = new System.Windows.Forms.Padding(0, 0, 12, 0);
            // Nombre del control
            this.btnGuardar.Name = "btnGuardar";
            // Tamaño: 170 de ancho y 40 de alto
            this.btnGuardar.Size = new System.Drawing.Size(170, 40);
            // Orden de tabulación
            this.btnGuardar.TabIndex = 1;
            // Texto del botón
            this.btnGuardar.Text = "Guardar cambios";
            // Usa el BackColor que pusimos, no el color del tema de Windows
            this.btnGuardar.UseVisualStyleBackColor = false;
            // Empieza oculto (en [Diseño] se ve igual, para poder editarlo)
            this.btnGuardar.Visible = false;
            // Conecta el clic con el método btnGuardar_Click (en UcPerfil.cs)
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            //
            // btnCancelar
            // Botón blanco con borde verde "Cancelar": deshace los cambios. Empieza oculto.
            //
            // Fondo blanco
            this.btnCancelar.BackColor = System.Drawing.Color.White;
            // Puntero de mano
            this.btnCancelar.Cursor = System.Windows.Forms.Cursors.Hand;
            // Borde verde SENA
            this.btnCancelar.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(169)))), ((int)(((byte)(0)))));
            // Verde un poco más claro mientras se mantiene presionado
            this.btnCancelar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(239)))), ((int)(((byte)(210)))));
            // Verde muy claro al pasar el mouse
            this.btnCancelar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(248)))), ((int)(((byte)(235)))));
            // Estilo plano (Flat)
            this.btnCancelar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            // Letra Segoe UI Semibold de 11 puntos
            this.btnCancelar.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Letra verde SENA
            this.btnCancelar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(169)))), ((int)(((byte)(0)))));
            // Posición: tercer botón de la franja
            this.btnCancelar.Location = new System.Drawing.Point(334, 12);
            // Sin margen
            this.btnCancelar.Margin = new System.Windows.Forms.Padding(0);
            // Nombre del control
            this.btnCancelar.Name = "btnCancelar";
            // Tamaño: 120 de ancho y 40 de alto
            this.btnCancelar.Size = new System.Drawing.Size(120, 40);
            // Orden de tabulación
            this.btnCancelar.TabIndex = 2;
            // Texto del botón
            this.btnCancelar.Text = "Cancelar";
            // Usa el BackColor que pusimos, no el color del tema de Windows
            this.btnCancelar.UseVisualStyleBackColor = false;
            // Empieza oculto (en [Diseño] se ve igual, para poder editarlo)
            this.btnCancelar.Visible = false;
            // Conecta el clic con el método btnCancelar_Click (en UcPerfil.cs)
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            //
            // tlpCampos
            // Tabla de dos columnas iguales: en cada fila par va la etiqueta y en la fila de abajo su caja.
            //
            // Dos columnas
            this.tlpCampos.ColumnCount = 2;
            // Columna 0: la mitad del ancho
            this.tlpCampos.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            // Columna 1: la otra mitad
            this.tlpCampos.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            // Etiqueta "Nombre completo": columna 0, fila 0
            this.tlpCampos.Controls.Add(this.lblNombre, 0, 0);
            // Etiqueta "Documento": columna 1, fila 0
            this.tlpCampos.Controls.Add(this.lblDocumento, 1, 0);
            // Caja del nombre: columna 0, fila 1
            this.tlpCampos.Controls.Add(this.txtNombre, 0, 1);
            // Caja del documento: columna 1, fila 1
            this.tlpCampos.Controls.Add(this.txtDocumento, 1, 1);
            // Etiqueta "Correo": columna 0, fila 2
            this.tlpCampos.Controls.Add(this.lblCorreo, 0, 2);
            // Etiqueta "Ficha": columna 1, fila 2
            this.tlpCampos.Controls.Add(this.lblFicha, 1, 2);
            // Caja del correo: columna 0, fila 3
            this.tlpCampos.Controls.Add(this.txtCorreo, 0, 3);
            // Caja de la ficha: columna 1, fila 3
            this.tlpCampos.Controls.Add(this.txtFicha, 1, 3);
            // Etiqueta "Programa": columna 0, fila 4
            this.tlpCampos.Controls.Add(this.lblPrograma, 0, 4);
            // Etiqueta "Perfil": columna 1, fila 4
            this.tlpCampos.Controls.Add(this.lblRol, 1, 4);
            // Caja del programa: columna 0, fila 5
            this.tlpCampos.Controls.Add(this.txtPrograma, 0, 5);
            // Caja del perfil: columna 1, fila 5
            this.tlpCampos.Controls.Add(this.txtRol, 1, 5);
            // Pegada arriba de la tarjeta
            this.tlpCampos.Dock = System.Windows.Forms.DockStyle.Top;
            // Posición: dentro del margen de la tarjeta
            this.tlpCampos.Location = new System.Drawing.Point(24, 24);
            // Nombre del control
            this.tlpCampos.Name = "tlpCampos";
            // Seis filas
            this.tlpCampos.RowCount = 6;
            // Fila 0 (etiquetas Nombre y Documento): 24 de alto
            this.tlpCampos.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 24F));
            // Fila 1 (cajas Nombre y Documento): 52 de alto
            this.tlpCampos.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 52F));
            // Fila 2 (etiquetas Correo y Ficha): 24 de alto
            this.tlpCampos.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 24F));
            // Fila 3 (cajas Correo y Ficha): 52 de alto
            this.tlpCampos.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 52F));
            // Fila 4 (etiquetas Programa y Perfil): 24 de alto
            this.tlpCampos.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 24F));
            // Fila 5 (cajas Programa y Perfil): 52 de alto
            this.tlpCampos.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 52F));
            // Tamaño: todo el ancho y 228 de alto (la suma de las filas)
            this.tlpCampos.Size = new System.Drawing.Size(932, 228);
            // Orden de tabulación
            this.tlpCampos.TabIndex = 0;
            //
            // lblNombre
            // Etiqueta "Nombre completo".
            //
            // Ocupa toda su celda
            this.lblNombre.Dock = System.Windows.Forms.DockStyle.Fill;
            // Letra Segoe UI Semibold
            this.lblNombre.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Color gris oscuro
            this.lblNombre.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(65)))), ((int)(((byte)(81)))));
            // Posición: columna 0, fila 0
            this.lblNombre.Location = new System.Drawing.Point(0, 0);
            // Sin margen
            this.lblNombre.Margin = new System.Windows.Forms.Padding(0);
            // Nombre del control
            this.lblNombre.Name = "lblNombre";
            // Tamaño (lo calcula el Dock)
            this.lblNombre.Size = new System.Drawing.Size(466, 24);
            // Orden de tabulación
            this.lblNombre.TabIndex = 0;
            // Texto que se muestra
            this.lblNombre.Text = "Nombre completo";
            // Texto abajo a la izquierda (pegado a su caja)
            this.lblNombre.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            //
            // lblDocumento
            // Etiqueta "Documento".
            //
            // Ocupa toda su celda
            this.lblDocumento.Dock = System.Windows.Forms.DockStyle.Fill;
            // Letra Segoe UI Semibold
            this.lblDocumento.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Color gris oscuro
            this.lblDocumento.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(65)))), ((int)(((byte)(81)))));
            // Posición: columna 1, fila 0
            this.lblDocumento.Location = new System.Drawing.Point(466, 0);
            // Sin margen
            this.lblDocumento.Margin = new System.Windows.Forms.Padding(0);
            // Nombre del control
            this.lblDocumento.Name = "lblDocumento";
            // Tamaño (lo calcula el Dock)
            this.lblDocumento.Size = new System.Drawing.Size(466, 24);
            // Orden de tabulación
            this.lblDocumento.TabIndex = 1;
            // Texto que se muestra
            this.lblDocumento.Text = "Documento";
            // Texto abajo a la izquierda (pegado a su caja)
            this.lblDocumento.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            //
            // txtNombre
            // Caja del nombre. Solo lectura hasta que se presiona "Editar".
            //
            // Anclada a la izquierda y a la derecha: se estira con su columna
            this.txtNombre.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            // Letra Segoe UI de 11 puntos
            this.txtNombre.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Posición: columna 0, fila 1
            this.txtNombre.Location = new System.Drawing.Point(0, 36);
            // Margen: 32 a la derecha (deja espacio para el ícono de error)
            this.txtNombre.Margin = new System.Windows.Forms.Padding(0, 0, 32, 0);
            // No deja escribir más de 100 caracteres
            this.txtNombre.MaxLength = 100;
            // Nombre del control
            this.txtNombre.Name = "txtNombre";
            // Solo lectura (gris) al abrir la sección
            this.txtNombre.ReadOnly = true;
            // Tamaño: el ancho de la columna menos el margen
            this.txtNombre.Size = new System.Drawing.Size(434, 27);
            // Orden de tabulación
            this.txtNombre.TabIndex = 2;
            //
            // txtDocumento
            // Caja del documento: siempre de solo lectura (el documento no se puede cambiar).
            //
            // Anclada a la izquierda y a la derecha: se estira con su columna
            this.txtDocumento.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            // Letra Segoe UI de 11 puntos
            this.txtDocumento.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Posición: columna 1, fila 1
            this.txtDocumento.Location = new System.Drawing.Point(466, 36);
            // Margen: 32 a la derecha
            this.txtDocumento.Margin = new System.Windows.Forms.Padding(0, 0, 32, 0);
            // Nombre del control
            this.txtDocumento.Name = "txtDocumento";
            // Siempre de solo lectura
            this.txtDocumento.ReadOnly = true;
            // Tamaño: el ancho de la columna menos el margen
            this.txtDocumento.Size = new System.Drawing.Size(434, 27);
            // Orden de tabulación
            this.txtDocumento.TabIndex = 3;
            // La tecla Tab se salta esta caja (no se edita nunca)
            this.txtDocumento.TabStop = false;
            //
            // lblCorreo
            // Etiqueta "Correo".
            //
            // Ocupa toda su celda
            this.lblCorreo.Dock = System.Windows.Forms.DockStyle.Fill;
            // Letra Segoe UI Semibold
            this.lblCorreo.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Color gris oscuro
            this.lblCorreo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(65)))), ((int)(((byte)(81)))));
            // Posición: columna 0, fila 2
            this.lblCorreo.Location = new System.Drawing.Point(0, 76);
            // Sin margen
            this.lblCorreo.Margin = new System.Windows.Forms.Padding(0);
            // Nombre del control
            this.lblCorreo.Name = "lblCorreo";
            // Tamaño (lo calcula el Dock)
            this.lblCorreo.Size = new System.Drawing.Size(466, 24);
            // Orden de tabulación
            this.lblCorreo.TabIndex = 4;
            // Texto que se muestra
            this.lblCorreo.Text = "Correo";
            // Texto abajo a la izquierda (pegado a su caja)
            this.lblCorreo.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            //
            // lblFicha
            // Etiqueta "Ficha".
            //
            // Ocupa toda su celda
            this.lblFicha.Dock = System.Windows.Forms.DockStyle.Fill;
            // Letra Segoe UI Semibold
            this.lblFicha.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Color gris oscuro
            this.lblFicha.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(65)))), ((int)(((byte)(81)))));
            // Posición: columna 1, fila 2
            this.lblFicha.Location = new System.Drawing.Point(466, 76);
            // Sin margen
            this.lblFicha.Margin = new System.Windows.Forms.Padding(0);
            // Nombre del control
            this.lblFicha.Name = "lblFicha";
            // Tamaño (lo calcula el Dock)
            this.lblFicha.Size = new System.Drawing.Size(466, 24);
            // Orden de tabulación
            this.lblFicha.TabIndex = 5;
            // Texto que se muestra
            this.lblFicha.Text = "Ficha";
            // Texto abajo a la izquierda (pegado a su caja)
            this.lblFicha.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            //
            // txtCorreo
            // Caja del correo. Solo lectura hasta que se presiona "Editar".
            //
            // Anclada a la izquierda y a la derecha: se estira con su columna
            this.txtCorreo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            // Letra Segoe UI de 11 puntos
            this.txtCorreo.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Posición: columna 0, fila 3
            this.txtCorreo.Location = new System.Drawing.Point(0, 112);
            // Margen: 32 a la derecha (deja espacio para el ícono de error)
            this.txtCorreo.Margin = new System.Windows.Forms.Padding(0, 0, 32, 0);
            // No deja escribir más de 100 caracteres
            this.txtCorreo.MaxLength = 100;
            // Nombre del control
            this.txtCorreo.Name = "txtCorreo";
            // Solo lectura (gris) al abrir la sección
            this.txtCorreo.ReadOnly = true;
            // Tamaño: el ancho de la columna menos el margen
            this.txtCorreo.Size = new System.Drawing.Size(434, 27);
            // Orden de tabulación
            this.txtCorreo.TabIndex = 6;
            //
            // txtFicha
            // Caja de la ficha. Solo lectura hasta que se presiona "Editar".
            //
            // Anclada a la izquierda y a la derecha: se estira con su columna
            this.txtFicha.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            // Letra Segoe UI de 11 puntos
            this.txtFicha.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Posición: columna 1, fila 3
            this.txtFicha.Location = new System.Drawing.Point(466, 112);
            // Margen: 32 a la derecha
            this.txtFicha.Margin = new System.Windows.Forms.Padding(0, 0, 32, 0);
            // No deja escribir más de 20 caracteres
            this.txtFicha.MaxLength = 20;
            // Nombre del control
            this.txtFicha.Name = "txtFicha";
            // Solo lectura (gris) al abrir la sección
            this.txtFicha.ReadOnly = true;
            // Tamaño: el ancho de la columna menos el margen
            this.txtFicha.Size = new System.Drawing.Size(434, 27);
            // Orden de tabulación
            this.txtFicha.TabIndex = 7;
            //
            // lblPrograma
            // Etiqueta "Programa".
            //
            // Ocupa toda su celda
            this.lblPrograma.Dock = System.Windows.Forms.DockStyle.Fill;
            // Letra Segoe UI Semibold
            this.lblPrograma.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Color gris oscuro
            this.lblPrograma.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(65)))), ((int)(((byte)(81)))));
            // Posición: columna 0, fila 4
            this.lblPrograma.Location = new System.Drawing.Point(0, 152);
            // Sin margen
            this.lblPrograma.Margin = new System.Windows.Forms.Padding(0);
            // Nombre del control
            this.lblPrograma.Name = "lblPrograma";
            // Tamaño (lo calcula el Dock)
            this.lblPrograma.Size = new System.Drawing.Size(466, 24);
            // Orden de tabulación
            this.lblPrograma.TabIndex = 8;
            // Texto que se muestra
            this.lblPrograma.Text = "Programa";
            // Texto abajo a la izquierda (pegado a su caja)
            this.lblPrograma.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            //
            // lblRol
            // Etiqueta "Perfil".
            //
            // Ocupa toda su celda
            this.lblRol.Dock = System.Windows.Forms.DockStyle.Fill;
            // Letra Segoe UI Semibold
            this.lblRol.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Color gris oscuro
            this.lblRol.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(65)))), ((int)(((byte)(81)))));
            // Posición: columna 1, fila 4
            this.lblRol.Location = new System.Drawing.Point(466, 152);
            // Sin margen
            this.lblRol.Margin = new System.Windows.Forms.Padding(0);
            // Nombre del control
            this.lblRol.Name = "lblRol";
            // Tamaño (lo calcula el Dock)
            this.lblRol.Size = new System.Drawing.Size(466, 24);
            // Orden de tabulación
            this.lblRol.TabIndex = 9;
            // Texto que se muestra
            this.lblRol.Text = "Perfil";
            // Texto abajo a la izquierda (pegado a su caja)
            this.lblRol.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            //
            // txtPrograma
            // Caja del programa de formación: siempre de solo lectura.
            //
            // Anclada a la izquierda y a la derecha: se estira con su columna
            this.txtPrograma.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            // Letra Segoe UI de 11 puntos
            this.txtPrograma.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Posición: columna 0, fila 5
            this.txtPrograma.Location = new System.Drawing.Point(0, 188);
            // Margen: 32 a la derecha
            this.txtPrograma.Margin = new System.Windows.Forms.Padding(0, 0, 32, 0);
            // Nombre del control
            this.txtPrograma.Name = "txtPrograma";
            // Siempre de solo lectura
            this.txtPrograma.ReadOnly = true;
            // Tamaño: el ancho de la columna menos el margen
            this.txtPrograma.Size = new System.Drawing.Size(434, 27);
            // Orden de tabulación
            this.txtPrograma.TabIndex = 10;
            // La tecla Tab se salta esta caja (no se edita nunca)
            this.txtPrograma.TabStop = false;
            //
            // txtRol
            // Caja del perfil (Aprendiz): siempre de solo lectura.
            //
            // Anclada a la izquierda y a la derecha: se estira con su columna
            this.txtRol.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            // Letra Segoe UI de 11 puntos
            this.txtRol.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Posición: columna 1, fila 5
            this.txtRol.Location = new System.Drawing.Point(466, 188);
            // Margen: 32 a la derecha
            this.txtRol.Margin = new System.Windows.Forms.Padding(0, 0, 32, 0);
            // Nombre del control
            this.txtRol.Name = "txtRol";
            // Siempre de solo lectura
            this.txtRol.ReadOnly = true;
            // Tamaño: el ancho de la columna menos el margen
            this.txtRol.Size = new System.Drawing.Size(434, 27);
            // Orden de tabulación
            this.txtRol.TabIndex = 11;
            // La tecla Tab se salta esta caja (no se edita nunca)
            this.txtRol.TabStop = false;
            //
            // errorProvider
            // Muestra un ícono rojo junto al campo con error; al pasar el mouse por el ícono se lee el mensaje.
            //
            // El ícono no parpadea
            this.errorProvider.BlinkStyle = System.Windows.Forms.ErrorBlinkStyle.NeverBlink;
            // Trabaja sobre los controles de esta sección
            this.errorProvider.ContainerControl = this;
            //
            // UcPerfil
            // La sección completa: fondo gris muy claro, igual al área de contenido del panel.
            //
            // Tamaño de letra con el que se diseñó (sirve para escalar si cambia la fuente o el DPI)
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            // Escala los controles según la fuente
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            // Muestra barras de desplazamiento si la ventana queda más pequeña que el contenido
            this.AutoScroll = true;
            // Tamaño mínimo del contenido: por debajo de esto aparecen las barras de desplazamiento
            this.AutoScrollMinSize = new System.Drawing.Size(600, 440);
            // Fondo gris muy claro
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(245)))), ((int)(((byte)(241)))));
            // Agrega la tarjeta (se agrega primero para que el Dock Fill se acomode al final)
            this.Controls.Add(this.pnlTarjeta);
            // Agrega la descripción
            this.Controls.Add(this.lblDescripcion);
            // Agrega el título (el último agregado queda más arriba con Dock Top)
            this.Controls.Add(this.lblTitulo);
            // Fuente de toda la sección: Segoe UI de 9.75 puntos
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Nombre de la sección
            this.Name = "UcPerfil";
            // Tamaño en [Diseño] (en el panel se estira con Dock Fill)
            this.Size = new System.Drawing.Size(980, 600);
            // Reanuda el acomodo de la tarjeta
            this.pnlTarjeta.ResumeLayout(false);
            // Reanuda el acomodo de la franja de botones
            this.flpBotones.ResumeLayout(false);
            // Reanuda el acomodo de la tabla de campos
            this.tlpCampos.ResumeLayout(false);
            // Acomoda ya las cajas de texto de la tabla
            this.tlpCampos.PerformLayout();
            // Termina la configuración del ErrorProvider
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).EndInit();
            // Reanuda el acomodo de la sección
            this.ResumeLayout(false);

        }

        // Fin de la región del diseñador
        #endregion

        // Título grande de la sección
        private System.Windows.Forms.Label lblTitulo;
        // Descripción de la sección
        private System.Windows.Forms.Label lblDescripcion;
        // Tarjeta blanca
        private System.Windows.Forms.Panel pnlTarjeta;
        // Franja de botones
        private System.Windows.Forms.FlowLayoutPanel flpBotones;
        // Botón "Editar"
        private System.Windows.Forms.Button btnEditar;
        // Botón "Guardar cambios"
        private System.Windows.Forms.Button btnGuardar;
        // Botón "Cancelar"
        private System.Windows.Forms.Button btnCancelar;
        // Tabla de los campos
        private System.Windows.Forms.TableLayoutPanel tlpCampos;
        // Etiqueta "Nombre completo"
        private System.Windows.Forms.Label lblNombre;
        // Etiqueta "Documento"
        private System.Windows.Forms.Label lblDocumento;
        // Caja del nombre
        private System.Windows.Forms.TextBox txtNombre;
        // Caja del documento
        private System.Windows.Forms.TextBox txtDocumento;
        // Etiqueta "Correo"
        private System.Windows.Forms.Label lblCorreo;
        // Etiqueta "Ficha"
        private System.Windows.Forms.Label lblFicha;
        // Caja del correo
        private System.Windows.Forms.TextBox txtCorreo;
        // Caja de la ficha
        private System.Windows.Forms.TextBox txtFicha;
        // Etiqueta "Programa"
        private System.Windows.Forms.Label lblPrograma;
        // Etiqueta "Perfil"
        private System.Windows.Forms.Label lblRol;
        // Caja del programa
        private System.Windows.Forms.TextBox txtPrograma;
        // Caja del perfil
        private System.Windows.Forms.TextBox txtRol;
        // Marca los errores junto a cada campo
        private System.Windows.Forms.ErrorProvider errorProvider;
    }
}
