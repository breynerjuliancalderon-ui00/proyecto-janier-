﻿// Archivo: Secciones/UcMisFichas.cs
// Sección "Mis Fichas" (UserControl). La ve el aprendiz.
// Muestra en una tabla de solo lectura todas sus reservas de almuerzo, de la más reciente a la más antigua,
// con su estado de pago en colores, y debajo los totales. Los controles están en UcMisFichas.Designer.cs.

// Trae DateTime y EventArgs
using System;
// Trae List<T>
using System.Collections.Generic;
// Trae los colores (Color) para pintar los estados
using System.Drawing;
// Trae los controles de Windows Forms (UserControl, DataGridView)
using System.Windows.Forms;
// Trae AlmacenDatos (las reservas guardadas en datos.xml)
using GastroSena.Datos;
// Trae las clases Reserva y EstadoPago
using GastroSena.Modelos;
// Trae Formato (pesos y fechas al estilo de Colombia)
using GastroSena.Utilidades;

// Espacio de nombres de las secciones (carpeta Secciones)
namespace GastroSena.Secciones
{
    /// <summary>
    /// Sección "Mis Fichas". FrmPanel la crea cada vez que se presiona el botón "Mis Fichas",
    /// así que siempre lee las reservas más recientes (también la que se acaba de hacer en Inicio).
    /// </summary>
    public partial class UcMisFichas : UserControl
    {
        // Pagado: fondo verde claro
        private readonly Color fondoVerde = Color.FromArgb(220, 252, 231);
        // Pagado: letra verde oscura
        private readonly Color letraVerde = Color.FromArgb(22, 101, 52);
        // Pendiente: fondo amarillo claro
        private readonly Color fondoAmarillo = Color.FromArgb(254, 249, 195);
        // Pendiente: letra café amarillenta (se lee bien sobre el amarillo)
        private readonly Color letraAmarilla = Color.FromArgb(133, 77, 14);
        // Gratis: fondo azul claro
        private readonly Color fondoAzul = Color.FromArgb(219, 234, 254);
        // Gratis y Reservado: letra azul oscura
        private readonly Color letraAzul = Color.FromArgb(30, 64, 175);
        // Consumido: letra gris
        private readonly Color letraGris = Color.FromArgb(107, 114, 128);

        /// <summary>
        /// Constructor: se ejecuta cuando el panel crea la sección (new UcMisFichas()).
        /// Llama a InitializeComponent para crear la tabla y los totales del diseñador.
        /// </summary>
        public UcMisFichas()
        {
            // Crea los controles de la sección tal como se dibujaron en [Diseño]
            InitializeComponent();
        }

        /// <summary>
        /// Evento Load: se ejecuta una vez, cuando la sección aparece en el panel.
        /// Llena la tabla con las reservas y calcula los totales.
        /// </summary>
        /// <param name="sender">La sección que lanzó el evento.</param>
        /// <param name="e">Datos del evento (aquí no se usan).</param>
        private void UcMisFichas_Load(object sender, EventArgs e)
        {
            // Llena la tabla y los totales
            CargarFichas();
        }

        /// <summary>
        /// Pone una fila en la tabla por cada reserva (de la más reciente a la más antigua)
        /// y escribe debajo el total de almuerzos, el total pagado y el total pendiente.
        /// </summary>
        private void CargarFichas()
        {
            // Borra las filas que hubiera
            dgvFichas.Rows.Clear();
            // Suma de lo pagado (empieza en cero)
            decimal totalPagado = 0;
            // Suma de lo pendiente (empieza en cero)
            decimal totalPendiente = 0;
            // Trae las reservas ya ordenadas de la más reciente a la más antigua
            List<Reserva> reservas = AlmacenDatos.ObtenerReservas();
            // Recorre las reservas una por una
            foreach (Reserva reserva in reservas)
            {
                // Texto de la columna Estado (se decide abajo)
                string estado;
                // Si la reserva es de hoy...
                if (reserva.Fecha.Date == DateTime.Today)
                {
                    // ...todavía está reservada
                    estado = "Reservado";
                }
                // Si es de un día anterior...
                else
                {
                    // ...ya se consumió
                    estado = "Consumido";
                }
                // Agrega la fila con los cinco valores, en el orden de las columnas, y guarda su número
                int numeroFila = dgvFichas.Rows.Add(Formato.FechaCorta(reserva.Fecha), reserva.NombreMenu, Formato.Pesos(reserva.Precio), reserva.EstadoPago.ToString(), estado);
                // Toma la fila que se acaba de agregar
                DataGridViewRow fila = dgvFichas.Rows[numeroFila];
                // Pinta la celda del estado de pago con su color
                PintarEstadoPago(fila.Cells[colEstadoPago.Index], reserva.EstadoPago);
                // Si está reservado...
                if (estado == "Reservado")
                {
                    // ...el texto "Reservado" va en azul
                    fila.Cells[colEstado.Index].Style.ForeColor = letraAzul;
                }
                // Si ya se consumió...
                else
                {
                    // ...el texto "Consumido" va en gris
                    fila.Cells[colEstado.Index].Style.ForeColor = letraGris;
                }
                // Si la reserva está pagada...
                if (reserva.EstadoPago == EstadoPago.Pagado)
                {
                    // ...suma su precio al total pagado
                    totalPagado = totalPagado + reserva.Precio;
                }
                // Si está pendiente...
                else if (reserva.EstadoPago == EstadoPago.Pendiente)
                {
                    // ...suma su precio al total pendiente
                    totalPendiente = totalPendiente + reserva.Precio;
                }
            }
            // Escribe cuántas reservas hay en total
            lblTotalAlmuerzos.Text = "Total de almuerzos: " + reservas.Count;
            // Escribe el total pagado en pesos
            lblTotalPagado.Text = "Total pagado: " + Formato.Pesos(totalPagado);
            // Escribe el total pendiente en pesos
            lblTotalPendiente.Text = "Total pendiente: " + Formato.Pesos(totalPendiente);
            // Quita la selección de la primera fila (la tabla es solo para mirar)
            dgvFichas.ClearSelection();
        }

        /// <summary>
        /// Pinta una celda según el estado de pago: Pagado en verde, Pendiente en amarillo y Gratis en azul.
        /// El color se mantiene aunque la fila esté seleccionada.
        /// </summary>
        /// <param name="celda">La celda de la columna "Estado de pago".</param>
        /// <param name="estadoPago">El estado de pago de la reserva.</param>
        private void PintarEstadoPago(DataGridViewCell celda, EstadoPago estadoPago)
        {
            // Color de fondo que le toca (se decide abajo)
            Color fondo;
            // Color de letra que le toca (se decide abajo)
            Color letra;
            // Si está pagado...
            if (estadoPago == EstadoPago.Pagado)
            {
                // ...fondo verde claro
                fondo = fondoVerde;
                // ...y letra verde oscura
                letra = letraVerde;
            }
            // Si está pendiente...
            else if (estadoPago == EstadoPago.Pendiente)
            {
                // ...fondo amarillo claro
                fondo = fondoAmarillo;
                // ...y letra café amarillenta
                letra = letraAmarilla;
            }
            // Si es gratis...
            else
            {
                // ...fondo azul claro
                fondo = fondoAzul;
                // ...y letra azul oscura
                letra = letraAzul;
            }
            // Pone el color de fondo
            celda.Style.BackColor = fondo;
            // Pone el color de letra
            celda.Style.ForeColor = letra;
            // Cuando la fila está seleccionada, el fondo sigue igual
            celda.Style.SelectionBackColor = fondo;
            // Cuando la fila está seleccionada, la letra sigue igual
            celda.Style.SelectionForeColor = letra;
        }
    }
}
