﻿// Archivo: Secciones/UcMenuDelDia.cs
// Sección "Menú del Día" (UserControl). La ve el encargado.
// Por ahora solo muestra su título grande y el texto "En construcción"; los controles están en UcMenuDelDia.Designer.cs.

// Trae los controles de Windows Forms (UserControl)
using System.Windows.Forms;

// Espacio de nombres de las secciones (carpeta Secciones)
namespace GastroSena.Secciones
{
    /// <summary>
    /// Sección "Menú del Día". FrmPanel la crea y la muestra en el área de contenido
    /// cuando se presiona el botón "Menú del Día" del menú lateral (btnMenuDelDia).
    /// </summary>
    public partial class UcMenuDelDia : UserControl
    {
        /// <summary>
        /// Constructor: se ejecuta cuando el panel crea la sección (new UcMenuDelDia()).
        /// Llama a InitializeComponent para crear el título, la descripción y la tarjeta "En construcción".
        /// </summary>
        public UcMenuDelDia()
        {
            // Crea los controles de la sección tal como se dibujaron en [Diseño]
            InitializeComponent();
        }
    }
}
