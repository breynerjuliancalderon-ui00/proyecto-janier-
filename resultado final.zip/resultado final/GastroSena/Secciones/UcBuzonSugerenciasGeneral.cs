﻿// Archivo: Secciones/UcBuzonSugerenciasGeneral.cs
// Sección "Buzón de Sugerencias" (UserControl) de los perfiles Instructor, Encargado e Invitado
// (el aprendiz usa UcBuzonSugerencias, que ya está completo).
// Por ahora solo muestra su título grande y el texto "En construcción"; los controles están en UcBuzonSugerenciasGeneral.Designer.cs.

// Trae los controles de Windows Forms (UserControl)
using System.Windows.Forms;

// Espacio de nombres de las secciones (carpeta Secciones)
namespace GastroSena.Secciones
{
    /// <summary>
    /// Sección "Buzón de Sugerencias" de Instructor, Encargado e Invitado. FrmPanel la crea y la muestra en el área de contenido
    /// cuando se presiona el botón "Buzón de Sugerencias" del menú lateral (btnBuzonSugerencias).
    /// </summary>
    public partial class UcBuzonSugerenciasGeneral : UserControl
    {
        /// <summary>
        /// Constructor: se ejecuta cuando el panel crea la sección (new UcBuzonSugerenciasGeneral()).
        /// Llama a InitializeComponent para crear el título, la descripción y la tarjeta "En construcción".
        /// </summary>
        public UcBuzonSugerenciasGeneral()
        {
            // Crea los controles de la sección tal como se dibujaron en [Diseño]
            InitializeComponent();
        }
    }
}
