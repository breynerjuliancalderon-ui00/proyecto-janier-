﻿// Archivo: Secciones/UcSolicitudesCuenta.cs
// Sección "Solicitudes de Cuenta" (UserControl). La ve el encargado.
// Por ahora solo muestra su título grande y el texto "En construcción"; los controles están en UcSolicitudesCuenta.Designer.cs.

// Trae los controles de Windows Forms (UserControl)
using System.Windows.Forms;

// Espacio de nombres de las secciones (carpeta Secciones)
namespace GastroSena.Secciones
{
    /// <summary>
    /// Sección "Solicitudes de Cuenta". FrmPanel la crea y la muestra en el área de contenido
    /// cuando se presiona el botón "Solicitudes de Cuenta" del menú lateral (btnSolicitudesCuenta).
    /// </summary>
    public partial class UcSolicitudesCuenta : UserControl
    {
        /// <summary>
        /// Constructor: se ejecuta cuando el panel crea la sección (new UcSolicitudesCuenta()).
        /// Llama a InitializeComponent para crear el título, la descripción y la tarjeta "En construcción".
        /// </summary>
        public UcSolicitudesCuenta()
        {
            // Crea los controles de la sección tal como se dibujaron en [Diseño]
            InitializeComponent();
        }
    }
}
