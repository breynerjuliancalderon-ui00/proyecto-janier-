﻿// Archivo: Secciones/UcGrupos.cs
// Sección "Grupos" (UserControl). La ve el encargado.
// Por ahora solo muestra su título grande y el texto "En construcción"; los controles están en UcGrupos.Designer.cs.

// Trae los controles de Windows Forms (UserControl)
using System.Windows.Forms;

// Espacio de nombres de las secciones (carpeta Secciones)
namespace GastroSena.Secciones
{
    /// <summary>
    /// Sección "Grupos". FrmPanel la crea y la muestra en el área de contenido
    /// cuando se presiona el botón "Grupos" del menú lateral (btnGrupos).
    /// </summary>
    public partial class UcGrupos : UserControl
    {
        /// <summary>
        /// Constructor: se ejecuta cuando el panel crea la sección (new UcGrupos()).
        /// Llama a InitializeComponent para crear el título, la descripción y la tarjeta "En construcción".
        /// </summary>
        public UcGrupos()
        {
            // Crea los controles de la sección tal como se dibujaron en [Diseño]
            InitializeComponent();
        }
    }
}
