﻿// Archivo: Secciones/UcBeneficiarios.cs
// Sección "Beneficiarios" (UserControl). La ve el encargado.
// Por ahora solo muestra su título grande y el texto "En construcción"; los controles están en UcBeneficiarios.Designer.cs.

// Trae los controles de Windows Forms (UserControl)
using System.Windows.Forms;

// Espacio de nombres de las secciones (carpeta Secciones)
namespace GastroSena.Secciones
{
    /// <summary>
    /// Sección "Beneficiarios". FrmPanel la crea y la muestra en el área de contenido
    /// cuando se presiona el botón "Beneficiarios" del menú lateral (btnBeneficiarios).
    /// </summary>
    public partial class UcBeneficiarios : UserControl
    {
        /// <summary>
        /// Constructor: se ejecuta cuando el panel crea la sección (new UcBeneficiarios()).
        /// Llama a InitializeComponent para crear el título, la descripción y la tarjeta "En construcción".
        /// </summary>
        public UcBeneficiarios()
        {
            // Crea los controles de la sección tal como se dibujaron en [Diseño]
            InitializeComponent();
        }
    }
}
