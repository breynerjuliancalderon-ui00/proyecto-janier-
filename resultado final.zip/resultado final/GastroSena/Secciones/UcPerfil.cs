﻿// Archivo: Secciones/UcPerfil.cs
// Sección "Perfil" del aprendiz (UserControl).
// Muestra Nombre, Documento, Correo, Ficha, Programa y Perfil. Con "Editar" se pueden cambiar
// el nombre, el correo y la ficha; "Guardar cambios" los valida y los guarda en datos.xml, y "Cancelar"
// los deshace. El instructor ve UcPerfilGeneral. Los controles están en UcPerfil.Designer.cs ([Diseño]).

// Trae EventArgs y EventHandler
using System;
// Trae Regex (para revisar que el correo tenga un formato válido)
using System.Text.RegularExpressions;
// Trae los controles de Windows Forms (UserControl, MessageBox)
using System.Windows.Forms;
// Trae AlmacenDatos (guarda el perfil en datos.xml)
using GastroSena.Datos;
// Trae la clase Usuario
using GastroSena.Modelos;

// Espacio de nombres de las secciones (carpeta Secciones)
namespace GastroSena.Secciones
{
    /// <summary>
    /// Sección "Perfil" del aprendiz. FrmPanel la crea cuando se presiona el botón "Perfil",
    /// le pasa el usuario con CargarDatos y escucha el evento PerfilGuardado para
    /// actualizar el nombre del encabezado.
    /// </summary>
    public partial class UcPerfil : UserControl
    {
        // Patrón de un correo válido: algo@algo.algo, sin espacios y con una sola @
        private const string PatronCorreo = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";
        // El usuario que se está mostrando (llega desde FrmPanel)
        private Usuario usuario;

        /// <summary>
        /// Evento que avisa que el perfil se guardó. FrmPanel lo usa para cambiar el nombre del encabezado.
        /// </summary>
        // "event" = otros pueden suscribirse (+=) para enterarse cuando pase
        public event EventHandler PerfilGuardado;

        /// <summary>
        /// Constructor: se ejecuta cuando el panel crea la sección (new UcPerfil()).
        /// Llama a InitializeComponent para crear los campos y los botones del diseñador.
        /// </summary>
        public UcPerfil()
        {
            // Crea los controles de la sección tal como se dibujaron en [Diseño]
            InitializeComponent();
        }

        /// <summary>
        /// Recibe el usuario que inició sesión y muestra sus datos en las cajas.
        /// </summary>
        /// <param name="usuario">El aprendiz que inició sesión.</param>
        public void CargarDatos(Usuario usuario)
        {
            // Guarda el usuario en el campo de la clase ("this." distingue el campo del parámetro)
            this.usuario = usuario;
            // Escribe sus datos en las cajas
            MostrarDatos();
        }

        /// <summary>
        /// Escribe en cada caja el dato del usuario. También sirve para deshacer cambios al cancelar.
        /// </summary>
        private void MostrarDatos()
        {
            // Nombre completo
            txtNombre.Text = usuario.NombreCompleto;
            // Documento
            txtDocumento.Text = usuario.Documento;
            // Correo
            txtCorreo.Text = usuario.Correo;
            // Ficha
            txtFicha.Text = usuario.Ficha;
            // Programa de formación
            txtPrograma.Text = usuario.Programa;
            // Perfil (por ejemplo "Aprendiz")
            txtRol.Text = usuario.Rol.ToString();
        }

        /// <summary>
        /// Entra o sale del modo de edición: habilita o bloquea Nombre, Correo y Ficha,
        /// y muestra "Editar" o los botones "Guardar cambios" y "Cancelar".
        /// </summary>
        /// <param name="editando">true para editar; false para solo mirar.</param>
        private void CambiarModoEdicion(bool editando)
        {
            // El nombre se puede escribir solo mientras se edita (! = "no")
            txtNombre.ReadOnly = !editando;
            // El correo se puede escribir solo mientras se edita
            txtCorreo.ReadOnly = !editando;
            // La ficha se puede escribir solo mientras se edita
            txtFicha.ReadOnly = !editando;
            // "Editar" se ve solo cuando NO se está editando
            btnEditar.Visible = !editando;
            // "Guardar cambios" se ve solo mientras se edita
            btnGuardar.Visible = editando;
            // "Cancelar" se ve solo mientras se edita
            btnCancelar.Visible = editando;
            // Si se terminó de editar...
            if (!editando)
            {
                // ...deja el cursor en el botón Editar (así ninguna caja queda con el texto marcado)
                btnEditar.Focus();
            }
        }

        /// <summary>
        /// Revisa los datos escritos: el nombre no puede estar vacío y el correo debe tener un formato válido.
        /// Marca con el ErrorProvider cada campo que esté mal.
        /// </summary>
        /// <returns>true si todo está bien; false si hay algún error.</returns>
        private bool ValidarDatos()
        {
            // Quita los errores que hubiera de antes
            errorProvider.Clear();
            // Empieza suponiendo que todo está bien
            bool todoBien = true;
            // Si el nombre está vacío (o solo tiene espacios)...
            if (txtNombre.Text.Trim() == "")
            {
                // ...muestra el error junto a la caja
                errorProvider.SetError(txtNombre, "Escribe tu nombre completo.");
                // ...y anota que hay un error
                todoBien = false;
            }
            // Si el correo no cumple el patrón algo@algo.algo...
            if (!Regex.IsMatch(txtCorreo.Text.Trim(), PatronCorreo))
            {
                // ...muestra el error junto a la caja
                errorProvider.SetError(txtCorreo, "Escribe un correo válido, por ejemplo nombre@soy.sena.edu.co.");
                // ...y anota que hay un error
                todoBien = false;
            }
            // Devuelve si todo quedó bien
            return todoBien;
        }

        /// <summary>
        /// Clic en "Editar": habilita Nombre, Correo y Ficha y pone el cursor en el nombre.
        /// </summary>
        /// <param name="sender">El botón Editar.</param>
        /// <param name="e">Datos del evento (aquí no se usan).</param>
        private void btnEditar_Click(object sender, EventArgs e)
        {
            // Entra al modo de edición
            CambiarModoEdicion(true);
            // Pone el cursor en la caja del nombre
            txtNombre.Focus();
        }

        /// <summary>
        /// Clic en "Guardar cambios": valida; si todo está bien, guarda en datos.xml, avisa a FrmPanel
        /// para que cambie el nombre del encabezado y muestra un mensaje.
        /// </summary>
        /// <param name="sender">El botón Guardar cambios.</param>
        /// <param name="e">Datos del evento (aquí no se usan).</param>
        private void btnGuardar_Click(object sender, EventArgs e)
        {
            // Si algún dato está mal...
            if (!ValidarDatos())
            {
                // ...no guarda (los errores ya se ven junto a cada campo)
                return;
            }
            // Pasa el nombre nuevo al usuario (sin espacios en las puntas)
            usuario.NombreCompleto = txtNombre.Text.Trim();
            // Pasa el correo nuevo al usuario
            usuario.Correo = txtCorreo.Text.Trim();
            // Pasa la ficha nueva al usuario
            usuario.Ficha = txtFicha.Text.Trim();
            // Guarda el perfil en el archivo datos.xml
            AlmacenDatos.GuardarPerfil(usuario);
            // Vuelve a escribir los datos en las cajas (ya sin espacios sobrantes)
            MostrarDatos();
            // Sale del modo de edición
            CambiarModoEdicion(false);
            // Si alguien está escuchando el evento (FrmPanel)...
            if (PerfilGuardado != null)
            {
                // ...le avisa que el perfil se guardó
                PerfilGuardado(this, EventArgs.Empty);
            }
            // Muestra el mensaje de confirmación
            MessageBox.Show("¡Perfil actualizado correctamente!", "GastroSENA", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        /// <summary>
        /// Clic en "Cancelar": borra los errores, vuelve a poner los datos guardados y sale del modo de edición.
        /// </summary>
        /// <param name="sender">El botón Cancelar.</param>
        /// <param name="e">Datos del evento (aquí no se usan).</param>
        private void btnCancelar_Click(object sender, EventArgs e)
        {
            // Quita los íconos de error
            errorProvider.Clear();
            // Deshace los cambios: vuelve a escribir los datos guardados
            MostrarDatos();
            // Sale del modo de edición
            CambiarModoEdicion(false);
        }
    }
}
