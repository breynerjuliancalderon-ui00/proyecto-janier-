﻿// Archivo: Secciones/UcVentas.cs
// Sección "Ventas" (UserControl). La ve el encargado.
// Por ahora solo muestra su título grande y el texto "En construcción"; los controles están en UcVentas.Designer.cs.

// Trae los controles de Windows Forms (UserControl)
using System.Windows.Forms;

// Espacio de nombres de las secciones (carpeta Secciones)
namespace GastroSena.Secciones
{
    /// <summary>
    /// Sección "Ventas". FrmPanel la crea y la muestra en el área de contenido
    /// cuando se presiona el botón "Ventas" del menú lateral (btnVentas).
    /// </summary>
    public partial class UcVentas : UserControl
    {
        /// <summary>
        /// Constructor: se ejecuta cuando el panel crea la sección (new UcVentas()).
        /// Llama a InitializeComponent para crear el título, la descripción y la tarjeta "En construcción".
        /// </summary>
        public UcVentas()
        {
            // Crea los controles de la sección tal como se dibujaron en [Diseño]
            InitializeComponent();
        }
    }
}
