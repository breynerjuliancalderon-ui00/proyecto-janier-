﻿// Archivo: Secciones/UcBuzonSugerencias.cs
// Sección "Buzón de Sugerencias" del aprendiz (UserControl).
// Tiene un formulario (Asunto y Mensaje) que se valida con un ErrorProvider, un contador de caracteres
// y la tabla "Mis sugerencias" con la respuesta del comedor. Los otros perfiles ven UcBuzonSugerenciasGeneral.
// Los controles están en UcBuzonSugerencias.Designer.cs ([Diseño]).

// Trae EventArgs
using System;
// Trae los colores (Color) para pintar los estados
using System.Drawing;
// Trae los controles de Windows Forms (UserControl, DataGridView, MessageBox)
using System.Windows.Forms;
// Trae AlmacenDatos (las sugerencias guardadas en datos.xml)
using GastroSena.Datos;
// Trae las clases Sugerencia y EstadoSugerencia
using GastroSena.Modelos;
// Trae Formato (fechas al estilo de Colombia)
using GastroSena.Utilidades;

// Espacio de nombres de las secciones (carpeta Secciones)
namespace GastroSena.Secciones
{
    /// <summary>
    /// Sección "Buzón de Sugerencias" del aprendiz. FrmPanel la crea cuando se presiona
    /// el botón "Buzón de Sugerencias" del menú lateral.
    /// </summary>
    public partial class UcBuzonSugerencias : UserControl
    {
        // Mínimo de caracteres del asunto
        private const int MinimoAsunto = 3;
        // Máximo de caracteres del asunto (igual al MaxLength de txtAsunto)
        private const int MaximoAsunto = 150;
        // Mínimo de caracteres del mensaje
        private const int MinimoMensaje = 10;
        // Máximo de caracteres del mensaje (igual al MaxLength de txtMensaje)
        private const int MaximoMensaje = 2000;
        // Atendida: fondo verde claro
        private readonly Color fondoVerde = Color.FromArgb(220, 252, 231);
        // Atendida: letra verde oscura
        private readonly Color letraVerde = Color.FromArgb(22, 101, 52);
        // Pendiente: fondo amarillo claro
        private readonly Color fondoAmarillo = Color.FromArgb(254, 249, 195);
        // Pendiente: letra café amarillenta
        private readonly Color letraAmarilla = Color.FromArgb(133, 77, 14);
        // Texto "Todavía no hay respuesta": letra gris
        private readonly Color letraGris = Color.FromArgb(107, 114, 128);

        /// <summary>
        /// Constructor: se ejecuta cuando el panel crea la sección (new UcBuzonSugerencias()).
        /// Llama a InitializeComponent para crear el formulario y la tabla del diseñador.
        /// </summary>
        public UcBuzonSugerencias()
        {
            // Crea los controles de la sección tal como se dibujaron en [Diseño]
            InitializeComponent();
        }

        /// <summary>
        /// Evento Load: se ejecuta una vez, cuando la sección aparece en el panel.
        /// Llena la tabla "Mis sugerencias".
        /// </summary>
        /// <param name="sender">La sección que lanzó el evento.</param>
        /// <param name="e">Datos del evento (aquí no se usan).</param>
        private void UcBuzonSugerencias_Load(object sender, EventArgs e)
        {
            // Llena la tabla con las sugerencias guardadas
            CargarSugerencias();
        }

        /// <summary>
        /// Pone una fila en la tabla por cada sugerencia, de la más reciente a la más antigua,
        /// con el estado en colores y la respuesta del comedor.
        /// </summary>
        private void CargarSugerencias()
        {
            // Borra las filas que hubiera
            dgvSugerencias.Rows.Clear();
            // Recorre las sugerencias ya ordenadas de la más reciente a la más antigua
            foreach (Sugerencia sugerencia in AlmacenDatos.ObtenerSugerencias())
            {
                // Texto de la respuesta (se decide abajo)
                string respuesta;
                // Si el comedor no ha respondido (respuesta vacía o null)...
                if (string.IsNullOrWhiteSpace(sugerencia.Respuesta))
                {
                    // ...lo dice así
                    respuesta = "Todavía no hay respuesta";
                }
                // Si ya respondió...
                else
                {
                    // ...muestra la respuesta
                    respuesta = sugerencia.Respuesta;
                }
                // Agrega la fila con los cuatro valores, en el orden de las columnas, y guarda su número
                int numeroFila = dgvSugerencias.Rows.Add(Formato.FechaCorta(sugerencia.Fecha), sugerencia.Asunto, sugerencia.Estado.ToString(), respuesta);
                // Toma la fila que se acaba de agregar
                DataGridViewRow fila = dgvSugerencias.Rows[numeroFila];
                // Al pasar el mouse por el asunto se ve el mensaje completo
                fila.Cells[colAsunto.Index].ToolTipText = sugerencia.Mensaje;
                // Toma la celda del estado para pintarla
                DataGridViewCell celdaEstado = fila.Cells[colEstado.Index];
                // Si la sugerencia ya fue atendida...
                if (sugerencia.Estado == EstadoSugerencia.Atendida)
                {
                    // ...fondo verde claro
                    celdaEstado.Style.BackColor = fondoVerde;
                    // ...letra verde oscura
                    celdaEstado.Style.ForeColor = letraVerde;
                }
                // Si está pendiente...
                else
                {
                    // ...fondo amarillo claro
                    celdaEstado.Style.BackColor = fondoAmarillo;
                    // ...letra café amarillenta
                    celdaEstado.Style.ForeColor = letraAmarilla;
                    // ...y el texto "Todavía no hay respuesta" en gris
                    fila.Cells[colRespuesta.Index].Style.ForeColor = letraGris;
                }
                // Cuando la fila está seleccionada, el estado conserva su fondo
                celdaEstado.Style.SelectionBackColor = celdaEstado.Style.BackColor;
                // Cuando la fila está seleccionada, el estado conserva su letra
                celdaEstado.Style.SelectionForeColor = celdaEstado.Style.ForeColor;
            }
            // Quita la selección de la primera fila (la tabla es solo para mirar)
            dgvSugerencias.ClearSelection();
        }

        /// <summary>
        /// Revisa el asunto: debe tener de 3 a 150 caracteres (sin contar espacios al principio y al final).
        /// Si está mal, pone el ícono de error junto a la caja; si está bien, lo quita.
        /// </summary>
        /// <returns>true si el asunto está bien; false si no.</returns>
        private bool ValidarAsunto()
        {
            // Cuenta los caracteres del asunto sin los espacios de las puntas
            int largo = txtAsunto.Text.Trim().Length;
            // Si es muy corto...
            if (largo < MinimoAsunto)
            {
                // ...muestra el error junto a la caja
                errorProvider.SetError(txtAsunto, "El asunto debe tener al menos " + MinimoAsunto + " caracteres.");
                // ...y dice que está mal
                return false;
            }
            // Si es muy largo...
            if (largo > MaximoAsunto)
            {
                // ...muestra el error junto a la caja
                errorProvider.SetError(txtAsunto, "El asunto no debe superar " + MaximoAsunto + " caracteres.");
                // ...y dice que está mal
                return false;
            }
            // Está bien: quita el error ("" = sin error)
            errorProvider.SetError(txtAsunto, "");
            // Dice que está bien
            return true;
        }

        /// <summary>
        /// Revisa el mensaje: debe tener de 10 a 2000 caracteres (sin contar espacios al principio y al final).
        /// Si está mal, pone el ícono de error junto a la caja; si está bien, lo quita.
        /// </summary>
        /// <returns>true si el mensaje está bien; false si no.</returns>
        private bool ValidarMensaje()
        {
            // Cuenta los caracteres del mensaje sin los espacios de las puntas
            int largo = txtMensaje.Text.Trim().Length;
            // Si es muy corto...
            if (largo < MinimoMensaje)
            {
                // ...muestra el error junto a la caja
                errorProvider.SetError(txtMensaje, "El mensaje debe tener al menos " + MinimoMensaje + " caracteres.");
                // ...y dice que está mal
                return false;
            }
            // Si es muy largo...
            if (largo > MaximoMensaje)
            {
                // ...muestra el error junto a la caja
                errorProvider.SetError(txtMensaje, "El mensaje no debe superar " + MaximoMensaje + " caracteres.");
                // ...y dice que está mal
                return false;
            }
            // Está bien: quita el error
            errorProvider.SetError(txtMensaje, "");
            // Dice que está bien
            return true;
        }

        /// <summary>
        /// Cada vez que cambia el texto del asunto: si tenía un error marcado, lo vuelve a revisar
        /// para quitarlo apenas quede bien escrito.
        /// </summary>
        /// <param name="sender">La caja txtAsunto.</param>
        /// <param name="e">Datos del evento (aquí no se usan).</param>
        private void txtAsunto_TextChanged(object sender, EventArgs e)
        {
            // Si la caja tiene un error marcado...
            if (errorProvider.GetError(txtAsunto) != "")
            {
                // ...la vuelve a revisar
                ValidarAsunto();
            }
        }

        /// <summary>
        /// Cada vez que cambia el texto del mensaje: actualiza el contador de caracteres y,
        /// si tenía un error marcado, lo vuelve a revisar.
        /// </summary>
        /// <param name="sender">La caja txtMensaje.</param>
        /// <param name="e">Datos del evento (aquí no se usan).</param>
        private void txtMensaje_TextChanged(object sender, EventArgs e)
        {
            // Escribe cuántos caracteres lleva, por ejemplo "125 / 2000 caracteres"
            lblContador.Text = txtMensaje.TextLength + " / " + MaximoMensaje + " caracteres";
            // Si la caja tiene un error marcado...
            if (errorProvider.GetError(txtMensaje) != "")
            {
                // ...la vuelve a revisar
                ValidarMensaje();
            }
        }

        /// <summary>
        /// Clic en "Enviar sugerencia": valida los dos campos; si están bien, guarda la sugerencia
        /// como "Pendiente", limpia el formulario, actualiza la tabla y muestra un mensaje de confirmación.
        /// </summary>
        /// <param name="sender">El botón Enviar sugerencia.</param>
        /// <param name="e">Datos del evento (aquí no se usan).</param>
        private void btnEnviar_Click(object sender, EventArgs e)
        {
            // Revisa el asunto (pone o quita su error)
            bool asuntoBien = ValidarAsunto();
            // Revisa el mensaje (pone o quita su error)
            bool mensajeBien = ValidarMensaje();
            // Si el asunto está mal...
            if (!asuntoBien)
            {
                // ...pone el cursor en la caja del asunto
                txtAsunto.Focus();
                // ...y no envía
                return;
            }
            // Si el mensaje está mal...
            if (!mensajeBien)
            {
                // ...pone el cursor en la caja del mensaje
                txtMensaje.Focus();
                // ...y no envía
                return;
            }
            // Guarda la sugerencia como "Pendiente" (sin los espacios de las puntas)
            AlmacenDatos.AgregarSugerencia(txtAsunto.Text.Trim(), txtMensaje.Text.Trim());
            // Borra el asunto
            txtAsunto.Clear();
            // Borra el mensaje (el contador vuelve a 0 solo)
            txtMensaje.Clear();
            // Quita cualquier ícono de error
            errorProvider.Clear();
            // Vuelve a llenar la tabla para que se vea la sugerencia nueva arriba
            CargarSugerencias();
            // Muestra el mensaje de confirmación
            MessageBox.Show("¡Sugerencia enviada con éxito!\n\nGracias por tu aporte. El encargado del comedor revisará tu mensaje.", "GastroSENA", MessageBoxButtons.OK, MessageBoxIcon.Information);
            // Deja el cursor en el asunto, listo para otra sugerencia
            txtAsunto.Focus();
        }
    }
}
