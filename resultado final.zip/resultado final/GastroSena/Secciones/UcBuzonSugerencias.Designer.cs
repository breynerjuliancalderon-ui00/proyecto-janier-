﻿// Visual Studio regenera este archivo cuando se edita en [Diseño], y los comentarios de adentro se pueden borrar.
// Archivo: Secciones/UcBuzonSugerencias.Designer.cs
// Parte "de diseño" de la sección "Buzón de Sugerencias" del aprendiz: aquí se crean el título,
// la tarjeta del formulario (Asunto, Mensaje con contador y botón "Enviar sugerencia"),
// el ErrorProvider que marca los errores junto a cada campo y la tarjeta "Mis sugerencias" con su tabla.
// Para cambiarla, abre UcBuzonSugerencias.cs en la vista [Diseño].

// Espacio de nombres de las secciones (carpeta Secciones)
namespace GastroSena.Secciones
{
    /// <summary>
    /// Segunda parte (partial) de la clase UcBuzonSugerencias: contiene el código que escribe el diseñador.
    /// La otra parte, con la lógica, está en UcBuzonSugerencias.cs.
    /// </summary>
    partial class UcBuzonSugerencias
    {
        /// <summary>
        /// Variable del diseñador necesaria: guarda los componentes que hay que liberar al cerrar (aquí, el ErrorProvider).
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpia los recursos que se estén usando. Se ejecuta cuando la sección se cambia por otra.
        /// </summary>
        /// <param name="disposing">true si se deben liberar los recursos administrados; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            // Si se están liberando recursos y hay componentes guardados...
            if (disposing && (components != null))
            {
                // ...los libera
                components.Dispose();
            }
            // Llama al Dispose de la clase base (UserControl) para que termine de limpiar
            base.Dispose(disposing);
        }

        // Región con el código que escribe el Diseñador de componentes
        #region Código generado por el Diseñador de componentes

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// Crea los controles de la sección, les pone sus propiedades, los agrega y conecta sus eventos.
        /// </summary>
        private void InitializeComponent()
        {
            // Crea el contenedor de componentes (aquí se guarda el ErrorProvider)
            this.components = new System.ComponentModel.Container();
            // Estilo de los encabezados de la tabla (fondo gris verdoso y letra seminegrita)
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            // Estilo de la columna "Estado" (letra seminegrita)
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            // Estilo normal de las celdas de la tabla
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            // Crea la etiqueta del título grande
            this.lblTitulo = new System.Windows.Forms.Label();
            // Crea la etiqueta de la descripción
            this.lblDescripcion = new System.Windows.Forms.Label();
            // Crea la tabla que acomoda las dos tarjetas una debajo de la otra
            this.tlpBuzon = new System.Windows.Forms.TableLayoutPanel();
            // Crea la tarjeta blanca del formulario
            this.pnlFormulario = new System.Windows.Forms.Panel();
            // Crea el botón "Enviar sugerencia"
            this.btnEnviar = new System.Windows.Forms.Button();
            // Crea la etiqueta del contador de caracteres
            this.lblContador = new System.Windows.Forms.Label();
            // Crea la caja de texto del mensaje
            this.txtMensaje = new System.Windows.Forms.TextBox();
            // Crea la etiqueta "Mensaje"
            this.lblMensaje = new System.Windows.Forms.Label();
            // Crea la caja de texto del asunto
            this.txtAsunto = new System.Windows.Forms.TextBox();
            // Crea la etiqueta "Asunto"
            this.lblAsunto = new System.Windows.Forms.Label();
            // Crea la tarjeta blanca "Mis sugerencias"
            this.pnlMisSugerencias = new System.Windows.Forms.Panel();
            // Crea la tabla de sugerencias
            this.dgvSugerencias = new System.Windows.Forms.DataGridView();
            // Crea la columna "Fecha"
            this.colFecha = new System.Windows.Forms.DataGridViewTextBoxColumn();
            // Crea la columna "Asunto"
            this.colAsunto = new System.Windows.Forms.DataGridViewTextBoxColumn();
            // Crea la columna "Estado"
            this.colEstado = new System.Windows.Forms.DataGridViewTextBoxColumn();
            // Crea la columna "Respuesta del comedor"
            this.colRespuesta = new System.Windows.Forms.DataGridViewTextBoxColumn();
            // Crea la etiqueta "Mis sugerencias"
            this.lblMisSugerencias = new System.Windows.Forms.Label();
            // Crea el ErrorProvider: muestra un ícono rojo junto al campo que tiene un error
            this.errorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            // Pausa el acomodo de la tabla principal mientras se configura
            this.tlpBuzon.SuspendLayout();
            // Pausa el acomodo de la tarjeta del formulario
            this.pnlFormulario.SuspendLayout();
            // Pausa el acomodo de la tarjeta "Mis sugerencias"
            this.pnlMisSugerencias.SuspendLayout();
            // Avisa a la tabla de sugerencias que empieza su configuración
            ((System.ComponentModel.ISupportInitialize)(this.dgvSugerencias)).BeginInit();
            // Avisa al ErrorProvider que empieza su configuración
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).BeginInit();
            // Pausa el acomodo de la sección mientras se configura
            this.SuspendLayout();
            //
            // lblTitulo
            // Título grande "Buzón de Sugerencias": arriba de todo, Segoe UI de 20 puntos en negrita.
            //
            // Pegada arriba, ocupando todo el ancho
            this.lblTitulo.Dock = System.Windows.Forms.DockStyle.Top;
            // Letra Segoe UI de 20 puntos en negrita
            this.lblTitulo.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Color casi negro
            this.lblTitulo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(41)))), ((int)(((byte)(51)))));
            // Posición: arriba a la izquierda
            this.lblTitulo.Location = new System.Drawing.Point(0, 0);
            // Nombre del control
            this.lblTitulo.Name = "lblTitulo";
            // Tamaño: todo el ancho y 48 de alto
            this.lblTitulo.Size = new System.Drawing.Size(980, 48);
            // Orden de tabulación
            this.lblTitulo.TabIndex = 0;
            // Texto que se muestra
            this.lblTitulo.Text = "Buzón de Sugerencias";
            // Texto alineado a la izquierda y centrado de arriba a abajo
            this.lblTitulo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            //
            // lblDescripcion
            // Descripción gris de para qué sirve la sección, debajo del título.
            //
            // Pegada arriba, debajo del título
            this.lblDescripcion.Dock = System.Windows.Forms.DockStyle.Top;
            // Letra Segoe UI de 11 puntos
            this.lblDescripcion.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Color gris
            this.lblDescripcion.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(114)))), ((int)(((byte)(128)))));
            // Posición: debajo del título
            this.lblDescripcion.Location = new System.Drawing.Point(0, 48);
            // Nombre del control
            this.lblDescripcion.Name = "lblDescripcion";
            // Tamaño: todo el ancho; el alto deja un espacio antes de las tarjetas
            this.lblDescripcion.Size = new System.Drawing.Size(980, 44);
            // Orden de tabulación
            this.lblDescripcion.TabIndex = 1;
            // Texto que se muestra
            this.lblDescripcion.Text = "Comparte tus ideas o comentarios para mejorar el servicio. El encargado del comedor revisará tu mensaje.";
            //
            // tlpBuzon
            // Tabla de una columna: fila 0 = formulario (alto fijo), fila 1 = "Mis sugerencias" (el resto).
            //
            // Una sola columna
            this.tlpBuzon.ColumnCount = 1;
            // La columna ocupa el 100% del ancho
            this.tlpBuzon.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            // Pone el formulario en la columna 0, fila 0
            this.tlpBuzon.Controls.Add(this.pnlFormulario, 0, 0);
            // Pone "Mis sugerencias" en la columna 0, fila 1
            this.tlpBuzon.Controls.Add(this.pnlMisSugerencias, 0, 1);
            // Ocupa todo el espacio que sobra debajo de la descripción
            this.tlpBuzon.Dock = System.Windows.Forms.DockStyle.Fill;
            // Posición: debajo de la descripción
            this.tlpBuzon.Location = new System.Drawing.Point(0, 92);
            // Nombre del control
            this.tlpBuzon.Name = "tlpBuzon";
            // Dos filas
            this.tlpBuzon.RowCount = 2;
            // Fila 0 (formulario): 300 de alto
            this.tlpBuzon.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 300F));
            // Fila 1 (Mis sugerencias): todo el alto que sobre
            this.tlpBuzon.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            // Tamaño (lo calcula el Dock)
            this.tlpBuzon.Size = new System.Drawing.Size(980, 508);
            // Orden de tabulación
            this.tlpBuzon.TabIndex = 2;
            //
            // pnlFormulario
            // Tarjeta blanca con el formulario. Los controles de adentro se acomodan con Anchor:
            // las cajas de texto se estiran a lo ancho cuando la ventana crece.
            //
            // Fondo blanco
            this.pnlFormulario.BackColor = System.Drawing.Color.White;
            // Agrega el botón Enviar
            this.pnlFormulario.Controls.Add(this.btnEnviar);
            // Agrega el contador de caracteres
            this.pnlFormulario.Controls.Add(this.lblContador);
            // Agrega la caja del mensaje
            this.pnlFormulario.Controls.Add(this.txtMensaje);
            // Agrega la etiqueta "Mensaje"
            this.pnlFormulario.Controls.Add(this.lblMensaje);
            // Agrega la caja del asunto
            this.pnlFormulario.Controls.Add(this.txtAsunto);
            // Agrega la etiqueta "Asunto"
            this.pnlFormulario.Controls.Add(this.lblAsunto);
            // Ocupa toda su celda de la tabla
            this.pnlFormulario.Dock = System.Windows.Forms.DockStyle.Fill;
            // Posición: arriba de la tabla
            this.pnlFormulario.Location = new System.Drawing.Point(0, 0);
            // Margen: 16 abajo para separarla de "Mis sugerencias"
            this.pnlFormulario.Margin = new System.Windows.Forms.Padding(0, 0, 0, 16);
            // Nombre del control
            this.pnlFormulario.Name = "pnlFormulario";
            // Tamaño (lo calcula el Dock)
            this.pnlFormulario.Size = new System.Drawing.Size(980, 284);
            // Orden de tabulación
            this.pnlFormulario.TabIndex = 0;
            //
            // btnEnviar
            // Botón verde "Enviar sugerencia". Al hacer clic se ejecuta btnEnviar_Click (en UcBuzonSugerencias.cs).
            //
            // Fondo verde SENA
            this.btnEnviar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(169)))), ((int)(((byte)(0)))));
            // Puntero de mano
            this.btnEnviar.Cursor = System.Windows.Forms.Cursors.Hand;
            // Sin borde
            this.btnEnviar.FlatAppearance.BorderSize = 0;
            // Verde más oscuro mientras se mantiene presionado
            this.btnEnviar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(115)))), ((int)(((byte)(0)))));
            // Verde oscuro al pasar el mouse
            this.btnEnviar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(0)))));
            // Estilo plano (Flat)
            this.btnEnviar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            // Letra Segoe UI Semibold de 11 puntos
            this.btnEnviar.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Letra blanca
            this.btnEnviar.ForeColor = System.Drawing.Color.White;
            // Posición: abajo a la izquierda de la tarjeta
            this.btnEnviar.Location = new System.Drawing.Point(24, 228);
            // Nombre del control
            this.btnEnviar.Name = "btnEnviar";
            // Tamaño: 200 de ancho y 40 de alto
            this.btnEnviar.Size = new System.Drawing.Size(200, 40);
            // Orden de tabulación
            this.btnEnviar.TabIndex = 5;
            // Texto del botón
            this.btnEnviar.Text = "Enviar sugerencia";
            // Usa el BackColor que pusimos, no el color del tema de Windows
            this.btnEnviar.UseVisualStyleBackColor = false;
            // Conecta el clic con el método btnEnviar_Click (en UcBuzonSugerencias.cs)
            this.btnEnviar.Click += new System.EventHandler(this.btnEnviar_Click);
            //
            // lblContador
            // Contador de caracteres del mensaje, a la derecha debajo de la caja. Lo actualiza UcBuzonSugerencias.cs.
            //
            // Anclado arriba a la derecha: se mueve con el borde derecho cuando la ventana crece
            this.lblContador.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            // Letra Segoe UI de 9 puntos
            this.lblContador.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Color gris
            this.lblContador.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(114)))), ((int)(((byte)(128)))));
            // Posición: debajo de la caja del mensaje, pegada a su borde derecho
            this.lblContador.Location = new System.Drawing.Point(732, 197);
            // Nombre del control
            this.lblContador.Name = "lblContador";
            // Tamaño: 200 de ancho y 20 de alto
            this.lblContador.Size = new System.Drawing.Size(200, 20);
            // Orden de tabulación
            this.lblContador.TabIndex = 4;
            // Texto inicial (caja vacía)
            this.lblContador.Text = "0 / 2000 caracteres";
            // Texto alineado a la derecha
            this.lblContador.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            //
            // txtMensaje
            // Caja de varias líneas para el mensaje (de 10 a 2000 caracteres).
            //
            // Anclada arriba, a la izquierda y a la derecha: se estira a lo ancho
            this.txtMensaje.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            // Posición: debajo de la etiqueta "Mensaje"
            this.txtMensaje.Location = new System.Drawing.Point(24, 98);
            // No deja escribir más de 2000 caracteres
            this.txtMensaje.MaxLength = 2000;
            // Permite varias líneas
            this.txtMensaje.Multiline = true;
            // Nombre del control
            this.txtMensaje.Name = "txtMensaje";
            // Barra de desplazamiento vertical si el texto no cabe
            this.txtMensaje.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            // Tamaño: casi todo el ancho (deja espacio para el ícono de error) y 96 de alto
            this.txtMensaje.Size = new System.Drawing.Size(908, 96);
            // Orden de tabulación
            this.txtMensaje.TabIndex = 3;
            // Conecta el cambio de texto con txtMensaje_TextChanged (actualiza el contador)
            this.txtMensaje.TextChanged += new System.EventHandler(this.txtMensaje_TextChanged);
            //
            // lblMensaje
            // Etiqueta "Mensaje" encima de su caja.
            //
            // El tamaño se ajusta solo al texto
            this.lblMensaje.AutoSize = true;
            // Letra Segoe UI Semibold
            this.lblMensaje.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Color gris oscuro
            this.lblMensaje.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(65)))), ((int)(((byte)(81)))));
            // Posición: debajo de la caja del asunto
            this.lblMensaje.Location = new System.Drawing.Point(24, 76);
            // Nombre del control
            this.lblMensaje.Name = "lblMensaje";
            // Tamaño calculado por el AutoSize
            this.lblMensaje.Size = new System.Drawing.Size(60, 17);
            // Orden de tabulación
            this.lblMensaje.TabIndex = 2;
            // Texto que se muestra
            this.lblMensaje.Text = "Mensaje";
            //
            // txtAsunto
            // Caja de una línea para el asunto (de 3 a 150 caracteres).
            //
            // Anclada arriba, a la izquierda y a la derecha: se estira a lo ancho
            this.txtAsunto.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            // Posición: debajo de la etiqueta "Asunto"
            this.txtAsunto.Location = new System.Drawing.Point(24, 38);
            // No deja escribir más de 150 caracteres
            this.txtAsunto.MaxLength = 150;
            // Nombre del control
            this.txtAsunto.Name = "txtAsunto";
            // Tamaño: casi todo el ancho (deja espacio para el ícono de error)
            this.txtAsunto.Size = new System.Drawing.Size(908, 25);
            // Orden de tabulación
            this.txtAsunto.TabIndex = 1;
            // Conecta el cambio de texto con txtAsunto_TextChanged (quita el error cuando ya está bien)
            this.txtAsunto.TextChanged += new System.EventHandler(this.txtAsunto_TextChanged);
            //
            // lblAsunto
            // Etiqueta "Asunto" encima de su caja.
            //
            // El tamaño se ajusta solo al texto
            this.lblAsunto.AutoSize = true;
            // Letra Segoe UI Semibold
            this.lblAsunto.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Color gris oscuro
            this.lblAsunto.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(65)))), ((int)(((byte)(81)))));
            // Posición: arriba a la izquierda de la tarjeta
            this.lblAsunto.Location = new System.Drawing.Point(24, 16);
            // Nombre del control
            this.lblAsunto.Name = "lblAsunto";
            // Tamaño calculado por el AutoSize
            this.lblAsunto.Size = new System.Drawing.Size(50, 17);
            // Orden de tabulación
            this.lblAsunto.TabIndex = 0;
            // Texto que se muestra
            this.lblAsunto.Text = "Asunto";
            //
            // pnlMisSugerencias
            // Tarjeta blanca "Mis sugerencias": el título arriba y la tabla debajo.
            //
            // Fondo blanco
            this.pnlMisSugerencias.BackColor = System.Drawing.Color.White;
            // Agrega la tabla (primero, para que su Dock Fill se acomode al final)
            this.pnlMisSugerencias.Controls.Add(this.dgvSugerencias);
            // Agrega el título (queda arriba con Dock Top)
            this.pnlMisSugerencias.Controls.Add(this.lblMisSugerencias);
            // Ocupa toda su celda de la tabla
            this.pnlMisSugerencias.Dock = System.Windows.Forms.DockStyle.Fill;
            // Posición: debajo del formulario
            this.pnlMisSugerencias.Location = new System.Drawing.Point(0, 300);
            // Sin margen alrededor
            this.pnlMisSugerencias.Margin = new System.Windows.Forms.Padding(0);
            // Nombre del control
            this.pnlMisSugerencias.Name = "pnlMisSugerencias";
            // Margen interior: 24 a los lados y abajo, 16 arriba
            this.pnlMisSugerencias.Padding = new System.Windows.Forms.Padding(24, 16, 24, 24);
            // Tamaño (lo calcula el Dock)
            this.pnlMisSugerencias.Size = new System.Drawing.Size(980, 208);
            // Orden de tabulación
            this.pnlMisSugerencias.TabIndex = 1;
            //
            // dgvSugerencias
            // Tabla de solo lectura con las sugerencias. Las filas las agrega UcBuzonSugerencias.cs.
            //
            // No deja agregar filas escribiendo en la tabla
            this.dgvSugerencias.AllowUserToAddRows = false;
            // No deja borrar filas con la tecla Supr
            this.dgvSugerencias.AllowUserToDeleteRows = false;
            // No deja cambiar el alto de las filas con el mouse
            this.dgvSugerencias.AllowUserToResizeRows = false;
            // Las columnas se reparten todo el ancho de la tabla
            this.dgvSugerencias.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            // Cada fila crece a lo alto para que se lea la respuesta completa
            this.dgvSugerencias.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            // Fondo blanco donde no hay filas
            this.dgvSugerencias.BackgroundColor = System.Drawing.Color.White;
            // Sin borde alrededor de la tabla
            this.dgvSugerencias.BorderStyle = System.Windows.Forms.BorderStyle.None;
            // Solo líneas horizontales entre filas
            this.dgvSugerencias.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            // Encabezados sin borde
            this.dgvSugerencias.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            // Encabezado: texto a la izquierda y centrado de arriba a abajo
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            // Encabezado: fondo gris verdoso muy claro
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(245)))), ((int)(((byte)(241)))));
            // Encabezado: letra Segoe UI Semibold
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Encabezado: letra gris oscura
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(65)))), ((int)(((byte)(81)))));
            // Encabezado: 8 píxeles de espacio a la izquierda del texto
            dataGridViewCellStyle1.Padding = new System.Windows.Forms.Padding(8, 0, 0, 0);
            // Encabezado: no cambia de color al seleccionarlo
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(245)))), ((int)(((byte)(241)))));
            // Encabezado: la letra tampoco cambia al seleccionarlo
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(65)))), ((int)(((byte)(81)))));
            // Encabezado: el texto no pasa a otra línea
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            // Aplica el estilo a los encabezados
            this.dgvSugerencias.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            // Alto de los encabezados: 40
            this.dgvSugerencias.ColumnHeadersHeight = 40;
            // El alto de los encabezados no se puede cambiar con el mouse
            this.dgvSugerencias.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            // Agrega las cuatro columnas a la tabla, en este orden
            this.dgvSugerencias.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colFecha,
            this.colAsunto,
            this.colEstado,
            this.colRespuesta});
            // Celdas: texto a la izquierda y arriba (las filas pueden tener varias líneas)
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            // Celdas: fondo blanco
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            // Celdas: letra Segoe UI de 9.75 puntos
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Celdas: letra casi negra
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(41)))), ((int)(((byte)(51)))));
            // Celdas: espacio alrededor del texto (8 a los lados y 8 arriba y abajo)
            dataGridViewCellStyle3.Padding = new System.Windows.Forms.Padding(8);
            // Fila seleccionada: verde muy claro
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(248)))), ((int)(((byte)(235)))));
            // Fila seleccionada: la letra sigue casi negra
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(41)))), ((int)(((byte)(51)))));
            // Celdas: el texto largo pasa a la siguiente línea
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            // Aplica el estilo a todas las celdas
            this.dgvSugerencias.DefaultCellStyle = dataGridViewCellStyle3;
            // Ocupa todo el espacio debajo del título
            this.dgvSugerencias.Dock = System.Windows.Forms.DockStyle.Fill;
            // Usa los colores de encabezado que pusimos, no los del tema de Windows
            this.dgvSugerencias.EnableHeadersVisualStyles = false;
            // Color gris claro de las líneas entre filas
            this.dgvSugerencias.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(231)))), ((int)(((byte)(235)))));
            // Posición: debajo del título
            this.dgvSugerencias.Location = new System.Drawing.Point(24, 52);
            // Solo se puede seleccionar una fila a la vez
            this.dgvSugerencias.MultiSelect = false;
            // Nombre del control
            this.dgvSugerencias.Name = "dgvSugerencias";
            // Solo lectura: no se puede escribir en las celdas
            this.dgvSugerencias.ReadOnly = true;
            // Oculta la columna gris de la izquierda (la de los triangulitos)
            this.dgvSugerencias.RowHeadersVisible = false;
            // Al hacer clic se selecciona la fila completa
            this.dgvSugerencias.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            // Tamaño (lo calcula el Dock)
            this.dgvSugerencias.Size = new System.Drawing.Size(932, 132);
            // Orden de tabulación
            this.dgvSugerencias.TabIndex = 1;
            //
            // colFecha
            // Columna "Fecha": día en que se envió la sugerencia.
            //
            // Parte del ancho que le toca (comparada con las otras columnas)
            this.colFecha.FillWeight = 14F;
            // Texto del encabezado
            this.colFecha.HeaderText = "Fecha";
            // Nombre de la columna
            this.colFecha.Name = "colFecha";
            // Solo lectura
            this.colFecha.ReadOnly = true;
            // No se ordena al hacer clic en el encabezado (la lista ya viene ordenada)
            this.colFecha.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            //
            // colAsunto
            // Columna "Asunto". Al pasar el mouse por encima se ve el mensaje completo.
            //
            // Parte del ancho que le toca
            this.colAsunto.FillWeight = 28F;
            // Texto del encabezado
            this.colAsunto.HeaderText = "Asunto";
            // Nombre de la columna
            this.colAsunto.Name = "colAsunto";
            // Solo lectura
            this.colAsunto.ReadOnly = true;
            // No se ordena al hacer clic en el encabezado
            this.colAsunto.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            //
            // colEstado
            // Columna "Estado": Pendiente (amarillo) o Atendida (verde). Los colores los pone UcBuzonSugerencias.cs.
            //
            // Estado: letra Segoe UI Semibold
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Aplica el estilo a la columna
            this.colEstado.DefaultCellStyle = dataGridViewCellStyle2;
            // Parte del ancho que le toca
            this.colEstado.FillWeight = 14F;
            // Texto del encabezado
            this.colEstado.HeaderText = "Estado";
            // Nombre de la columna
            this.colEstado.Name = "colEstado";
            // Solo lectura
            this.colEstado.ReadOnly = true;
            // No se ordena al hacer clic en el encabezado
            this.colEstado.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            //
            // colRespuesta
            // Columna "Respuesta del comedor": lo que contestó el encargado (o "Todavía no hay respuesta").
            //
            // Parte del ancho que le toca (es la más ancha)
            this.colRespuesta.FillWeight = 44F;
            // Texto del encabezado
            this.colRespuesta.HeaderText = "Respuesta del comedor";
            // Nombre de la columna
            this.colRespuesta.Name = "colRespuesta";
            // Solo lectura
            this.colRespuesta.ReadOnly = true;
            // No se ordena al hacer clic en el encabezado
            this.colRespuesta.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            //
            // lblMisSugerencias
            // Título "Mis sugerencias" arriba de la tabla.
            //
            // Pegada arriba de la tarjeta
            this.lblMisSugerencias.Dock = System.Windows.Forms.DockStyle.Top;
            // Letra Segoe UI de 12 puntos en negrita
            this.lblMisSugerencias.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Color casi negro
            this.lblMisSugerencias.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(41)))), ((int)(((byte)(51)))));
            // Posición: dentro del margen de la tarjeta
            this.lblMisSugerencias.Location = new System.Drawing.Point(24, 16);
            // Nombre del control
            this.lblMisSugerencias.Name = "lblMisSugerencias";
            // Tamaño: todo el ancho y 36 de alto
            this.lblMisSugerencias.Size = new System.Drawing.Size(932, 36);
            // Orden de tabulación
            this.lblMisSugerencias.TabIndex = 0;
            // Texto que se muestra
            this.lblMisSugerencias.Text = "Mis sugerencias";
            //
            // errorProvider
            // Muestra un ícono rojo junto al campo con error; al pasar el mouse por el ícono se lee el mensaje.
            //
            // El ícono no parpadea
            this.errorProvider.BlinkStyle = System.Windows.Forms.ErrorBlinkStyle.NeverBlink;
            // Trabaja sobre los controles de esta sección
            this.errorProvider.ContainerControl = this;
            //
            // UcBuzonSugerencias
            // La sección completa: fondo gris muy claro, igual al área de contenido del panel.
            //
            // Tamaño de letra con el que se diseñó (sirve para escalar si cambia la fuente o el DPI)
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            // Escala los controles según la fuente
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            // Muestra barras de desplazamiento si la ventana queda más pequeña que el contenido
            this.AutoScroll = true;
            // Tamaño mínimo del contenido: por debajo de esto aparecen las barras de desplazamiento
            this.AutoScrollMinSize = new System.Drawing.Size(680, 560);
            // Fondo gris muy claro
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(245)))), ((int)(((byte)(241)))));
            // Agrega la tabla principal (se agrega primero para que el Dock Fill se acomode al final)
            this.Controls.Add(this.tlpBuzon);
            // Agrega la descripción
            this.Controls.Add(this.lblDescripcion);
            // Agrega el título (el último agregado queda más arriba con Dock Top)
            this.Controls.Add(this.lblTitulo);
            // Fuente de toda la sección: Segoe UI de 9.75 puntos
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Nombre de la sección
            this.Name = "UcBuzonSugerencias";
            // Tamaño en [Diseño] (en el panel se estira con Dock Fill)
            this.Size = new System.Drawing.Size(980, 600);
            // Conecta el evento Load con UcBuzonSugerencias_Load (llena la tabla de sugerencias)
            this.Load += new System.EventHandler(this.UcBuzonSugerencias_Load);
            // Reanuda el acomodo de la tabla principal
            this.tlpBuzon.ResumeLayout(false);
            // Reanuda el acomodo de la tarjeta del formulario
            this.pnlFormulario.ResumeLayout(false);
            // Acomoda ya los controles del formulario (las etiquetas con AutoSize)
            this.pnlFormulario.PerformLayout();
            // Reanuda el acomodo de la tarjeta "Mis sugerencias"
            this.pnlMisSugerencias.ResumeLayout(false);
            // Termina la configuración de la tabla de sugerencias
            ((System.ComponentModel.ISupportInitialize)(this.dgvSugerencias)).EndInit();
            // Termina la configuración del ErrorProvider
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).EndInit();
            // Reanuda el acomodo de la sección
            this.ResumeLayout(false);

        }

        // Fin de la región del diseñador
        #endregion

        // Título grande de la sección
        private System.Windows.Forms.Label lblTitulo;
        // Descripción de la sección
        private System.Windows.Forms.Label lblDescripcion;
        // Tabla que acomoda las dos tarjetas
        private System.Windows.Forms.TableLayoutPanel tlpBuzon;
        // Tarjeta del formulario
        private System.Windows.Forms.Panel pnlFormulario;
        // Botón "Enviar sugerencia"
        private System.Windows.Forms.Button btnEnviar;
        // Contador de caracteres del mensaje
        private System.Windows.Forms.Label lblContador;
        // Caja del mensaje
        private System.Windows.Forms.TextBox txtMensaje;
        // Etiqueta "Mensaje"
        private System.Windows.Forms.Label lblMensaje;
        // Caja del asunto
        private System.Windows.Forms.TextBox txtAsunto;
        // Etiqueta "Asunto"
        private System.Windows.Forms.Label lblAsunto;
        // Tarjeta "Mis sugerencias"
        private System.Windows.Forms.Panel pnlMisSugerencias;
        // Tabla de sugerencias
        private System.Windows.Forms.DataGridView dgvSugerencias;
        // Columna "Fecha"
        private System.Windows.Forms.DataGridViewTextBoxColumn colFecha;
        // Columna "Asunto"
        private System.Windows.Forms.DataGridViewTextBoxColumn colAsunto;
        // Columna "Estado"
        private System.Windows.Forms.DataGridViewTextBoxColumn colEstado;
        // Columna "Respuesta del comedor"
        private System.Windows.Forms.DataGridViewTextBoxColumn colRespuesta;
        // Título "Mis sugerencias"
        private System.Windows.Forms.Label lblMisSugerencias;
        // Marca los errores junto a cada campo
        private System.Windows.Forms.ErrorProvider errorProvider;
    }
}
