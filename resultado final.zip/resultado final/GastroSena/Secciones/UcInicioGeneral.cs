﻿// Archivo: Secciones/UcInicioGeneral.cs
// Sección "Inicio" de los perfiles Instructor, Encargado e Invitado (el aprendiz usa UcInicio).
// Es lo primero que se ve en el panel después de iniciar sesión.
// Muestra "Bienvenido, <nombre>" y el perfil del usuario. Los controles están en UcInicioGeneral.Designer.cs.

// Trae los controles de Windows Forms (UserControl)
using System.Windows.Forms;
// Trae la clase Usuario
using GastroSena.Modelos;

// Espacio de nombres de las secciones (carpeta Secciones)
namespace GastroSena.Secciones
{
    /// <summary>
    /// Sección de bienvenida de los perfiles que todavía no están terminados (Instructor, Encargado e Invitado).
    /// FrmPanel la crea al abrir y cada vez que se presiona "Inicio",
    /// y luego llama a MostrarBienvenida para escribir el nombre y el perfil.
    /// </summary>
    public partial class UcInicioGeneral : UserControl
    {
        /// <summary>
        /// Constructor: se ejecuta cuando el panel crea la sección (new UcInicioGeneral()).
        /// Llama a InitializeComponent para crear las etiquetas y la tarjeta del diseñador.
        /// </summary>
        public UcInicioGeneral()
        {
            // Crea los controles de la sección tal como se dibujaron en [Diseño]
            InitializeComponent();
        }

        /// <summary>
        /// Escribe en la sección el nombre y el perfil del usuario que inició sesión.
        /// </summary>
        /// <param name="usuario">El usuario que entró al sistema.</param>
        public void MostrarBienvenida(Usuario usuario)
        {
            // Escribe el saludo con el nombre completo (+ une textos)
            lblBienvenida.Text = "Bienvenido, " + usuario.NombreCompleto;
            // Escribe el perfil (por ejemplo "Perfil: Encargado")
            lblPerfil.Text = "Perfil: " + usuario.Rol;
        }
    }
}
