﻿// Archivo: Secciones/UcCarteraDeudas.cs
// Sección "Cartera de Deudas" (UserControl). La ve el encargado.
// Por ahora solo muestra su título grande y el texto "En construcción"; los controles están en UcCarteraDeudas.Designer.cs.

// Trae los controles de Windows Forms (UserControl)
using System.Windows.Forms;

// Espacio de nombres de las secciones (carpeta Secciones)
namespace GastroSena.Secciones
{
    /// <summary>
    /// Sección "Cartera de Deudas". FrmPanel la crea y la muestra en el área de contenido
    /// cuando se presiona el botón "Cartera de Deudas" del menú lateral (btnCarteraDeudas).
    /// </summary>
    public partial class UcCarteraDeudas : UserControl
    {
        /// <summary>
        /// Constructor: se ejecuta cuando el panel crea la sección (new UcCarteraDeudas()).
        /// Llama a InitializeComponent para crear el título, la descripción y la tarjeta "En construcción".
        /// </summary>
        public UcCarteraDeudas()
        {
            // Crea los controles de la sección tal como se dibujaron en [Diseño]
            InitializeComponent();
        }
    }
}
