﻿// Visual Studio regenera este archivo cuando se edita en [Diseño], y los comentarios de adentro se pueden borrar.
// Archivo: Secciones/UcInicio.Designer.cs
// Parte "de diseño" de la sección Inicio del aprendiz: aquí se crean la bienvenida, la fecha,
// la tarjeta "Menú del día" (foto, nombre, descripción, precio, cupos y botón "Reservar almuerzo"),
// las tres tarjetas pequeñas del resumen del mes y el recuadro con el horario del comedor.
// Para cambiar cómo se ve, abre UcInicio.cs en la vista [Diseño].

// Espacio de nombres de las secciones (carpeta Secciones)
namespace GastroSena.Secciones
{
    /// <summary>
    /// Segunda parte (partial) de la clase UcInicio: contiene el código que escribe el diseñador.
    /// La otra parte, con la lógica, está en UcInicio.cs.
    /// </summary>
    partial class UcInicio
    {
        /// <summary>
        /// Variable del diseñador necesaria: guarda los componentes que hay que liberar al cerrar.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpia los recursos que se estén usando. Se ejecuta cuando la sección se cambia por otra.
        /// </summary>
        /// <param name="disposing">true si se deben liberar los recursos administrados; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            // Si se están liberando recursos y hay componentes guardados...
            if (disposing && (components != null))
            {
                // ...los libera
                components.Dispose();
            }
            // Llama al Dispose de la clase base (UserControl) para que termine de limpiar
            base.Dispose(disposing);
        }

        // Región con el código que escribe el Diseñador de componentes
        #region Código generado por el Diseñador de componentes

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// Crea los controles de la sección, les pone sus propiedades, los agrega y conecta sus eventos.
        /// </summary>
        private void InitializeComponent()
        {
            // Crea la etiqueta grande de bienvenida
            this.lblBienvenida = new System.Windows.Forms.Label();
            // Crea la etiqueta con la fecha de hoy
            this.lblFecha = new System.Windows.Forms.Label();
            // Crea la tabla que acomoda las tarjetas una debajo de la otra
            this.tlpInicio = new System.Windows.Forms.TableLayoutPanel();
            // Crea la tarjeta blanca del menú del día
            this.pnlTarjetaMenu = new System.Windows.Forms.Panel();
            // Crea el panel de los datos del menú (a la derecha de la foto)
            this.pnlDetalleMenu = new System.Windows.Forms.Panel();
            // Crea la etiqueta del aviso que va debajo del botón
            this.lblAvisoReserva = new System.Windows.Forms.Label();
            // Crea el panel que contiene el botón Reservar almuerzo
            this.pnlAccion = new System.Windows.Forms.Panel();
            // Crea el botón "Reservar almuerzo"
            this.btnReservar = new System.Windows.Forms.Button();
            // Crea el panel del precio y los cupos
            this.pnlPrecio = new System.Windows.Forms.Panel();
            // Crea la etiqueta de los cupos disponibles
            this.lblCupos = new System.Windows.Forms.Label();
            // Crea la etiqueta del precio
            this.lblPrecio = new System.Windows.Forms.Label();
            // Crea la etiqueta de la descripción del menú
            this.lblMenuDescripcion = new System.Windows.Forms.Label();
            // Crea la etiqueta del nombre del menú
            this.lblMenuNombre = new System.Windows.Forms.Label();
            // Crea la etiqueta pequeña "Menú del día"
            this.lblMenuEtiqueta = new System.Windows.Forms.Label();
            // Crea la foto del menú
            this.picMenu = new System.Windows.Forms.PictureBox();
            // Crea la tabla de las tres tarjetas pequeñas del resumen
            this.tlpResumen = new System.Windows.Forms.TableLayoutPanel();
            // Crea la tarjeta "Almuerzos este mes"
            this.pnlAlmuerzosMes = new System.Windows.Forms.Panel();
            // Crea la etiqueta con el número de almuerzos del mes
            this.lblAlmuerzosMes = new System.Windows.Forms.Label();
            // Crea la etiqueta del título "Almuerzos este mes"
            this.lblAlmuerzosMesTitulo = new System.Windows.Forms.Label();
            // Crea la tarjeta "Gasto del mes"
            this.pnlGastoMes = new System.Windows.Forms.Panel();
            // Crea la etiqueta con el gasto del mes
            this.lblGastoMes = new System.Windows.Forms.Label();
            // Crea la etiqueta del título "Gasto del mes"
            this.lblGastoMesTitulo = new System.Windows.Forms.Label();
            // Crea la tarjeta "Pendiente por pagar"
            this.pnlPendiente = new System.Windows.Forms.Panel();
            // Crea la etiqueta con el valor pendiente por pagar
            this.lblPendiente = new System.Windows.Forms.Label();
            // Crea la etiqueta del título "Pendiente por pagar"
            this.lblPendienteTitulo = new System.Windows.Forms.Label();
            // Crea el recuadro azul claro del horario
            this.pnlHorario = new System.Windows.Forms.Panel();
            // Crea la etiqueta con el detalle del horario
            this.lblHorarioDetalle = new System.Windows.Forms.Label();
            // Crea la etiqueta del título "Horario del comedor"
            this.lblHorarioTitulo = new System.Windows.Forms.Label();
            // Pausa el acomodo de la tabla principal mientras se configura
            this.tlpInicio.SuspendLayout();
            // Pausa el acomodo de la tarjeta del menú
            this.pnlTarjetaMenu.SuspendLayout();
            // Pausa el acomodo del panel de datos del menú
            this.pnlDetalleMenu.SuspendLayout();
            // Pausa el acomodo del panel del botón
            this.pnlAccion.SuspendLayout();
            // Pausa el acomodo del panel del precio
            this.pnlPrecio.SuspendLayout();
            // Avisa a la foto que empieza su configuración
            ((System.ComponentModel.ISupportInitialize)(this.picMenu)).BeginInit();
            // Pausa el acomodo de la tabla del resumen
            this.tlpResumen.SuspendLayout();
            // Pausa el acomodo de la tarjeta "Almuerzos este mes"
            this.pnlAlmuerzosMes.SuspendLayout();
            // Pausa el acomodo de la tarjeta "Gasto del mes"
            this.pnlGastoMes.SuspendLayout();
            // Pausa el acomodo de la tarjeta "Pendiente por pagar"
            this.pnlPendiente.SuspendLayout();
            // Pausa el acomodo del recuadro del horario
            this.pnlHorario.SuspendLayout();
            // Pausa el acomodo de la sección mientras se configura
            this.SuspendLayout();
            //
            // lblBienvenida
            // Título grande "Bienvenido, <nombre>": arriba de todo. El nombre lo escribe CargarDatos.
            //
            // Pegada arriba, ocupando todo el ancho
            this.lblBienvenida.Dock = System.Windows.Forms.DockStyle.Top;
            // Letra Segoe UI de 20 puntos en negrita
            this.lblBienvenida.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Color casi negro
            this.lblBienvenida.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(41)))), ((int)(((byte)(51)))));
            // Posición: arriba a la izquierda
            this.lblBienvenida.Location = new System.Drawing.Point(0, 0);
            // Nombre del control
            this.lblBienvenida.Name = "lblBienvenida";
            // Tamaño: todo el ancho y 48 de alto
            this.lblBienvenida.Size = new System.Drawing.Size(980, 48);
            // Orden de tabulación
            this.lblBienvenida.TabIndex = 0;
            // Texto de ejemplo (se reemplaza con el nombre real al abrir la sección)
            this.lblBienvenida.Text = "Bienvenido, Carlos Ruiz";
            // Texto alineado a la izquierda y centrado de arriba a abajo
            this.lblBienvenida.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            //
            // lblFecha
            // Fecha de hoy en español, debajo de la bienvenida. La escribe CargarDatos.
            //
            // Pegada arriba, debajo de la bienvenida
            this.lblFecha.Dock = System.Windows.Forms.DockStyle.Top;
            // Letra Segoe UI de 11 puntos
            this.lblFecha.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Color gris
            this.lblFecha.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(114)))), ((int)(((byte)(128)))));
            // Posición: debajo de la bienvenida
            this.lblFecha.Location = new System.Drawing.Point(0, 48);
            // Nombre del control
            this.lblFecha.Name = "lblFecha";
            // Tamaño: todo el ancho; el alto deja un espacio antes de las tarjetas
            this.lblFecha.Size = new System.Drawing.Size(980, 44);
            // Orden de tabulación
            this.lblFecha.TabIndex = 1;
            // Texto de ejemplo (se reemplaza con la fecha real)
            this.lblFecha.Text = "Viernes, 13 de noviembre de 2026";
            //
            // tlpInicio
            // Tabla de una columna: fila 0 = menú del día, fila 1 = resumen, fila 2 = horario, fila 3 = espacio libre.
            //
            // Una sola columna
            this.tlpInicio.ColumnCount = 1;
            // La columna ocupa el 100% del ancho
            this.tlpInicio.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            // Pone la tarjeta del menú en la columna 0, fila 0
            this.tlpInicio.Controls.Add(this.pnlTarjetaMenu, 0, 0);
            // Pone el resumen en la columna 0, fila 1
            this.tlpInicio.Controls.Add(this.tlpResumen, 0, 1);
            // Pone el horario en la columna 0, fila 2
            this.tlpInicio.Controls.Add(this.pnlHorario, 0, 2);
            // Ocupa todo el espacio que sobra debajo de la fecha
            this.tlpInicio.Dock = System.Windows.Forms.DockStyle.Fill;
            // Posición: debajo de la fecha
            this.tlpInicio.Location = new System.Drawing.Point(0, 92);
            // Nombre del control
            this.tlpInicio.Name = "tlpInicio";
            // Cuatro filas
            this.tlpInicio.RowCount = 4;
            // Fila 0 (menú del día): 256 de alto
            this.tlpInicio.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 256F));
            // Fila 1 (resumen): 104 de alto
            this.tlpInicio.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 104F));
            // Fila 2 (horario): 88 de alto
            this.tlpInicio.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 88F));
            // Fila 3: el espacio que sobre (queda vacía)
            this.tlpInicio.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            // Tamaño (lo calcula el Dock)
            this.tlpInicio.Size = new System.Drawing.Size(980, 508);
            // Orden de tabulación
            this.tlpInicio.TabIndex = 2;
            //
            // pnlTarjetaMenu
            // Tarjeta blanca "Menú del día": la foto a la izquierda y los datos a la derecha.
            //
            // Fondo blanco
            this.pnlTarjetaMenu.BackColor = System.Drawing.Color.White;
            // Agrega los datos del menú (primero, para que su Dock Fill se acomode al final)
            this.pnlTarjetaMenu.Controls.Add(this.pnlDetalleMenu);
            // Agrega la foto (queda a la izquierda con Dock Left)
            this.pnlTarjetaMenu.Controls.Add(this.picMenu);
            // Ocupa toda su celda de la tabla
            this.pnlTarjetaMenu.Dock = System.Windows.Forms.DockStyle.Fill;
            // Posición: arriba de la tabla
            this.pnlTarjetaMenu.Location = new System.Drawing.Point(0, 0);
            // Margen: 16 abajo para separarla del resumen
            this.pnlTarjetaMenu.Margin = new System.Windows.Forms.Padding(0, 0, 0, 16);
            // Nombre del control
            this.pnlTarjetaMenu.Name = "pnlTarjetaMenu";
            // Margen interior de 16 píxeles
            this.pnlTarjetaMenu.Padding = new System.Windows.Forms.Padding(16);
            // Tamaño (lo calcula el Dock)
            this.pnlTarjetaMenu.Size = new System.Drawing.Size(980, 240);
            // Orden de tabulación
            this.pnlTarjetaMenu.TabIndex = 0;
            //
            // pnlDetalleMenu
            // Datos del menú, uno debajo del otro: etiqueta, nombre, descripción, precio, botón y aviso.
            //
            // Agrega el aviso (el primero agregado queda más abajo con Dock Top)
            this.pnlDetalleMenu.Controls.Add(this.lblAvisoReserva);
            // Agrega el panel del botón
            this.pnlDetalleMenu.Controls.Add(this.pnlAccion);
            // Agrega el panel del precio
            this.pnlDetalleMenu.Controls.Add(this.pnlPrecio);
            // Agrega la descripción
            this.pnlDetalleMenu.Controls.Add(this.lblMenuDescripcion);
            // Agrega el nombre del menú
            this.pnlDetalleMenu.Controls.Add(this.lblMenuNombre);
            // Agrega la etiqueta "Menú del día" (la última agregada queda más arriba)
            this.pnlDetalleMenu.Controls.Add(this.lblMenuEtiqueta);
            // Ocupa todo el espacio a la derecha de la foto
            this.pnlDetalleMenu.Dock = System.Windows.Forms.DockStyle.Fill;
            // Posición: a la derecha de la foto
            this.pnlDetalleMenu.Location = new System.Drawing.Point(293, 16);
            // Nombre del control
            this.pnlDetalleMenu.Name = "pnlDetalleMenu";
            // Margen interior: 24 a la izquierda para separar el texto de la foto
            this.pnlDetalleMenu.Padding = new System.Windows.Forms.Padding(24, 0, 0, 0);
            // Tamaño (lo calcula el Dock)
            this.pnlDetalleMenu.Size = new System.Drawing.Size(671, 208);
            // Orden de tabulación
            this.pnlDetalleMenu.TabIndex = 1;
            //
            // lblAvisoReserva
            // Aviso gris debajo del botón: cómo se paga, o por qué no se puede reservar. Lo escribe UcInicio.cs.
            //
            // Pegada arriba, debajo del botón
            this.lblAvisoReserva.Dock = System.Windows.Forms.DockStyle.Top;
            // Letra Segoe UI de 9 puntos
            this.lblAvisoReserva.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Color gris
            this.lblAvisoReserva.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(114)))), ((int)(((byte)(128)))));
            // Posición: debajo del botón
            this.lblAvisoReserva.Location = new System.Drawing.Point(24, 178);
            // Nombre del control
            this.lblAvisoReserva.Name = "lblAvisoReserva";
            // Tamaño: todo el ancho y 26 de alto
            this.lblAvisoReserva.Size = new System.Drawing.Size(647, 26);
            // Orden de tabulación
            this.lblAvisoReserva.TabIndex = 5;
            // Texto de ejemplo (se reemplaza al abrir la sección)
            this.lblAvisoReserva.Text = "Lo pagas en la ventanilla del comedor.";
            // Texto alineado a la izquierda y centrado de arriba a abajo
            this.lblAvisoReserva.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            //
            // pnlAccion
            // Franja que contiene el botón "Reservar almuerzo" (así el botón no se estira a lo ancho).
            //
            // Agrega el botón dentro de la franja
            this.pnlAccion.Controls.Add(this.btnReservar);
            // Pegada arriba, debajo del precio
            this.pnlAccion.Dock = System.Windows.Forms.DockStyle.Top;
            // Posición: debajo del precio
            this.pnlAccion.Location = new System.Drawing.Point(24, 132);
            // Nombre del control
            this.pnlAccion.Name = "pnlAccion";
            // Tamaño: todo el ancho y 46 de alto
            this.pnlAccion.Size = new System.Drawing.Size(647, 46);
            // Orden de tabulación
            this.pnlAccion.TabIndex = 4;
            //
            // btnReservar
            // Botón verde "Reservar almuerzo". Al hacer clic se ejecuta btnReservar_Click (en UcInicio.cs).
            //
            // Fondo verde SENA
            this.btnReservar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(169)))), ((int)(((byte)(0)))));
            // Puntero de mano
            this.btnReservar.Cursor = System.Windows.Forms.Cursors.Hand;
            // Sin borde
            this.btnReservar.FlatAppearance.BorderSize = 0;
            // Verde más oscuro mientras se mantiene presionado
            this.btnReservar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(115)))), ((int)(((byte)(0)))));
            // Verde oscuro al pasar el mouse
            this.btnReservar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(0)))));
            // Estilo plano (Flat)
            this.btnReservar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            // Letra Segoe UI Semibold de 11 puntos
            this.btnReservar.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Letra blanca
            this.btnReservar.ForeColor = System.Drawing.Color.White;
            // Posición: a la izquierda de la franja, con 3 píxeles arriba
            this.btnReservar.Location = new System.Drawing.Point(0, 3);
            // Nombre del control
            this.btnReservar.Name = "btnReservar";
            // Tamaño: 300 de ancho (para que quepa "Ya reservaste tu almuerzo de hoy") y 40 de alto
            this.btnReservar.Size = new System.Drawing.Size(300, 40);
            // Orden de tabulación
            this.btnReservar.TabIndex = 0;
            // Texto del botón
            this.btnReservar.Text = "Reservar almuerzo";
            // Usa el BackColor que pusimos, no el color del tema de Windows
            this.btnReservar.UseVisualStyleBackColor = false;
            // Conecta el clic con el método btnReservar_Click (en UcInicio.cs)
            this.btnReservar.Click += new System.EventHandler(this.btnReservar_Click);
            //
            // pnlPrecio
            // Franja con el precio (izquierda) y los cupos disponibles (derecha).
            //
            // Agrega los cupos (primero, para que su Dock Fill se acomode al final)
            this.pnlPrecio.Controls.Add(this.lblCupos);
            // Agrega el precio (queda a la izquierda con Dock Left)
            this.pnlPrecio.Controls.Add(this.lblPrecio);
            // Pegada arriba, debajo de la descripción
            this.pnlPrecio.Dock = System.Windows.Forms.DockStyle.Top;
            // Posición: debajo de la descripción
            this.pnlPrecio.Location = new System.Drawing.Point(24, 92);
            // Nombre del control
            this.pnlPrecio.Name = "pnlPrecio";
            // Tamaño: todo el ancho y 40 de alto
            this.pnlPrecio.Size = new System.Drawing.Size(647, 40);
            // Orden de tabulación
            this.pnlPrecio.TabIndex = 3;
            //
            // lblCupos
            // Cupos que quedan hoy, a la derecha del precio. Lo escribe UcInicio.cs.
            //
            // Ocupa el espacio a la derecha del precio
            this.lblCupos.Dock = System.Windows.Forms.DockStyle.Fill;
            // Color gris
            this.lblCupos.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(114)))), ((int)(((byte)(128)))));
            // Posición: a la derecha del precio
            this.lblCupos.Location = new System.Drawing.Point(100, 0);
            // Nombre del control
            this.lblCupos.Name = "lblCupos";
            // Tamaño (lo calcula el Dock)
            this.lblCupos.Size = new System.Drawing.Size(547, 40);
            // Orden de tabulación
            this.lblCupos.TabIndex = 1;
            // Texto de ejemplo (se reemplaza con los cupos reales)
            this.lblCupos.Text = "150 cupos disponibles";
            // Texto alineado a la izquierda y centrado de arriba a abajo
            this.lblCupos.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            //
            // lblPrecio
            // Precio del almuerzo en verde y grande. Lo escribe UcInicio.cs.
            //
            // Pegada a la izquierda de la franja
            this.lblPrecio.Dock = System.Windows.Forms.DockStyle.Left;
            // Letra Segoe UI de 18 puntos en negrita
            this.lblPrecio.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Color verde SENA
            this.lblPrecio.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(169)))), ((int)(((byte)(0)))));
            // Posición: a la izquierda de la franja
            this.lblPrecio.Location = new System.Drawing.Point(0, 0);
            // Nombre del control
            this.lblPrecio.Name = "lblPrecio";
            // Tamaño: 100 de ancho y todo el alto de la franja
            this.lblPrecio.Size = new System.Drawing.Size(100, 40);
            // Orden de tabulación
            this.lblPrecio.TabIndex = 0;
            // Texto de ejemplo (se reemplaza con el precio real)
            this.lblPrecio.Text = "$5.000";
            // Texto alineado a la izquierda y centrado de arriba a abajo
            this.lblPrecio.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            //
            // lblMenuDescripcion
            // Qué trae el almuerzo. Si el texto es largo, pasa a la siguiente línea. Lo escribe UcInicio.cs.
            //
            // Pegada arriba, debajo del nombre
            this.lblMenuDescripcion.Dock = System.Windows.Forms.DockStyle.Top;
            // Color gris oscuro
            this.lblMenuDescripcion.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(85)))), ((int)(((byte)(99)))));
            // Posición: debajo del nombre
            this.lblMenuDescripcion.Location = new System.Drawing.Point(24, 52);
            // Nombre del control
            this.lblMenuDescripcion.Name = "lblMenuDescripcion";
            // Tamaño: todo el ancho y 40 de alto (caben dos líneas)
            this.lblMenuDescripcion.Size = new System.Drawing.Size(647, 40);
            // Orden de tabulación
            this.lblMenuDescripcion.TabIndex = 2;
            // Texto de ejemplo (se reemplaza con la descripción real)
            this.lblMenuDescripcion.Text = "Almuerzo completo: sopa, bandeja con proteína, arroz, ensalada, jugo natural y postre.";
            //
            // lblMenuNombre
            // Nombre del menú en negrita. Lo escribe UcInicio.cs.
            //
            // Pegada arriba, debajo de la etiqueta "Menú del día"
            this.lblMenuNombre.Dock = System.Windows.Forms.DockStyle.Top;
            // Letra Segoe UI de 15.75 puntos en negrita
            this.lblMenuNombre.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Color casi negro
            this.lblMenuNombre.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(41)))), ((int)(((byte)(51)))));
            // Posición: debajo de la etiqueta
            this.lblMenuNombre.Location = new System.Drawing.Point(24, 20);
            // Nombre del control
            this.lblMenuNombre.Name = "lblMenuNombre";
            // Tamaño: todo el ancho y 32 de alto
            this.lblMenuNombre.Size = new System.Drawing.Size(647, 32);
            // Orden de tabulación
            this.lblMenuNombre.TabIndex = 1;
            // Texto de ejemplo (se reemplaza con el nombre real)
            this.lblMenuNombre.Text = "Menú Ejecutivo SENA";
            // Texto alineado a la izquierda y centrado de arriba a abajo
            this.lblMenuNombre.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            //
            // lblMenuEtiqueta
            // Etiqueta pequeña y verde "Menú del día", arriba de los datos.
            //
            // Pegada arriba de todo
            this.lblMenuEtiqueta.Dock = System.Windows.Forms.DockStyle.Top;
            // Letra Segoe UI Semibold de 9 puntos
            this.lblMenuEtiqueta.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Color verde SENA
            this.lblMenuEtiqueta.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(169)))), ((int)(((byte)(0)))));
            // Posición: arriba del panel
            this.lblMenuEtiqueta.Location = new System.Drawing.Point(24, 0);
            // Nombre del control
            this.lblMenuEtiqueta.Name = "lblMenuEtiqueta";
            // Tamaño: todo el ancho y 20 de alto
            this.lblMenuEtiqueta.Size = new System.Drawing.Size(647, 20);
            // Orden de tabulación
            this.lblMenuEtiqueta.TabIndex = 0;
            // Texto que se muestra
            this.lblMenuEtiqueta.Text = "Menú del día";
            //
            // picMenu
            // Foto del menú (la imagen cafeteria-bg.jpg de Properties > Resources), a la izquierda de la tarjeta.
            //
            // Fondo blanco (se ve si la foto no llena todo el cuadro)
            this.picMenu.BackColor = System.Drawing.Color.White;
            // Pegada a la izquierda de la tarjeta, de arriba a abajo
            this.picMenu.Dock = System.Windows.Forms.DockStyle.Left;
            // Imagen tomada de los recursos del proyecto
            this.picMenu.Image = global::GastroSena.Properties.Resources.cafeteria_bg;
            // Posición: dentro del margen de la tarjeta
            this.picMenu.Location = new System.Drawing.Point(16, 16);
            // Nombre del control
            this.picMenu.Name = "picMenu";
            // Tamaño: 277 x 208 (la misma proporción 4:3 de la foto)
            this.picMenu.Size = new System.Drawing.Size(277, 208);
            // Zoom = agranda o achica la foto sin deformarla
            this.picMenu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            // Orden de tabulación
            this.picMenu.TabIndex = 0;
            // La tecla Tab no se detiene en la foto
            this.picMenu.TabStop = false;
            //
            // tlpResumen
            // Tabla de tres columnas iguales con las tarjetas pequeñas del resumen del mes.
            //
            // Tres columnas
            this.tlpResumen.ColumnCount = 3;
            // Columna 0: un tercio del ancho
            this.tlpResumen.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            // Columna 1: un tercio del ancho
            this.tlpResumen.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            // Columna 2: un tercio del ancho
            this.tlpResumen.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            // Pone "Almuerzos este mes" en la columna 0
            this.tlpResumen.Controls.Add(this.pnlAlmuerzosMes, 0, 0);
            // Pone "Gasto del mes" en la columna 1
            this.tlpResumen.Controls.Add(this.pnlGastoMes, 1, 0);
            // Pone "Pendiente por pagar" en la columna 2
            this.tlpResumen.Controls.Add(this.pnlPendiente, 2, 0);
            // Ocupa toda su celda de la tabla principal
            this.tlpResumen.Dock = System.Windows.Forms.DockStyle.Fill;
            // Posición: debajo de la tarjeta del menú
            this.tlpResumen.Location = new System.Drawing.Point(0, 256);
            // Margen: 16 abajo para separarla del horario
            this.tlpResumen.Margin = new System.Windows.Forms.Padding(0, 0, 0, 16);
            // Nombre del control
            this.tlpResumen.Name = "tlpResumen";
            // Una sola fila
            this.tlpResumen.RowCount = 1;
            // La fila ocupa todo el alto
            this.tlpResumen.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            // Tamaño (lo calcula el Dock)
            this.tlpResumen.Size = new System.Drawing.Size(980, 88);
            // Orden de tabulación
            this.tlpResumen.TabIndex = 1;
            //
            // pnlAlmuerzosMes
            // Tarjeta blanca pequeña "Almuerzos este mes".
            //
            // Fondo blanco
            this.pnlAlmuerzosMes.BackColor = System.Drawing.Color.White;
            // Agrega el número (primero, para que su Dock Fill se acomode al final)
            this.pnlAlmuerzosMes.Controls.Add(this.lblAlmuerzosMes);
            // Agrega el título (queda arriba con Dock Top)
            this.pnlAlmuerzosMes.Controls.Add(this.lblAlmuerzosMesTitulo);
            // Ocupa toda su celda
            this.pnlAlmuerzosMes.Dock = System.Windows.Forms.DockStyle.Fill;
            // Posición: columna 0
            this.pnlAlmuerzosMes.Location = new System.Drawing.Point(0, 0);
            // Margen: 8 a la derecha para separarla de la tarjeta del lado
            this.pnlAlmuerzosMes.Margin = new System.Windows.Forms.Padding(0, 0, 8, 0);
            // Nombre del control
            this.pnlAlmuerzosMes.Name = "pnlAlmuerzosMes";
            // Margen interior: 16 a los lados y 10 arriba y abajo
            this.pnlAlmuerzosMes.Padding = new System.Windows.Forms.Padding(16, 10, 16, 10);
            // Tamaño (lo calcula el Dock)
            this.pnlAlmuerzosMes.Size = new System.Drawing.Size(318, 88);
            // Orden de tabulación
            this.pnlAlmuerzosMes.TabIndex = 0;
            //
            // lblAlmuerzosMes
            // Número grande de almuerzos reservados este mes. Lo escribe UcInicio.cs.
            //
            // Ocupa el espacio debajo del título
            this.lblAlmuerzosMes.Dock = System.Windows.Forms.DockStyle.Fill;
            // Letra Segoe UI de 20 puntos en negrita
            this.lblAlmuerzosMes.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Color verde SENA
            this.lblAlmuerzosMes.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(169)))), ((int)(((byte)(0)))));
            // Posición: debajo del título
            this.lblAlmuerzosMes.Location = new System.Drawing.Point(16, 30);
            // Nombre del control
            this.lblAlmuerzosMes.Name = "lblAlmuerzosMes";
            // Tamaño (lo calcula el Dock)
            this.lblAlmuerzosMes.Size = new System.Drawing.Size(286, 48);
            // Orden de tabulación
            this.lblAlmuerzosMes.TabIndex = 1;
            // Texto de ejemplo (se reemplaza con el número real)
            this.lblAlmuerzosMes.Text = "0";
            // Texto alineado a la izquierda y centrado de arriba a abajo
            this.lblAlmuerzosMes.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            //
            // lblAlmuerzosMesTitulo
            // Título gris "Almuerzos este mes".
            //
            // Pegada arriba de la tarjeta
            this.lblAlmuerzosMesTitulo.Dock = System.Windows.Forms.DockStyle.Top;
            // Color gris
            this.lblAlmuerzosMesTitulo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(114)))), ((int)(((byte)(128)))));
            // Posición: dentro del margen de la tarjeta
            this.lblAlmuerzosMesTitulo.Location = new System.Drawing.Point(16, 10);
            // Nombre del control
            this.lblAlmuerzosMesTitulo.Name = "lblAlmuerzosMesTitulo";
            // Tamaño: todo el ancho y 20 de alto
            this.lblAlmuerzosMesTitulo.Size = new System.Drawing.Size(286, 20);
            // Orden de tabulación
            this.lblAlmuerzosMesTitulo.TabIndex = 0;
            // Texto que se muestra
            this.lblAlmuerzosMesTitulo.Text = "Almuerzos este mes";
            //
            // pnlGastoMes
            // Tarjeta blanca pequeña "Gasto del mes".
            //
            // Fondo blanco
            this.pnlGastoMes.BackColor = System.Drawing.Color.White;
            // Agrega el valor (primero, para que su Dock Fill se acomode al final)
            this.pnlGastoMes.Controls.Add(this.lblGastoMes);
            // Agrega el título (queda arriba con Dock Top)
            this.pnlGastoMes.Controls.Add(this.lblGastoMesTitulo);
            // Ocupa toda su celda
            this.pnlGastoMes.Dock = System.Windows.Forms.DockStyle.Fill;
            // Posición: columna 1
            this.pnlGastoMes.Location = new System.Drawing.Point(334, 0);
            // Margen: 8 a cada lado para separarla de las otras dos tarjetas
            this.pnlGastoMes.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            // Nombre del control
            this.pnlGastoMes.Name = "pnlGastoMes";
            // Margen interior: 16 a los lados y 10 arriba y abajo
            this.pnlGastoMes.Padding = new System.Windows.Forms.Padding(16, 10, 16, 10);
            // Tamaño (lo calcula el Dock)
            this.pnlGastoMes.Size = new System.Drawing.Size(311, 88);
            // Orden de tabulación
            this.pnlGastoMes.TabIndex = 1;
            //
            // lblGastoMes
            // Valor grande de lo que suman los almuerzos del mes. Lo escribe UcInicio.cs.
            //
            // Ocupa el espacio debajo del título
            this.lblGastoMes.Dock = System.Windows.Forms.DockStyle.Fill;
            // Letra Segoe UI de 20 puntos en negrita
            this.lblGastoMes.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Color casi negro
            this.lblGastoMes.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(41)))), ((int)(((byte)(51)))));
            // Posición: debajo del título
            this.lblGastoMes.Location = new System.Drawing.Point(16, 30);
            // Nombre del control
            this.lblGastoMes.Name = "lblGastoMes";
            // Tamaño (lo calcula el Dock)
            this.lblGastoMes.Size = new System.Drawing.Size(279, 48);
            // Orden de tabulación
            this.lblGastoMes.TabIndex = 1;
            // Texto de ejemplo (se reemplaza con el valor real)
            this.lblGastoMes.Text = "$0";
            // Texto alineado a la izquierda y centrado de arriba a abajo
            this.lblGastoMes.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            //
            // lblGastoMesTitulo
            // Título gris "Gasto del mes".
            //
            // Pegada arriba de la tarjeta
            this.lblGastoMesTitulo.Dock = System.Windows.Forms.DockStyle.Top;
            // Color gris
            this.lblGastoMesTitulo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(114)))), ((int)(((byte)(128)))));
            // Posición: dentro del margen de la tarjeta
            this.lblGastoMesTitulo.Location = new System.Drawing.Point(16, 10);
            // Nombre del control
            this.lblGastoMesTitulo.Name = "lblGastoMesTitulo";
            // Tamaño: todo el ancho y 20 de alto
            this.lblGastoMesTitulo.Size = new System.Drawing.Size(279, 20);
            // Orden de tabulación
            this.lblGastoMesTitulo.TabIndex = 0;
            // Texto que se muestra
            this.lblGastoMesTitulo.Text = "Gasto del mes";
            //
            // pnlPendiente
            // Tarjeta blanca pequeña "Pendiente por pagar".
            //
            // Fondo blanco
            this.pnlPendiente.BackColor = System.Drawing.Color.White;
            // Agrega el valor (primero, para que su Dock Fill se acomode al final)
            this.pnlPendiente.Controls.Add(this.lblPendiente);
            // Agrega el título (queda arriba con Dock Top)
            this.pnlPendiente.Controls.Add(this.lblPendienteTitulo);
            // Ocupa toda su celda
            this.pnlPendiente.Dock = System.Windows.Forms.DockStyle.Fill;
            // Posición: columna 2
            this.pnlPendiente.Location = new System.Drawing.Point(661, 0);
            // Margen: 8 a la izquierda para separarla de la tarjeta del lado
            this.pnlPendiente.Margin = new System.Windows.Forms.Padding(8, 0, 0, 0);
            // Nombre del control
            this.pnlPendiente.Name = "pnlPendiente";
            // Margen interior: 16 a los lados y 10 arriba y abajo
            this.pnlPendiente.Padding = new System.Windows.Forms.Padding(16, 10, 16, 10);
            // Tamaño (lo calcula el Dock)
            this.pnlPendiente.Size = new System.Drawing.Size(319, 88);
            // Orden de tabulación
            this.pnlPendiente.TabIndex = 2;
            //
            // lblPendiente
            // Valor grande de lo que falta por pagar (en ámbar). Lo escribe UcInicio.cs.
            //
            // Ocupa el espacio debajo del título
            this.lblPendiente.Dock = System.Windows.Forms.DockStyle.Fill;
            // Letra Segoe UI de 20 puntos en negrita
            this.lblPendiente.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Color ámbar (llama la atención sin ser rojo)
            this.lblPendiente.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(83)))), ((int)(((byte)(9)))));
            // Posición: debajo del título
            this.lblPendiente.Location = new System.Drawing.Point(16, 30);
            // Nombre del control
            this.lblPendiente.Name = "lblPendiente";
            // Tamaño (lo calcula el Dock)
            this.lblPendiente.Size = new System.Drawing.Size(287, 48);
            // Orden de tabulación
            this.lblPendiente.TabIndex = 1;
            // Texto de ejemplo (se reemplaza con el valor real)
            this.lblPendiente.Text = "$0";
            // Texto alineado a la izquierda y centrado de arriba a abajo
            this.lblPendiente.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            //
            // lblPendienteTitulo
            // Título gris "Pendiente por pagar".
            //
            // Pegada arriba de la tarjeta
            this.lblPendienteTitulo.Dock = System.Windows.Forms.DockStyle.Top;
            // Color gris
            this.lblPendienteTitulo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(114)))), ((int)(((byte)(128)))));
            // Posición: dentro del margen de la tarjeta
            this.lblPendienteTitulo.Location = new System.Drawing.Point(16, 10);
            // Nombre del control
            this.lblPendienteTitulo.Name = "lblPendienteTitulo";
            // Tamaño: todo el ancho y 20 de alto
            this.lblPendienteTitulo.Size = new System.Drawing.Size(287, 20);
            // Orden de tabulación
            this.lblPendienteTitulo.TabIndex = 0;
            // Texto que se muestra
            this.lblPendienteTitulo.Text = "Pendiente por pagar";
            //
            // pnlHorario
            // Recuadro azul claro con el horario del comedor.
            //
            // Fondo azul muy claro
            this.pnlHorario.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(246)))), ((int)(((byte)(255)))));
            // Agrega el detalle (primero, para que su Dock Fill se acomode al final)
            this.pnlHorario.Controls.Add(this.lblHorarioDetalle);
            // Agrega el título (queda arriba con Dock Top)
            this.pnlHorario.Controls.Add(this.lblHorarioTitulo);
            // Ocupa toda su celda de la tabla principal
            this.pnlHorario.Dock = System.Windows.Forms.DockStyle.Fill;
            // Posición: debajo del resumen
            this.pnlHorario.Location = new System.Drawing.Point(0, 360);
            // Sin margen alrededor
            this.pnlHorario.Margin = new System.Windows.Forms.Padding(0);
            // Nombre del control
            this.pnlHorario.Name = "pnlHorario";
            // Margen interior: 20 a los lados y 12 arriba y abajo
            this.pnlHorario.Padding = new System.Windows.Forms.Padding(20, 12, 20, 12);
            // Tamaño (lo calcula el Dock)
            this.pnlHorario.Size = new System.Drawing.Size(980, 88);
            // Orden de tabulación
            this.pnlHorario.TabIndex = 2;
            //
            // lblHorarioDetalle
            // Detalle del horario en dos líneas (el "\r\n" es un salto de línea).
            //
            // Ocupa el espacio debajo del título
            this.lblHorarioDetalle.Dock = System.Windows.Forms.DockStyle.Fill;
            // Color azul oscuro
            this.lblHorarioDetalle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(64)))), ((int)(((byte)(175)))));
            // Posición: debajo del título
            this.lblHorarioDetalle.Location = new System.Drawing.Point(20, 36);
            // Nombre del control
            this.lblHorarioDetalle.Name = "lblHorarioDetalle";
            // Tamaño (lo calcula el Dock)
            this.lblHorarioDetalle.Size = new System.Drawing.Size(940, 40);
            // Orden de tabulación
            this.lblHorarioDetalle.TabIndex = 1;
            // Texto que se muestra
            this.lblHorarioDetalle.Text = "Reservas: de 7:00 a. m. a 9:00 p. m. (hora de Colombia).\r\nEl almuerzo se paga en la ventanilla del comedor. Recuerda presentar tu documento o ficha al ingresar.";
            //
            // lblHorarioTitulo
            // Título "Horario del comedor" en azul oscuro y negrita.
            //
            // Pegada arriba del recuadro
            this.lblHorarioTitulo.Dock = System.Windows.Forms.DockStyle.Top;
            // Letra Segoe UI de 11 puntos en negrita
            this.lblHorarioTitulo.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Color azul muy oscuro
            this.lblHorarioTitulo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(58)))), ((int)(((byte)(138)))));
            // Posición: dentro del margen del recuadro
            this.lblHorarioTitulo.Location = new System.Drawing.Point(20, 12);
            // Nombre del control
            this.lblHorarioTitulo.Name = "lblHorarioTitulo";
            // Tamaño: todo el ancho y 24 de alto
            this.lblHorarioTitulo.Size = new System.Drawing.Size(940, 24);
            // Orden de tabulación
            this.lblHorarioTitulo.TabIndex = 0;
            // Texto que se muestra
            this.lblHorarioTitulo.Text = "Horario del comedor";
            //
            // UcInicio
            // La sección Inicio completa: fondo gris muy claro, igual al área de contenido del panel.
            //
            // Tamaño de letra con el que se diseñó (sirve para escalar si cambia la fuente o el DPI)
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            // Escala los controles según la fuente
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            // Muestra barras de desplazamiento si la ventana queda más pequeña que el contenido
            this.AutoScroll = true;
            // Tamaño mínimo del contenido: por debajo de esto aparecen las barras de desplazamiento
            this.AutoScrollMinSize = new System.Drawing.Size(680, 540);
            // Fondo gris muy claro
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(245)))), ((int)(((byte)(241)))));
            // Agrega la tabla (se agrega primero para que el Dock Fill se acomode al final)
            this.Controls.Add(this.tlpInicio);
            // Agrega la fecha
            this.Controls.Add(this.lblFecha);
            // Agrega la bienvenida (la última agregada queda más arriba con Dock Top)
            this.Controls.Add(this.lblBienvenida);
            // Fuente de toda la sección: Segoe UI de 9.75 puntos
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Nombre de la sección
            this.Name = "UcInicio";
            // Tamaño en [Diseño] (en el panel se estira con Dock Fill)
            this.Size = new System.Drawing.Size(980, 600);
            // Reanuda el acomodo de la tabla principal
            this.tlpInicio.ResumeLayout(false);
            // Reanuda el acomodo de la tarjeta del menú
            this.pnlTarjetaMenu.ResumeLayout(false);
            // Reanuda el acomodo del panel de datos del menú
            this.pnlDetalleMenu.ResumeLayout(false);
            // Reanuda el acomodo del panel del botón
            this.pnlAccion.ResumeLayout(false);
            // Reanuda el acomodo del panel del precio
            this.pnlPrecio.ResumeLayout(false);
            // Termina la configuración de la foto
            ((System.ComponentModel.ISupportInitialize)(this.picMenu)).EndInit();
            // Reanuda el acomodo de la tabla del resumen
            this.tlpResumen.ResumeLayout(false);
            // Reanuda el acomodo de la tarjeta "Almuerzos este mes"
            this.pnlAlmuerzosMes.ResumeLayout(false);
            // Reanuda el acomodo de la tarjeta "Gasto del mes"
            this.pnlGastoMes.ResumeLayout(false);
            // Reanuda el acomodo de la tarjeta "Pendiente por pagar"
            this.pnlPendiente.ResumeLayout(false);
            // Reanuda el acomodo del recuadro del horario
            this.pnlHorario.ResumeLayout(false);
            // Reanuda el acomodo de la sección
            this.ResumeLayout(false);

        }

        // Fin de la región del diseñador
        #endregion

        // Título grande "Bienvenido, <nombre>"
        private System.Windows.Forms.Label lblBienvenida;
        // Fecha de hoy
        private System.Windows.Forms.Label lblFecha;
        // Tabla que acomoda las tarjetas
        private System.Windows.Forms.TableLayoutPanel tlpInicio;
        // Tarjeta blanca del menú del día
        private System.Windows.Forms.Panel pnlTarjetaMenu;
        // Panel de los datos del menú
        private System.Windows.Forms.Panel pnlDetalleMenu;
        // Aviso debajo del botón
        private System.Windows.Forms.Label lblAvisoReserva;
        // Franja del botón
        private System.Windows.Forms.Panel pnlAccion;
        // Botón "Reservar almuerzo"
        private System.Windows.Forms.Button btnReservar;
        // Franja del precio y los cupos
        private System.Windows.Forms.Panel pnlPrecio;
        // Cupos disponibles
        private System.Windows.Forms.Label lblCupos;
        // Precio del almuerzo
        private System.Windows.Forms.Label lblPrecio;
        // Descripción del menú
        private System.Windows.Forms.Label lblMenuDescripcion;
        // Nombre del menú
        private System.Windows.Forms.Label lblMenuNombre;
        // Etiqueta "Menú del día"
        private System.Windows.Forms.Label lblMenuEtiqueta;
        // Foto del menú
        private System.Windows.Forms.PictureBox picMenu;
        // Tabla de las tarjetas del resumen
        private System.Windows.Forms.TableLayoutPanel tlpResumen;
        // Tarjeta "Almuerzos este mes"
        private System.Windows.Forms.Panel pnlAlmuerzosMes;
        // Número de almuerzos del mes
        private System.Windows.Forms.Label lblAlmuerzosMes;
        // Título "Almuerzos este mes"
        private System.Windows.Forms.Label lblAlmuerzosMesTitulo;
        // Tarjeta "Gasto del mes"
        private System.Windows.Forms.Panel pnlGastoMes;
        // Valor del gasto del mes
        private System.Windows.Forms.Label lblGastoMes;
        // Título "Gasto del mes"
        private System.Windows.Forms.Label lblGastoMesTitulo;
        // Tarjeta "Pendiente por pagar"
        private System.Windows.Forms.Panel pnlPendiente;
        // Valor pendiente por pagar
        private System.Windows.Forms.Label lblPendiente;
        // Título "Pendiente por pagar"
        private System.Windows.Forms.Label lblPendienteTitulo;
        // Recuadro del horario
        private System.Windows.Forms.Panel pnlHorario;
        // Detalle del horario
        private System.Windows.Forms.Label lblHorarioDetalle;
        // Título "Horario del comedor"
        private System.Windows.Forms.Label lblHorarioTitulo;
    }
}
