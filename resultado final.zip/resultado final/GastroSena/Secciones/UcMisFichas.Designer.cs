﻿// Visual Studio regenera este archivo cuando se edita en [Diseño], y los comentarios de adentro se pueden borrar.
// Archivo: Secciones/UcMisFichas.Designer.cs
// Parte "de diseño" de la sección "Mis Fichas": aquí se crean el título, la descripción y la tarjeta
// blanca con la tabla de reservas (DataGridView) y los totales de abajo.
// Para cambiarla, abre UcMisFichas.cs en la vista [Diseño] (las columnas se editan con "Editar columnas...").

// Espacio de nombres de las secciones (carpeta Secciones)
namespace GastroSena.Secciones
{
    /// <summary>
    /// Segunda parte (partial) de la clase UcMisFichas: contiene el código que escribe el diseñador.
    /// La otra parte, con la lógica, está en UcMisFichas.cs.
    /// </summary>
    partial class UcMisFichas
    {
        /// <summary>
        /// Variable del diseñador necesaria: guarda los componentes que hay que liberar al cerrar.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpia los recursos que se estén usando. Se ejecuta cuando la sección se cambia por otra.
        /// </summary>
        /// <param name="disposing">true si se deben liberar los recursos administrados; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            // Si se están liberando recursos y hay componentes guardados...
            if (disposing && (components != null))
            {
                // ...los libera
                components.Dispose();
            }
            // Llama al Dispose de la clase base (UserControl) para que termine de limpiar
            base.Dispose(disposing);
        }

        // Región con el código que escribe el Diseñador de componentes
        #region Código generado por el Diseñador de componentes

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// Crea los controles de la sección, les pone sus propiedades, los agrega y conecta sus eventos.
        /// </summary>
        private void InitializeComponent()
        {
            // Estilo de los encabezados de la tabla (fondo gris verdoso y letra seminegrita)
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            // Estilo de la columna "Estado de pago" (letra seminegrita)
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            // Estilo normal de las celdas de la tabla
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            // Crea la etiqueta del título grande
            this.lblTitulo = new System.Windows.Forms.Label();
            // Crea la etiqueta de la descripción
            this.lblDescripcion = new System.Windows.Forms.Label();
            // Crea la tarjeta blanca
            this.pnlTarjeta = new System.Windows.Forms.Panel();
            // Crea la tabla de reservas
            this.dgvFichas = new System.Windows.Forms.DataGridView();
            // Crea la columna "Fecha"
            this.colFecha = new System.Windows.Forms.DataGridViewTextBoxColumn();
            // Crea la columna "Menú"
            this.colMenu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            // Crea la columna "Precio"
            this.colPrecio = new System.Windows.Forms.DataGridViewTextBoxColumn();
            // Crea la columna "Estado de pago"
            this.colEstadoPago = new System.Windows.Forms.DataGridViewTextBoxColumn();
            // Crea la columna "Estado"
            this.colEstado = new System.Windows.Forms.DataGridViewTextBoxColumn();
            // Crea la línea gris de arriba de los totales
            this.pnlLineaTotales = new System.Windows.Forms.Panel();
            // Crea la tabla de los tres totales
            this.tlpTotales = new System.Windows.Forms.TableLayoutPanel();
            // Crea la etiqueta del total de almuerzos
            this.lblTotalAlmuerzos = new System.Windows.Forms.Label();
            // Crea la etiqueta del total pagado
            this.lblTotalPagado = new System.Windows.Forms.Label();
            // Crea la etiqueta del total pendiente
            this.lblTotalPendiente = new System.Windows.Forms.Label();
            // Pausa el acomodo de la tarjeta mientras se configura
            this.pnlTarjeta.SuspendLayout();
            // Avisa a la tabla de reservas que empieza su configuración
            ((System.ComponentModel.ISupportInitialize)(this.dgvFichas)).BeginInit();
            // Pausa el acomodo de la tabla de totales
            this.tlpTotales.SuspendLayout();
            // Pausa el acomodo de la sección mientras se configura
            this.SuspendLayout();
            //
            // lblTitulo
            // Título grande "Mis Fichas": arriba de todo, Segoe UI de 20 puntos en negrita.
            //
            // Pegada arriba, ocupando todo el ancho
            this.lblTitulo.Dock = System.Windows.Forms.DockStyle.Top;
            // Letra Segoe UI de 20 puntos en negrita
            this.lblTitulo.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Color casi negro
            this.lblTitulo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(41)))), ((int)(((byte)(51)))));
            // Posición: arriba a la izquierda
            this.lblTitulo.Location = new System.Drawing.Point(0, 0);
            // Nombre del control
            this.lblTitulo.Name = "lblTitulo";
            // Tamaño: todo el ancho y 48 de alto
            this.lblTitulo.Size = new System.Drawing.Size(980, 48);
            // Orden de tabulación
            this.lblTitulo.TabIndex = 0;
            // Texto que se muestra
            this.lblTitulo.Text = "Mis Fichas";
            // Texto alineado a la izquierda y centrado de arriba a abajo
            this.lblTitulo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            //
            // lblDescripcion
            // Descripción gris de lo que muestra la sección, debajo del título.
            //
            // Pegada arriba, debajo del título
            this.lblDescripcion.Dock = System.Windows.Forms.DockStyle.Top;
            // Letra Segoe UI de 11 puntos
            this.lblDescripcion.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Color gris
            this.lblDescripcion.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(114)))), ((int)(((byte)(128)))));
            // Posición: debajo del título
            this.lblDescripcion.Location = new System.Drawing.Point(0, 48);
            // Nombre del control
            this.lblDescripcion.Name = "lblDescripcion";
            // Tamaño: todo el ancho; el alto deja un espacio antes de la tarjeta
            this.lblDescripcion.Size = new System.Drawing.Size(980, 44);
            // Orden de tabulación
            this.lblDescripcion.TabIndex = 1;
            // Texto que se muestra
            this.lblDescripcion.Text = "Tus reservas de almuerzo y su estado de pago, de la más reciente a la más antigua.";
            //
            // pnlTarjeta
            // Tarjeta blanca que ocupa el resto del espacio: la tabla arriba y los totales abajo.
            //
            // Fondo blanco
            this.pnlTarjeta.BackColor = System.Drawing.Color.White;
            // Agrega la tabla (primero, para que su Dock Fill se acomode al final)
            this.pnlTarjeta.Controls.Add(this.dgvFichas);
            // Agrega la línea gris (queda justo encima de los totales)
            this.pnlTarjeta.Controls.Add(this.pnlLineaTotales);
            // Agrega los totales (el último agregado queda más abajo con Dock Bottom)
            this.pnlTarjeta.Controls.Add(this.tlpTotales);
            // Ocupa todo el espacio que sobra debajo de las etiquetas
            this.pnlTarjeta.Dock = System.Windows.Forms.DockStyle.Fill;
            // Posición: debajo de la descripción
            this.pnlTarjeta.Location = new System.Drawing.Point(0, 92);
            // Nombre del control
            this.pnlTarjeta.Name = "pnlTarjeta";
            // Margen interior de 24 píxeles
            this.pnlTarjeta.Padding = new System.Windows.Forms.Padding(24);
            // Tamaño (lo calcula el Dock)
            this.pnlTarjeta.Size = new System.Drawing.Size(980, 508);
            // Orden de tabulación
            this.pnlTarjeta.TabIndex = 2;
            //
            // dgvFichas
            // Tabla de solo lectura con las reservas. Las filas las agrega UcMisFichas.cs.
            //
            // No deja agregar filas escribiendo en la tabla
            this.dgvFichas.AllowUserToAddRows = false;
            // No deja borrar filas con la tecla Supr
            this.dgvFichas.AllowUserToDeleteRows = false;
            // No deja cambiar el alto de las filas con el mouse
            this.dgvFichas.AllowUserToResizeRows = false;
            // Las columnas se reparten todo el ancho de la tabla
            this.dgvFichas.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            // Fondo blanco donde no hay filas
            this.dgvFichas.BackgroundColor = System.Drawing.Color.White;
            // Sin borde alrededor de la tabla
            this.dgvFichas.BorderStyle = System.Windows.Forms.BorderStyle.None;
            // Solo líneas horizontales entre filas
            this.dgvFichas.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            // Encabezados sin borde
            this.dgvFichas.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            // Encabezado: texto a la izquierda y centrado de arriba a abajo
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            // Encabezado: fondo gris verdoso muy claro
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(245)))), ((int)(((byte)(241)))));
            // Encabezado: letra Segoe UI Semibold
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Encabezado: letra gris oscura
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(65)))), ((int)(((byte)(81)))));
            // Encabezado: 8 píxeles de espacio a la izquierda del texto
            dataGridViewCellStyle1.Padding = new System.Windows.Forms.Padding(8, 0, 0, 0);
            // Encabezado: no cambia de color al seleccionarlo
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(245)))), ((int)(((byte)(241)))));
            // Encabezado: la letra tampoco cambia al seleccionarlo
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(65)))), ((int)(((byte)(81)))));
            // Encabezado: el texto no pasa a otra línea
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            // Aplica el estilo a los encabezados
            this.dgvFichas.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            // Alto de los encabezados: 40
            this.dgvFichas.ColumnHeadersHeight = 40;
            // El alto de los encabezados no se puede cambiar con el mouse
            this.dgvFichas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            // Agrega las cinco columnas a la tabla, en este orden
            this.dgvFichas.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colFecha,
            this.colMenu,
            this.colPrecio,
            this.colEstadoPago,
            this.colEstado});
            // Celdas: texto a la izquierda y centrado de arriba a abajo
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            // Celdas: fondo blanco
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            // Celdas: letra Segoe UI de 9.75 puntos
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Celdas: letra casi negra
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(41)))), ((int)(((byte)(51)))));
            // Celdas: 8 píxeles de espacio a la izquierda del texto
            dataGridViewCellStyle3.Padding = new System.Windows.Forms.Padding(8, 0, 0, 0);
            // Fila seleccionada: verde muy claro
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(248)))), ((int)(((byte)(235)))));
            // Fila seleccionada: la letra sigue casi negra
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(41)))), ((int)(((byte)(51)))));
            // Celdas: el texto no pasa a otra línea
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            // Aplica el estilo a todas las celdas
            this.dgvFichas.DefaultCellStyle = dataGridViewCellStyle3;
            // Ocupa todo el espacio de la tarjeta que dejan los totales
            this.dgvFichas.Dock = System.Windows.Forms.DockStyle.Fill;
            // Usa los colores de encabezado que pusimos, no los del tema de Windows
            this.dgvFichas.EnableHeadersVisualStyles = false;
            // Color gris claro de las líneas entre filas
            this.dgvFichas.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(231)))), ((int)(((byte)(235)))));
            // Posición: dentro del margen de la tarjeta
            this.dgvFichas.Location = new System.Drawing.Point(24, 24);
            // Solo se puede seleccionar una fila a la vez
            this.dgvFichas.MultiSelect = false;
            // Nombre del control
            this.dgvFichas.Name = "dgvFichas";
            // Solo lectura: no se puede escribir en las celdas
            this.dgvFichas.ReadOnly = true;
            // Oculta la columna gris de la izquierda (la de los triangulitos)
            this.dgvFichas.RowHeadersVisible = false;
            // Alto de cada fila: 38
            this.dgvFichas.RowTemplate.Height = 38;
            // Al hacer clic se selecciona la fila completa
            this.dgvFichas.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            // Tamaño (lo calcula el Dock)
            this.dgvFichas.Size = new System.Drawing.Size(932, 403);
            // Orden de tabulación
            this.dgvFichas.TabIndex = 0;
            //
            // colFecha
            // Columna "Fecha": día de la reserva (dd/mm/aaaa).
            //
            // Parte del ancho que le toca (comparada con las otras columnas)
            this.colFecha.FillWeight = 16F;
            // Texto del encabezado
            this.colFecha.HeaderText = "Fecha";
            // Nombre de la columna
            this.colFecha.Name = "colFecha";
            // Solo lectura
            this.colFecha.ReadOnly = true;
            // No se ordena al hacer clic en el encabezado (la lista ya viene ordenada)
            this.colFecha.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            //
            // colMenu
            // Columna "Menú": nombre del menú reservado.
            //
            // Parte del ancho que le toca (es la más ancha)
            this.colMenu.FillWeight = 34F;
            // Texto del encabezado
            this.colMenu.HeaderText = "Menú";
            // Nombre de la columna
            this.colMenu.Name = "colMenu";
            // Solo lectura
            this.colMenu.ReadOnly = true;
            // No se ordena al hacer clic en el encabezado
            this.colMenu.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            //
            // colPrecio
            // Columna "Precio": lo que vale el almuerzo en pesos.
            //
            // Parte del ancho que le toca
            this.colPrecio.FillWeight = 14F;
            // Texto del encabezado
            this.colPrecio.HeaderText = "Precio";
            // Nombre de la columna
            this.colPrecio.Name = "colPrecio";
            // Solo lectura
            this.colPrecio.ReadOnly = true;
            // No se ordena al hacer clic en el encabezado
            this.colPrecio.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            //
            // colEstadoPago
            // Columna "Estado de pago": Pagado (verde), Pendiente (amarillo) o Gratis (azul). Los colores los pone UcMisFichas.cs.
            //
            // Estado de pago: letra Segoe UI Semibold
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Aplica el estilo a la columna
            this.colEstadoPago.DefaultCellStyle = dataGridViewCellStyle2;
            // Parte del ancho que le toca
            this.colEstadoPago.FillWeight = 18F;
            // Texto del encabezado
            this.colEstadoPago.HeaderText = "Estado de pago";
            // Nombre de la columna
            this.colEstadoPago.Name = "colEstadoPago";
            // Solo lectura
            this.colEstadoPago.ReadOnly = true;
            // No se ordena al hacer clic en el encabezado
            this.colEstadoPago.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            //
            // colEstado
            // Columna "Estado": Reservado (si es de hoy) o Consumido (si ya pasó).
            //
            // Parte del ancho que le toca
            this.colEstado.FillWeight = 18F;
            // Texto del encabezado
            this.colEstado.HeaderText = "Estado";
            // Nombre de la columna
            this.colEstado.Name = "colEstado";
            // Solo lectura
            this.colEstado.ReadOnly = true;
            // No se ordena al hacer clic en el encabezado
            this.colEstado.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            //
            // pnlLineaTotales
            // Línea gris de 1 píxel que separa la tabla de los totales.
            //
            // Color gris claro
            this.pnlLineaTotales.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(231)))), ((int)(((byte)(235)))));
            // Pegada abajo, encima de los totales
            this.pnlLineaTotales.Dock = System.Windows.Forms.DockStyle.Bottom;
            // Posición: debajo de la tabla
            this.pnlLineaTotales.Location = new System.Drawing.Point(24, 427);
            // Nombre del control
            this.pnlLineaTotales.Name = "pnlLineaTotales";
            // Alto de 1 píxel
            this.pnlLineaTotales.Size = new System.Drawing.Size(932, 1);
            // Orden de tabulación
            this.pnlLineaTotales.TabIndex = 1;
            //
            // tlpTotales
            // Tabla de tres columnas iguales con los totales, abajo de la tarjeta.
            //
            // Tres columnas
            this.tlpTotales.ColumnCount = 3;
            // Columna 0: un tercio del ancho
            this.tlpTotales.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            // Columna 1: un tercio del ancho
            this.tlpTotales.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            // Columna 2: un tercio del ancho
            this.tlpTotales.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            // Pone el total de almuerzos en la columna 0
            this.tlpTotales.Controls.Add(this.lblTotalAlmuerzos, 0, 0);
            // Pone el total pagado en la columna 1
            this.tlpTotales.Controls.Add(this.lblTotalPagado, 1, 0);
            // Pone el total pendiente en la columna 2
            this.tlpTotales.Controls.Add(this.lblTotalPendiente, 2, 0);
            // Pegada abajo de la tarjeta
            this.tlpTotales.Dock = System.Windows.Forms.DockStyle.Bottom;
            // Posición: abajo de la tarjeta
            this.tlpTotales.Location = new System.Drawing.Point(24, 428);
            // Nombre del control
            this.tlpTotales.Name = "tlpTotales";
            // Una sola fila
            this.tlpTotales.RowCount = 1;
            // La fila ocupa todo el alto
            this.tlpTotales.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            // Tamaño: todo el ancho y 56 de alto
            this.tlpTotales.Size = new System.Drawing.Size(932, 56);
            // Orden de tabulación
            this.tlpTotales.TabIndex = 2;
            //
            // lblTotalAlmuerzos
            // "Total de almuerzos: N". Lo escribe UcMisFichas.cs.
            //
            // Ocupa toda su celda
            this.lblTotalAlmuerzos.Dock = System.Windows.Forms.DockStyle.Fill;
            // Letra Segoe UI Semibold de 11 puntos
            this.lblTotalAlmuerzos.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Color casi negro
            this.lblTotalAlmuerzos.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(41)))), ((int)(((byte)(51)))));
            // Posición: columna 0
            this.lblTotalAlmuerzos.Location = new System.Drawing.Point(0, 0);
            // Sin margen
            this.lblTotalAlmuerzos.Margin = new System.Windows.Forms.Padding(0);
            // Nombre del control
            this.lblTotalAlmuerzos.Name = "lblTotalAlmuerzos";
            // Margen interior: 8 a la izquierda, para que el texto quede alineado con la tabla
            this.lblTotalAlmuerzos.Padding = new System.Windows.Forms.Padding(8, 0, 0, 0);
            // Tamaño (lo calcula el Dock)
            this.lblTotalAlmuerzos.Size = new System.Drawing.Size(310, 56);
            // Orden de tabulación
            this.lblTotalAlmuerzos.TabIndex = 0;
            // Texto de ejemplo (se reemplaza con el total real)
            this.lblTotalAlmuerzos.Text = "Total de almuerzos: 0";
            // Texto alineado a la izquierda y centrado de arriba a abajo
            this.lblTotalAlmuerzos.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            //
            // lblTotalPagado
            // "Total pagado: $N" en verde. Lo escribe UcMisFichas.cs.
            //
            // Ocupa toda su celda
            this.lblTotalPagado.Dock = System.Windows.Forms.DockStyle.Fill;
            // Letra Segoe UI Semibold de 11 puntos
            this.lblTotalPagado.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Color verde oscuro
            this.lblTotalPagado.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(101)))), ((int)(((byte)(52)))));
            // Posición: columna 1
            this.lblTotalPagado.Location = new System.Drawing.Point(310, 0);
            // Sin margen
            this.lblTotalPagado.Margin = new System.Windows.Forms.Padding(0);
            // Nombre del control
            this.lblTotalPagado.Name = "lblTotalPagado";
            // Margen interior: 8 a la izquierda, para que el texto quede alineado con la tabla
            this.lblTotalPagado.Padding = new System.Windows.Forms.Padding(8, 0, 0, 0);
            // Tamaño (lo calcula el Dock)
            this.lblTotalPagado.Size = new System.Drawing.Size(311, 56);
            // Orden de tabulación
            this.lblTotalPagado.TabIndex = 1;
            // Texto de ejemplo (se reemplaza con el total real)
            this.lblTotalPagado.Text = "Total pagado: $0";
            // Texto alineado a la izquierda y centrado de arriba a abajo
            this.lblTotalPagado.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            //
            // lblTotalPendiente
            // "Total pendiente: $N" en ámbar. Lo escribe UcMisFichas.cs.
            //
            // Ocupa toda su celda
            this.lblTotalPendiente.Dock = System.Windows.Forms.DockStyle.Fill;
            // Letra Segoe UI Semibold de 11 puntos
            this.lblTotalPendiente.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Color ámbar
            this.lblTotalPendiente.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(83)))), ((int)(((byte)(9)))));
            // Posición: columna 2
            this.lblTotalPendiente.Location = new System.Drawing.Point(621, 0);
            // Sin margen
            this.lblTotalPendiente.Margin = new System.Windows.Forms.Padding(0);
            // Nombre del control
            this.lblTotalPendiente.Name = "lblTotalPendiente";
            // Margen interior: 8 a la izquierda, para que el texto quede alineado con la tabla
            this.lblTotalPendiente.Padding = new System.Windows.Forms.Padding(8, 0, 0, 0);
            // Tamaño (lo calcula el Dock)
            this.lblTotalPendiente.Size = new System.Drawing.Size(311, 56);
            // Orden de tabulación
            this.lblTotalPendiente.TabIndex = 2;
            // Texto de ejemplo (se reemplaza con el total real)
            this.lblTotalPendiente.Text = "Total pendiente: $0";
            // Texto alineado a la izquierda y centrado de arriba a abajo
            this.lblTotalPendiente.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            //
            // UcMisFichas
            // La sección completa: fondo gris muy claro, igual al área de contenido del panel.
            //
            // Tamaño de letra con el que se diseñó (sirve para escalar si cambia la fuente o el DPI)
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            // Escala los controles según la fuente
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            // Muestra barras de desplazamiento si la ventana queda más pequeña que el contenido
            this.AutoScroll = true;
            // Tamaño mínimo del contenido: por debajo de esto aparecen las barras de desplazamiento
            this.AutoScrollMinSize = new System.Drawing.Size(640, 400);
            // Fondo gris muy claro
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(245)))), ((int)(((byte)(241)))));
            // Agrega la tarjeta (se agrega primero para que el Dock Fill se acomode al final)
            this.Controls.Add(this.pnlTarjeta);
            // Agrega la descripción
            this.Controls.Add(this.lblDescripcion);
            // Agrega el título (el último agregado queda más arriba con Dock Top)
            this.Controls.Add(this.lblTitulo);
            // Fuente de toda la sección: Segoe UI de 9.75 puntos
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Nombre de la sección
            this.Name = "UcMisFichas";
            // Tamaño en [Diseño] (en el panel se estira con Dock Fill)
            this.Size = new System.Drawing.Size(980, 600);
            // Conecta el evento Load con UcMisFichas_Load (llena la tabla y los totales)
            this.Load += new System.EventHandler(this.UcMisFichas_Load);
            // Reanuda el acomodo de la tarjeta
            this.pnlTarjeta.ResumeLayout(false);
            // Termina la configuración de la tabla de reservas
            ((System.ComponentModel.ISupportInitialize)(this.dgvFichas)).EndInit();
            // Reanuda el acomodo de la tabla de totales
            this.tlpTotales.ResumeLayout(false);
            // Reanuda el acomodo de la sección
            this.ResumeLayout(false);

        }

        // Fin de la región del diseñador
        #endregion

        // Título grande de la sección
        private System.Windows.Forms.Label lblTitulo;
        // Descripción de la sección
        private System.Windows.Forms.Label lblDescripcion;
        // Tarjeta blanca
        private System.Windows.Forms.Panel pnlTarjeta;
        // Tabla de reservas
        private System.Windows.Forms.DataGridView dgvFichas;
        // Columna "Fecha"
        private System.Windows.Forms.DataGridViewTextBoxColumn colFecha;
        // Columna "Menú"
        private System.Windows.Forms.DataGridViewTextBoxColumn colMenu;
        // Columna "Precio"
        private System.Windows.Forms.DataGridViewTextBoxColumn colPrecio;
        // Columna "Estado de pago"
        private System.Windows.Forms.DataGridViewTextBoxColumn colEstadoPago;
        // Columna "Estado"
        private System.Windows.Forms.DataGridViewTextBoxColumn colEstado;
        // Línea gris encima de los totales
        private System.Windows.Forms.Panel pnlLineaTotales;
        // Tabla de los totales
        private System.Windows.Forms.TableLayoutPanel tlpTotales;
        // Total de almuerzos
        private System.Windows.Forms.Label lblTotalAlmuerzos;
        // Total pagado
        private System.Windows.Forms.Label lblTotalPagado;
        // Total pendiente
        private System.Windows.Forms.Label lblTotalPendiente;
    }
}
