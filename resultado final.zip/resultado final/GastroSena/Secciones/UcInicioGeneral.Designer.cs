﻿// Visual Studio regenera este archivo cuando se edita en [Diseño], y los comentarios de adentro se pueden borrar.
// Archivo: Secciones/UcInicioGeneral.Designer.cs
// Parte "de diseño" de la sección Inicio de Instructor, Encargado e Invitado: aquí se crean la bienvenida, el perfil y la tarjeta blanca.
// Para cambiar cómo se ve, abre UcInicioGeneral.cs en la vista [Diseño].

// Espacio de nombres de las secciones (carpeta Secciones)
namespace GastroSena.Secciones
{
    /// <summary>
    /// Segunda parte (partial) de la clase UcInicioGeneral: contiene el código que escribe el diseñador.
    /// </summary>
    partial class UcInicioGeneral
    {
        /// <summary>
        /// Variable del diseñador necesaria: guarda los componentes que hay que liberar al cerrar.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpia los recursos que se estén usando. Se ejecuta cuando la sección se cambia por otra.
        /// </summary>
        /// <param name="disposing">true si se deben liberar los recursos administrados; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            // Si se están liberando recursos y hay componentes guardados...
            if (disposing && (components != null))
            {
                // ...los libera
                components.Dispose();
            }
            // Llama al Dispose de la clase base (UserControl) para que termine de limpiar
            base.Dispose(disposing);
        }

        // Región con el código que escribe el Diseñador de componentes
        #region Código generado por el Diseñador de componentes

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// Crea los controles de la sección, les pone sus propiedades y los agrega.
        /// </summary>
        private void InitializeComponent()
        {
            // Crea la etiqueta grande de bienvenida
            this.lblBienvenida = new System.Windows.Forms.Label();
            // Crea la etiqueta del perfil
            this.lblPerfil = new System.Windows.Forms.Label();
            // Crea la tarjeta blanca
            this.pnlTarjeta = new System.Windows.Forms.Panel();
            // Crea la etiqueta con la indicación de usar el menú
            this.lblIndicacion = new System.Windows.Forms.Label();
            // Crea la etiqueta "En construcción"
            this.lblEnConstruccion = new System.Windows.Forms.Label();
            // Pausa el acomodo de la tarjeta mientras se configura
            this.pnlTarjeta.SuspendLayout();
            // Pausa el acomodo de la sección mientras se configura
            this.SuspendLayout();
            //
            // lblBienvenida
            // Título grande "Bienvenido, <nombre>": arriba de todo. El nombre lo escribe MostrarBienvenida.
            //
            // Pegada arriba, ocupando todo el ancho
            this.lblBienvenida.Dock = System.Windows.Forms.DockStyle.Top;
            // Letra Segoe UI de 20 puntos en negrita
            this.lblBienvenida.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Color casi negro
            this.lblBienvenida.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(41)))), ((int)(((byte)(51)))));
            // Posición: arriba a la izquierda
            this.lblBienvenida.Location = new System.Drawing.Point(0, 0);
            // Nombre del control
            this.lblBienvenida.Name = "lblBienvenida";
            // Tamaño: todo el ancho y 48 de alto
            this.lblBienvenida.Size = new System.Drawing.Size(980, 48);
            // Orden de tabulación
            this.lblBienvenida.TabIndex = 0;
            // Texto de ejemplo (se reemplaza con el nombre real al abrir la sección)
            this.lblBienvenida.Text = "Bienvenido, usuario";
            // Texto alineado a la izquierda y centrado de arriba a abajo
            this.lblBienvenida.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            //
            // lblPerfil
            // Perfil del usuario en verde, debajo de la bienvenida.
            //
            // Pegada arriba, debajo de la bienvenida
            this.lblPerfil.Dock = System.Windows.Forms.DockStyle.Top;
            // Letra Segoe UI Semibold de 11 puntos
            this.lblPerfil.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Color verde SENA
            this.lblPerfil.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(169)))), ((int)(((byte)(0)))));
            // Posición: debajo de la bienvenida
            this.lblPerfil.Location = new System.Drawing.Point(0, 48);
            // Nombre del control
            this.lblPerfil.Name = "lblPerfil";
            // Tamaño: todo el ancho; el alto deja un espacio antes de la tarjeta
            this.lblPerfil.Size = new System.Drawing.Size(980, 44);
            // Orden de tabulación
            this.lblPerfil.TabIndex = 1;
            // Texto de ejemplo (se reemplaza con el perfil real)
            this.lblPerfil.Text = "Perfil: ";
            //
            // pnlTarjeta
            // Tarjeta blanca que ocupa el resto del espacio.
            //
            // Fondo blanco
            this.pnlTarjeta.BackColor = System.Drawing.Color.White;
            // Agrega "En construcción" dentro de la tarjeta
            this.pnlTarjeta.Controls.Add(this.lblEnConstruccion);
            // Agrega la indicación dentro de la tarjeta
            this.pnlTarjeta.Controls.Add(this.lblIndicacion);
            // Ocupa todo el espacio que sobra debajo de las etiquetas
            this.pnlTarjeta.Dock = System.Windows.Forms.DockStyle.Fill;
            // Posición: debajo del perfil
            this.pnlTarjeta.Location = new System.Drawing.Point(0, 92);
            // Nombre del control
            this.pnlTarjeta.Name = "pnlTarjeta";
            // Margen interior de 24 píxeles para que el texto no quede pegado al borde
            this.pnlTarjeta.Padding = new System.Windows.Forms.Padding(24);
            // Tamaño (lo calcula el Dock)
            this.pnlTarjeta.Size = new System.Drawing.Size(980, 508);
            // Orden de tabulación
            this.pnlTarjeta.TabIndex = 2;
            //
            // lblIndicacion
            // Indicación arriba de la tarjeta: explica cómo moverse por el panel.
            //
            // Pegada arriba dentro de la tarjeta
            this.lblIndicacion.Dock = System.Windows.Forms.DockStyle.Top;
            // Letra Segoe UI de 11 puntos
            this.lblIndicacion.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Color gris oscuro
            this.lblIndicacion.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(85)))), ((int)(((byte)(99)))));
            // Posición: dentro del margen de la tarjeta
            this.lblIndicacion.Location = new System.Drawing.Point(24, 24);
            // Nombre del control
            this.lblIndicacion.Name = "lblIndicacion";
            // Tamaño: todo el ancho de la tarjeta y 32 de alto
            this.lblIndicacion.Size = new System.Drawing.Size(932, 32);
            // Orden de tabulación
            this.lblIndicacion.TabIndex = 0;
            // Texto que se muestra
            this.lblIndicacion.Text = "Usa el menú de la izquierda para entrar a cada sección.";
            //
            // lblEnConstruccion
            // Texto "En construcción" centrado en la tarjeta.
            //
            // Ocupa todo el espacio que sobra en la tarjeta
            this.lblEnConstruccion.Dock = System.Windows.Forms.DockStyle.Fill;
            // Letra Segoe UI de 15.75 puntos
            this.lblEnConstruccion.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Color gris
            this.lblEnConstruccion.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(114)))), ((int)(((byte)(128)))));
            // Posición: debajo de la indicación
            this.lblEnConstruccion.Location = new System.Drawing.Point(24, 56);
            // Nombre del control
            this.lblEnConstruccion.Name = "lblEnConstruccion";
            // Tamaño (lo calcula el Dock)
            this.lblEnConstruccion.Size = new System.Drawing.Size(932, 428);
            // Orden de tabulación
            this.lblEnConstruccion.TabIndex = 1;
            // Texto que se muestra
            this.lblEnConstruccion.Text = "En construcción";
            // Texto centrado a lo ancho y a lo alto
            this.lblEnConstruccion.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            //
            // UcInicioGeneral
            // La sección Inicio completa: fondo gris muy claro, igual al área de contenido del panel.
            //
            // Tamaño de letra con el que se diseñó (sirve para escalar si cambia la fuente o el DPI)
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            // Escala los controles según la fuente
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            // Fondo gris muy claro
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(245)))), ((int)(((byte)(241)))));
            // Agrega la tarjeta (se agrega primero para que el Dock Fill se acomode al final)
            this.Controls.Add(this.pnlTarjeta);
            // Agrega la etiqueta del perfil
            this.Controls.Add(this.lblPerfil);
            // Agrega la bienvenida (la última agregada queda más arriba con Dock Top)
            this.Controls.Add(this.lblBienvenida);
            // Fuente de toda la sección: Segoe UI de 9.75 puntos
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Nombre de la sección
            this.Name = "UcInicioGeneral";
            // Tamaño en [Diseño] (en el panel se estira con Dock Fill)
            this.Size = new System.Drawing.Size(980, 600);
            // Reanuda el acomodo de la tarjeta
            this.pnlTarjeta.ResumeLayout(false);
            // Reanuda el acomodo de la sección
            this.ResumeLayout(false);

        }

        // Fin de la región del diseñador
        #endregion

        // Título grande "Bienvenido, <nombre>"
        private System.Windows.Forms.Label lblBienvenida;
        // Perfil del usuario
        private System.Windows.Forms.Label lblPerfil;
        // Tarjeta blanca
        private System.Windows.Forms.Panel pnlTarjeta;
        // Indicación "Usa el menú de la izquierda..."
        private System.Windows.Forms.Label lblIndicacion;
        // Texto "En construcción"
        private System.Windows.Forms.Label lblEnConstruccion;
    }
}
