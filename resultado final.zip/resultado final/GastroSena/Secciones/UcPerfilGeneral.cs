﻿// Archivo: Secciones/UcPerfilGeneral.cs
// Sección "Perfil" (UserControl) del instructor (el aprendiz usa UcPerfil, que ya está completo).
// Por ahora solo muestra su título grande y el texto "En construcción"; los controles están en UcPerfilGeneral.Designer.cs.

// Trae los controles de Windows Forms (UserControl)
using System.Windows.Forms;

// Espacio de nombres de las secciones (carpeta Secciones)
namespace GastroSena.Secciones
{
    /// <summary>
    /// Sección "Perfil" del instructor. FrmPanel la crea y la muestra en el área de contenido
    /// cuando se presiona el botón "Perfil" del menú lateral (btnPerfil).
    /// </summary>
    public partial class UcPerfilGeneral : UserControl
    {
        /// <summary>
        /// Constructor: se ejecuta cuando el panel crea la sección (new UcPerfilGeneral()).
        /// Llama a InitializeComponent para crear el título, la descripción y la tarjeta "En construcción".
        /// </summary>
        public UcPerfilGeneral()
        {
            // Crea los controles de la sección tal como se dibujaron en [Diseño]
            InitializeComponent();
        }
    }
}
