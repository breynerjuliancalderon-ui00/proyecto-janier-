﻿// Archivo: Secciones/UcInicio.cs
// Sección "Inicio" del aprendiz (UserControl): es lo primero que ve el aprendiz después de iniciar sesión.
// Muestra la bienvenida, la fecha de hoy, el menú del día con el botón "Reservar almuerzo",
// el resumen del mes (almuerzos, gasto y pendiente por pagar) y el horario del comedor.
// Los otros perfiles ven UcInicioGeneral. Los controles están en UcInicio.Designer.cs ([Diseño]).

// Trae DateTime, TimeSpan y EventArgs
using System;
// Trae los colores (Color) para pintar el botón habilitado o deshabilitado
using System.Drawing;
// Trae los controles de Windows Forms (UserControl, MessageBox)
using System.Windows.Forms;
// Trae AlmacenDatos (el menú de hoy y las reservas guardadas en datos.xml)
using GastroSena.Datos;
// Trae las clases Usuario, MenuDia, Reserva y EstadoPago
using GastroSena.Modelos;
// Trae Formato (pesos y fechas al estilo de Colombia)
using GastroSena.Utilidades;

// Espacio de nombres de las secciones (carpeta Secciones)
namespace GastroSena.Secciones
{
    /// <summary>
    /// Sección de inicio del aprendiz. FrmPanel la crea al abrir y cada vez que se presiona "Inicio",
    /// y luego llama a CargarDatos para llenar la bienvenida, el menú y el resumen.
    /// </summary>
    public partial class UcInicio : UserControl
    {
        // Hora desde la que se reciben reservas: 7:00 a. m.
        private static readonly TimeSpan horaApertura = new TimeSpan(7, 0, 0);
        // Hora en la que se dejan de recibir reservas: 9:00 p. m. (21:00)
        private static readonly TimeSpan horaCierre = new TimeSpan(21, 0, 0);
        // Verde SENA (#39A900): color del botón cuando se puede reservar
        private readonly Color verdeSena = Color.FromArgb(57, 169, 0);
        // Gris claro: color del botón cuando está deshabilitado
        private readonly Color grisDeshabilitado = Color.FromArgb(214, 221, 209);

        /// <summary>
        /// Constructor: se ejecuta cuando el panel crea la sección (new UcInicio()).
        /// Llama a InitializeComponent para crear las tarjetas dibujadas en el diseñador.
        /// </summary>
        public UcInicio()
        {
            // Crea los controles de la sección tal como se dibujaron en [Diseño]
            InitializeComponent();
        }

        /// <summary>
        /// Llena la sección con los datos del aprendiz: bienvenida, fecha, menú del día,
        /// resumen del mes y el estado del botón "Reservar almuerzo".
        /// </summary>
        /// <param name="usuario">El aprendiz que inició sesión.</param>
        public void CargarDatos(Usuario usuario)
        {
            // Escribe el saludo con el nombre completo (+ une textos)
            lblBienvenida.Text = "Bienvenido, " + usuario.NombreCompleto;
            // Escribe la fecha de hoy, por ejemplo "Viernes, 13 de noviembre de 2026"
            lblFecha.Text = Formato.FechaLarga(DateTime.Today);
            // Muestra los datos del menú de hoy
            MostrarMenu();
            // Calcula y muestra las tres tarjetas del resumen
            MostrarResumen();
            // Deja el botón habilitado o deshabilitado según corresponda
            ActualizarBotonReservar();
        }

        /// <summary>
        /// Escribe en la tarjeta "Menú del día" el nombre, la descripción, el precio y los cupos.
        /// </summary>
        private void MostrarMenu()
        {
            // Toma el menú de hoy guardado en datos.xml
            MenuDia menu = AlmacenDatos.MenuDelDia;
            // Escribe el nombre del menú
            lblMenuNombre.Text = menu.Nombre;
            // Escribe qué trae el almuerzo
            lblMenuDescripcion.Text = menu.Descripcion;
            // Escribe el precio, por ejemplo "$5.000"
            lblPrecio.Text = Formato.Pesos(menu.Precio);
            // Si ya no quedan cupos...
            if (menu.CuposDisponibles <= 0)
            {
                // ...lo dice así
                lblCupos.Text = "Sin cupos disponibles";
            }
            // Si queda uno solo...
            else if (menu.CuposDisponibles == 1)
            {
                // ...lo escribe en singular
                lblCupos.Text = "1 cupo disponible";
            }
            // Si quedan varios...
            else
            {
                // ...escribe cuántos, por ejemplo "150 cupos disponibles"
                lblCupos.Text = menu.CuposDisponibles + " cupos disponibles";
            }
        }

        /// <summary>
        /// Calcula y muestra las tarjetas pequeñas: almuerzos de este mes, lo que suman
        /// esos almuerzos (gasto del mes) y todo lo que falta por pagar.
        /// </summary>
        private void MostrarResumen()
        {
            // Contador de almuerzos de este mes (empieza en cero)
            int almuerzosMes = 0;
            // Suma de lo que valen los almuerzos de este mes
            decimal gastoMes = 0;
            // Suma de lo que falta por pagar (de cualquier mes)
            decimal pendientePorPagar = 0;
            // Fecha de hoy, para comparar el mes y el año
            DateTime hoy = DateTime.Today;
            // Recorre todas las reservas del aprendiz
            foreach (Reserva reserva in AlmacenDatos.ObtenerReservas())
            {
                // Si la reserva es de este mes y de este año...
                if (reserva.Fecha.Month == hoy.Month && reserva.Fecha.Year == hoy.Year)
                {
                    // ...suma un almuerzo
                    almuerzosMes = almuerzosMes + 1;
                    // ...y suma su precio al gasto del mes
                    gastoMes = gastoMes + reserva.Precio;
                }
                // Si la reserva todavía no se ha pagado...
                if (reserva.EstadoPago == EstadoPago.Pendiente)
                {
                    // ...suma su precio a lo pendiente
                    pendientePorPagar = pendientePorPagar + reserva.Precio;
                }
            }
            // Muestra el número de almuerzos del mes
            lblAlmuerzosMes.Text = almuerzosMes.ToString();
            // Muestra el gasto del mes en pesos
            lblGastoMes.Text = Formato.Pesos(gastoMes);
            // Muestra lo pendiente por pagar en pesos
            lblPendiente.Text = Formato.Pesos(pendientePorPagar);
        }

        /// <summary>
        /// Revisa si la hora actual está dentro del horario de reservas (7:00 a. m. a 9:00 p. m.).
        /// </summary>
        /// <returns>true si se puede reservar a esta hora; false si no.</returns>
        private bool EstaEnHorario()
        {
            // Toma la hora de este momento (sin la fecha)
            TimeSpan ahora = DateTime.Now.TimeOfDay;
            // Está en horario si ya son las 7:00 a. m. o más, y todavía no son las 9:00 p. m.
            return ahora >= horaApertura && ahora < horaCierre;
        }

        /// <summary>
        /// Habilita o deshabilita el botón "Reservar almuerzo" y escribe el aviso de debajo:
        /// si ya reservó hoy, si está fuera del horario, si no quedan cupos, o si puede reservar.
        /// </summary>
        private void ActualizarBotonReservar()
        {
            // Caso 1: ya reservó hoy
            if (AlmacenDatos.ReservoHoy())
            {
                // Deshabilita el botón
                btnReservar.Enabled = false;
                // Cambia el texto del botón
                btnReservar.Text = "Ya reservaste tu almuerzo de hoy";
                // Recuerda cómo se paga
                lblAvisoReserva.Text = "Pendiente de pago: págala en la ventanilla del comedor.";
            }
            // Caso 2: está fuera del horario de reservas
            else if (!EstaEnHorario())
            {
                // Deshabilita el botón
                btnReservar.Enabled = false;
                // Deja el texto normal del botón
                btnReservar.Text = "Reservar almuerzo";
                // Explica el horario
                lblAvisoReserva.Text = "Las reservas solo se reciben de 7:00 a. m. a 9:00 p. m.";
            }
            // Caso 3: no quedan cupos
            else if (AlmacenDatos.MenuDelDia.CuposDisponibles <= 0)
            {
                // Deshabilita el botón
                btnReservar.Enabled = false;
                // Deja el texto normal del botón
                btnReservar.Text = "Reservar almuerzo";
                // Explica por qué no se puede
                lblAvisoReserva.Text = "Ya no quedan cupos para hoy.";
            }
            // Caso 4: sí puede reservar
            else
            {
                // Habilita el botón
                btnReservar.Enabled = true;
                // Deja el texto normal del botón
                btnReservar.Text = "Reservar almuerzo";
                // Recuerda cómo se paga
                lblAvisoReserva.Text = "Lo pagas en la ventanilla del comedor.";
            }
            // Si el botón quedó habilitado...
            if (btnReservar.Enabled)
            {
                // ...se pinta de verde SENA
                btnReservar.BackColor = verdeSena;
            }
            // Si quedó deshabilitado...
            else
            {
                // ...se pinta de gris
                btnReservar.BackColor = grisDeshabilitado;
            }
        }

        /// <summary>
        /// Clic en "Reservar almuerzo": pide confirmación mostrando el precio y, si el aprendiz
        /// dice que sí, guarda la reserva como "Pendiente de pago" y actualiza la pantalla.
        /// </summary>
        /// <param name="sender">El botón Reservar almuerzo.</param>
        /// <param name="e">Datos del evento (aquí no se usan).</param>
        private void btnReservar_Click(object sender, EventArgs e)
        {
            // Si se pasó la hora mientras la pantalla estaba abierta...
            if (!EstaEnHorario())
            {
                // ...deshabilita el botón y escribe el aviso
                ActualizarBotonReservar();
                // ...avisa con una ventanita
                MessageBox.Show("Las reservas solo se reciben de 7:00 a. m. a 9:00 p. m.", "GastroSENA", MessageBoxButtons.OK, MessageBoxIcon.Information);
                // ...y no reserva
                return;
            }
            // Toma el menú de hoy
            MenuDia menu = AlmacenDatos.MenuDelDia;
            // Arma la pregunta con el nombre y el precio del menú ("\n" = salto de línea)
            string pregunta = "¿Deseas reservar el " + menu.Nombre + " por " + Formato.Pesos(menu.Precio) + "?\n\nLo pagas en la ventanilla del comedor.";
            // Muestra la pregunta con los botones Sí y No, y guarda cuál se presionó
            DialogResult respuesta = MessageBox.Show(pregunta, "Confirmar reserva", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            // Si no presionó "Sí"...
            if (respuesta != DialogResult.Yes)
            {
                // ...no hace nada más
                return;
            }
            // Guarda la reserva como "Pendiente" de pago (y descuenta un cupo)
            Reserva reserva = AlmacenDatos.ReservarAlmuerzo();
            // Vuelve a mostrar el menú (para que se vean los cupos nuevos)
            MostrarMenu();
            // Vuelve a calcular el resumen (almuerzos, gasto y pendiente)
            MostrarResumen();
            // Deshabilita el botón con el texto "Ya reservaste tu almuerzo de hoy"
            ActualizarBotonReservar();
            // Muestra el mensaje de confirmación
            MessageBox.Show("¡Almuerzo reservado!\n\nTu reserva quedó pendiente de pago por " + Formato.Pesos(reserva.Precio) + ". Págala en la ventanilla del comedor y presenta tu documento o ficha al ingresar.", "GastroSENA", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
