﻿// Archivo: Secciones/UcMiCuenta.cs
// Sección "Mi Cuenta" (UserControl). La ve el instructor.
// Por ahora solo muestra su título grande y el texto "En construcción"; los controles están en UcMiCuenta.Designer.cs.

// Trae los controles de Windows Forms (UserControl)
using System.Windows.Forms;

// Espacio de nombres de las secciones (carpeta Secciones)
namespace GastroSena.Secciones
{
    /// <summary>
    /// Sección "Mi Cuenta". FrmPanel la crea y la muestra en el área de contenido
    /// cuando se presiona el botón "Mi Cuenta" del menú lateral (btnMiCuenta).
    /// </summary>
    public partial class UcMiCuenta : UserControl
    {
        /// <summary>
        /// Constructor: se ejecuta cuando el panel crea la sección (new UcMiCuenta()).
        /// Llama a InitializeComponent para crear el título, la descripción y la tarjeta "En construcción".
        /// </summary>
        public UcMiCuenta()
        {
            // Crea los controles de la sección tal como se dibujaron en [Diseño]
            InitializeComponent();
        }
    }
}
