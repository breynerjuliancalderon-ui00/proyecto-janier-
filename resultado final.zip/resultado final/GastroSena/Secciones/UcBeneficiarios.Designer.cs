﻿// Visual Studio regenera este archivo cuando se edita en [Diseño], y los comentarios de adentro se pueden borrar.
// Archivo: Secciones/UcBeneficiarios.Designer.cs
// Parte "de diseño" de la sección "Beneficiarios": aquí se crean el título grande, la descripción
// y la tarjeta blanca con el texto "En construcción". Para cambiarla, abre UcBeneficiarios.cs en la vista [Diseño].

// Espacio de nombres de las secciones (carpeta Secciones)
namespace GastroSena.Secciones
{
    /// <summary>
    /// Segunda parte (partial) de la clase UcBeneficiarios: contiene el código que escribe el diseñador.
    /// </summary>
    partial class UcBeneficiarios
    {
        /// <summary>
        /// Variable del diseñador necesaria: guarda los componentes que hay que liberar al cerrar.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpia los recursos que se estén usando. Se ejecuta cuando la sección se cambia por otra.
        /// </summary>
        /// <param name="disposing">true si se deben liberar los recursos administrados; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            // Si se están liberando recursos y hay componentes guardados...
            if (disposing && (components != null))
            {
                // ...los libera
                components.Dispose();
            }
            // Llama al Dispose de la clase base (UserControl) para que termine de limpiar
            base.Dispose(disposing);
        }

        // Región con el código que escribe el Diseñador de componentes
        #region Código generado por el Diseñador de componentes

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// Crea los controles de la sección, les pone sus propiedades y los agrega.
        /// </summary>
        private void InitializeComponent()
        {
            // Crea la etiqueta del título grande
            this.lblTitulo = new System.Windows.Forms.Label();
            // Crea la etiqueta de la descripción
            this.lblDescripcion = new System.Windows.Forms.Label();
            // Crea la tarjeta blanca
            this.pnlTarjeta = new System.Windows.Forms.Panel();
            // Crea la etiqueta "En construcción"
            this.lblEnConstruccion = new System.Windows.Forms.Label();
            // Pausa el acomodo de la tarjeta mientras se configura
            this.pnlTarjeta.SuspendLayout();
            // Pausa el acomodo de la sección mientras se configura
            this.SuspendLayout();
            //
            // lblTitulo
            // Título grande "Beneficiarios": arriba de todo, Segoe UI de 20 puntos en negrita.
            //
            // Pegada arriba, ocupando todo el ancho
            this.lblTitulo.Dock = System.Windows.Forms.DockStyle.Top;
            // Letra Segoe UI de 20 puntos en negrita
            this.lblTitulo.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Color casi negro
            this.lblTitulo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(41)))), ((int)(((byte)(51)))));
            // Posición: arriba a la izquierda
            this.lblTitulo.Location = new System.Drawing.Point(0, 0);
            // Nombre del control
            this.lblTitulo.Name = "lblTitulo";
            // Tamaño: todo el ancho y 48 de alto
            this.lblTitulo.Size = new System.Drawing.Size(980, 48);
            // Orden de tabulación
            this.lblTitulo.TabIndex = 0;
            // Texto que se muestra
            this.lblTitulo.Text = "Beneficiarios";
            // Texto alineado a la izquierda y centrado de arriba a abajo
            this.lblTitulo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            //
            // lblDescripcion
            // Descripción gris de para qué servirá la sección, debajo del título.
            //
            // Pegada arriba, debajo del título
            this.lblDescripcion.Dock = System.Windows.Forms.DockStyle.Top;
            // Letra Segoe UI de 11 puntos
            this.lblDescripcion.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Color gris
            this.lblDescripcion.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(114)))), ((int)(((byte)(128)))));
            // Posición: debajo del título
            this.lblDescripcion.Location = new System.Drawing.Point(0, 48);
            // Nombre del control
            this.lblDescripcion.Name = "lblDescripcion";
            // Tamaño: todo el ancho; el alto deja un espacio antes de la tarjeta
            this.lblDescripcion.Size = new System.Drawing.Size(980, 44);
            // Orden de tabulación
            this.lblDescripcion.TabIndex = 1;
            // Texto que se muestra
            this.lblDescripcion.Text = "Aquí se administrarán los aprendices que reciben el almuerzo subsidiado.";
            //
            // pnlTarjeta
            // Tarjeta blanca que ocupa el resto del espacio.
            //
            // Fondo blanco
            this.pnlTarjeta.BackColor = System.Drawing.Color.White;
            // Agrega "En construcción" dentro de la tarjeta
            this.pnlTarjeta.Controls.Add(this.lblEnConstruccion);
            // Ocupa todo el espacio que sobra debajo de las etiquetas
            this.pnlTarjeta.Dock = System.Windows.Forms.DockStyle.Fill;
            // Posición: debajo de la descripción
            this.pnlTarjeta.Location = new System.Drawing.Point(0, 92);
            // Nombre del control
            this.pnlTarjeta.Name = "pnlTarjeta";
            // Margen interior de 24 píxeles
            this.pnlTarjeta.Padding = new System.Windows.Forms.Padding(24);
            // Tamaño (lo calcula el Dock)
            this.pnlTarjeta.Size = new System.Drawing.Size(980, 508);
            // Orden de tabulación
            this.pnlTarjeta.TabIndex = 2;
            //
            // lblEnConstruccion
            // Texto "En construcción" centrado en la tarjeta.
            //
            // Ocupa toda la tarjeta
            this.lblEnConstruccion.Dock = System.Windows.Forms.DockStyle.Fill;
            // Letra Segoe UI de 15.75 puntos
            this.lblEnConstruccion.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Color gris
            this.lblEnConstruccion.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(114)))), ((int)(((byte)(128)))));
            // Posición: dentro del margen de la tarjeta
            this.lblEnConstruccion.Location = new System.Drawing.Point(24, 24);
            // Nombre del control
            this.lblEnConstruccion.Name = "lblEnConstruccion";
            // Tamaño (lo calcula el Dock)
            this.lblEnConstruccion.Size = new System.Drawing.Size(932, 460);
            // Orden de tabulación
            this.lblEnConstruccion.TabIndex = 0;
            // Texto que se muestra
            this.lblEnConstruccion.Text = "En construcción";
            // Texto centrado a lo ancho y a lo alto
            this.lblEnConstruccion.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            //
            // UcBeneficiarios
            // La sección completa: fondo gris muy claro, igual al área de contenido del panel.
            //
            // Tamaño de letra con el que se diseñó (sirve para escalar si cambia la fuente o el DPI)
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            // Escala los controles según la fuente
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            // Fondo gris muy claro
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(245)))), ((int)(((byte)(241)))));
            // Agrega la tarjeta (se agrega primero para que el Dock Fill se acomode al final)
            this.Controls.Add(this.pnlTarjeta);
            // Agrega la descripción
            this.Controls.Add(this.lblDescripcion);
            // Agrega el título (el último agregado queda más arriba con Dock Top)
            this.Controls.Add(this.lblTitulo);
            // Fuente de toda la sección: Segoe UI de 9.75 puntos
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // Nombre de la sección
            this.Name = "UcBeneficiarios";
            // Tamaño en [Diseño] (en el panel se estira con Dock Fill)
            this.Size = new System.Drawing.Size(980, 600);
            // Reanuda el acomodo de la tarjeta
            this.pnlTarjeta.ResumeLayout(false);
            // Reanuda el acomodo de la sección
            this.ResumeLayout(false);

        }

        // Fin de la región del diseñador
        #endregion

        // Título grande de la sección
        private System.Windows.Forms.Label lblTitulo;
        // Descripción de la sección
        private System.Windows.Forms.Label lblDescripcion;
        // Tarjeta blanca
        private System.Windows.Forms.Panel pnlTarjeta;
        // Texto "En construcción"
        private System.Windows.Forms.Label lblEnConstruccion;
    }
}
