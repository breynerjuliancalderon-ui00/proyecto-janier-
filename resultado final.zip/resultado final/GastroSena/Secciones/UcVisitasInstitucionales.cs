﻿// Archivo: Secciones/UcVisitasInstitucionales.cs
// Sección "Visitas Institucionales" (UserControl). La ve el encargado.
// Por ahora solo muestra su título grande y el texto "En construcción"; los controles están en UcVisitasInstitucionales.Designer.cs.

// Trae los controles de Windows Forms (UserControl)
using System.Windows.Forms;

// Espacio de nombres de las secciones (carpeta Secciones)
namespace GastroSena.Secciones
{
    /// <summary>
    /// Sección "Visitas Institucionales". FrmPanel la crea y la muestra en el área de contenido
    /// cuando se presiona el botón "Visitas Institucionales" del menú lateral (btnVisitasInstitucionales).
    /// </summary>
    public partial class UcVisitasInstitucionales : UserControl
    {
        /// <summary>
        /// Constructor: se ejecuta cuando el panel crea la sección (new UcVisitasInstitucionales()).
        /// Llama a InitializeComponent para crear el título, la descripción y la tarjeta "En construcción".
        /// </summary>
        public UcVisitasInstitucionales()
        {
            // Crea los controles de la sección tal como se dibujaron en [Diseño]
            InitializeComponent();
        }
    }
}
