﻿// Archivo: Secciones/UcConsumos.cs
// Sección "Consumos" (UserControl). La ve el instructor.
// Por ahora solo muestra su título grande y el texto "En construcción"; los controles están en UcConsumos.Designer.cs.

// Trae los controles de Windows Forms (UserControl)
using System.Windows.Forms;

// Espacio de nombres de las secciones (carpeta Secciones)
namespace GastroSena.Secciones
{
    /// <summary>
    /// Sección "Consumos". FrmPanel la crea y la muestra en el área de contenido
    /// cuando se presiona el botón "Consumos" del menú lateral (btnConsumos).
    /// </summary>
    public partial class UcConsumos : UserControl
    {
        /// <summary>
        /// Constructor: se ejecuta cuando el panel crea la sección (new UcConsumos()).
        /// Llama a InitializeComponent para crear el título, la descripción y la tarjeta "En construcción".
        /// </summary>
        public UcConsumos()
        {
            // Crea los controles de la sección tal como se dibujaron en [Diseño]
            InitializeComponent();
        }
    }
}
