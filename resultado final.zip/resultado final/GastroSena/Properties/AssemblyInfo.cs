﻿// Archivo: Properties/AssemblyInfo.cs
// Información del ensamblado (el archivo GastroSena.exe): nombre, descripción, versión, etc.
// Windows muestra estos datos en Propiedades > Detalles del .exe. No cambia cómo funciona el programa.

// Trae los atributos de ensamblado (AssemblyTitle, AssemblyVersion...)
using System.Reflection;
// Trae atributos que usa el compilador
using System.Runtime.CompilerServices;
// Trae los atributos para trabajar con COM (ComVisible, Guid)
using System.Runtime.InteropServices;

// Título del programa
[assembly: AssemblyTitle("GastroSENA")]
// Descripción corta del programa
[assembly: AssemblyDescription("Sistema de almuerzos - SENA Yamboró")]
// Configuración de compilación (se deja vacía)
[assembly: AssemblyConfiguration("")]
// Empresa o institución dueña del programa
[assembly: AssemblyCompany("SENA")]
// Nombre del producto
[assembly: AssemblyProduct("GastroSENA")]
// Derechos de autor
[assembly: AssemblyCopyright("Copyright © SENA 2026")]
// Marca registrada (se deja vacía)
[assembly: AssemblyTrademark("")]
// Idioma del ensamblado (vacío = idioma neutro)
[assembly: AssemblyCulture("")]

// false = las clases de este programa no se ofrecen a otros programas antiguos (COM)
[assembly: ComVisible(false)]

// Identificador único del ensamblado (solo se usa si algún día se expone a COM)
[assembly: Guid("931fbb60-3f2b-4026-87de-2e58e95cb4c1")]

// Versión del ensamblado: principal.secundaria.compilación.revisión
[assembly: AssemblyVersion("1.0.0.0")]
// Versión del archivo que muestra Windows en las propiedades del .exe
[assembly: AssemblyFileVersion("1.0.0.0")]
