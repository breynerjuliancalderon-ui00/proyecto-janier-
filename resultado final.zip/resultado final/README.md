# GastroSENA

Sistema de almuerzos del SENA Yamboró hecho en **Windows Forms (C#, .NET Framework 4.8)**.
Por ahora es solo la interfaz (frontend): no usa base de datos. El perfil **Aprendiz** ya está completo
y guarda sus datos en un archivo XML; los demás perfiles todavía muestran sus secciones "En construcción".

## Cómo abrirlo

1. Doble clic en `GastroSena.sln` (se abre en Visual Studio 2026).
2. Presiona **F5**: aparece el formulario de inicio de sesión.

Para editar una pantalla, haz doble clic en su archivo `.cs` en el Explorador de soluciones: se abre en la vista **[Diseño]**.
Cada formulario y cada sección tiene tres archivos: `.cs` (la lógica, en los eventos), `.Designer.cs` (lo que escribe el diseñador) y `.resx` (los recursos).

## Usuarios de demostración

Todos usan la contraseña `demo123`. Al elegir el perfil en el login, el usuario y la contraseña se llenan solos.

| Perfil | Usuario (documento) | Nombre |
|---|---|---|
| Aprendiz | `1005678901` | Carlos Ruiz (ficha 2847251, programa ADSO) |
| Instructor | `1098765432` | María Fernanda Gómez |
| Encargado | `1012345678` | Encargado General Comedor |
| Invitado | `1234567890` | Invitado Particular |

## Perfil Aprendiz

| Pantalla | Qué hace |
|---|---|
| **Inicio** (`UcInicio`) | Muestra "Bienvenido, &lt;nombre&gt;" y la fecha de hoy en español. La tarjeta **Menú del día** tiene la foto, el nombre, la descripción, el precio ($5.000) y los cupos disponibles. El botón **Reservar almuerzo** pide confirmación (Sí/No, con el precio) y guarda la reserva como *Pendiente de pago*. Si ya reservó hoy, el botón queda deshabilitado con el texto "Ya reservaste tu almuerzo de hoy". Solo se puede reservar de **7:00 a. m. a 9:00 p. m.**; fuera de ese horario el botón queda deshabilitado y debajo aparece el aviso. Tiene tres tarjetas (*Almuerzos este mes*, *Gasto del mes* y *Pendiente por pagar*) que se actualizan al reservar, y un recuadro con el horario del comedor. |
| **Mis Fichas** (`UcMisFichas`) | Tabla de solo lectura con todas las reservas, de la más reciente a la más antigua: Fecha, Menú, Precio, Estado de pago (Pagado en verde, Pendiente en amarillo, Gratis en azul) y Estado (*Reservado* si es de hoy, *Consumido* si ya pasó). Debajo: total de almuerzos, total pagado y total pendiente. Se vuelve a leer cada vez que se abre, así que muestra enseguida la reserva hecha en Inicio. |
| **Buzón de Sugerencias** (`UcBuzonSugerencias`) | Formulario con **Asunto** (de 3 a 150 caracteres) y **Mensaje** (de 10 a 2000, con contador). Los errores se marcan con un ícono rojo (ErrorProvider) junto al campo; al pasar el mouse por el ícono se lee el mensaje. **Enviar sugerencia** la guarda como *Pendiente*, limpia el formulario y muestra una confirmación. Debajo, **Mis sugerencias**: Fecha, Asunto, Estado (Pendiente o Atendida) y Respuesta del comedor. |
| **Perfil** (`UcPerfil`) | Muestra Nombre, Documento, Correo, Ficha, Programa y Perfil. **Editar** habilita Nombre, Correo y Ficha; **Guardar cambios** revisa que el nombre no esté vacío y que el correo sea válido, guarda y avisa (el nombre también cambia en el encabezado del panel); **Cancelar** deshace los cambios. |

### Dónde se guardan los datos

Los datos del aprendiz (perfil, menú de hoy, reservas y sugerencias) se guardan con `XmlSerializer` en:

```
%LOCALAPPDATA%\GastroSena\datos.xml
```

(por ejemplo `C:\Users\<tu usuario>\AppData\Local\GastroSena\datos.xml`). Así no se pierden al cerrar la aplicación.
Si el archivo no existe, se crea solo con los datos de demostración: el menú de hoy, las reservas de los 4 días
anteriores y 2 sugerencias (una pendiente y otra atendida con respuesta). Cada día nuevo el menú se cambia por el de ese día.
**Para volver a empezar con los datos de demostración, cierra la aplicación y borra `datos.xml`.**

## Dónde está cada pantalla

Las secciones que terminan en **General** son la versión que ven, por ahora, los perfiles que no son Aprendiz
(la misma pantalla que tenían antes).

| Pantalla | Archivo | La ven |
|---|---|---|
| Inicio de sesión | `GastroSena/Formularios/FrmLogin.cs` | todos |
| Panel principal (menú, encabezado y contenido) | `GastroSena/Formularios/FrmPanel.cs` | todos |
| Inicio | `GastroSena/Secciones/UcInicio.cs` | Aprendiz |
| Inicio (bienvenida) | `GastroSena/Secciones/UcInicioGeneral.cs` | Instructor, Encargado e Invitado |
| Mis Fichas | `GastroSena/Secciones/UcMisFichas.cs` | Aprendiz |
| Mi Cuenta | `GastroSena/Secciones/UcMiCuenta.cs` | Instructor |
| Consumos | `GastroSena/Secciones/UcConsumos.cs` | Instructor |
| Ventas | `GastroSena/Secciones/UcVentas.cs` | Encargado |
| Menú del Día | `GastroSena/Secciones/UcMenuDelDia.cs` | Encargado |
| Beneficiarios | `GastroSena/Secciones/UcBeneficiarios.cs` | Encargado |
| Cartera de Deudas | `GastroSena/Secciones/UcCarteraDeudas.cs` | Encargado |
| Inventario | `GastroSena/Secciones/UcInventario.cs` | Encargado |
| Grupos | `GastroSena/Secciones/UcGrupos.cs` | Encargado |
| Visitas Institucionales | `GastroSena/Secciones/UcVisitasInstitucionales.cs` | Encargado |
| Solicitudes de Cuenta | `GastroSena/Secciones/UcSolicitudesCuenta.cs` | Encargado |
| Buzón de Sugerencias | `GastroSena/Secciones/UcBuzonSugerencias.cs` | Aprendiz |
| Buzón de Sugerencias (en construcción) | `GastroSena/Secciones/UcBuzonSugerenciasGeneral.cs` | Instructor, Encargado e Invitado |
| Perfil | `GastroSena/Secciones/UcPerfil.cs` | Aprendiz |
| Perfil (en construcción) | `GastroSena/Secciones/UcPerfilGeneral.cs` | Instructor |

## Otros archivos

- `GastroSena/Program.cs`: punto de entrada; abre el login.
- `GastroSena/Modelos/`: los modelos. `Usuario.cs` y `Rol.cs` (usuarios y perfiles); `MenuDia.cs`, `Reserva.cs` y `Sugerencia.cs` (lo que usa el aprendiz); `EstadoPago.cs` y `EstadoSugerencia.cs` (los estados posibles); `DatosAprendiz.cs` (todo lo que se guarda en `datos.xml`).
- `GastroSena/Datos/UsuariosDemo.cs`: los usuarios de demostración.
- `GastroSena/Datos/DatosDemoAprendiz.cs`: los datos de demostración del aprendiz (menú, reservas y sugerencias).
- `GastroSena/Datos/AlmacenDatos.cs`: lee y guarda `datos.xml` con `XmlSerializer`.
- `GastroSena/Utilidades/Formato.cs`: escribe pesos ("$5.000") y fechas en español.
- `GastroSena/Resources/`: `logo.png`, `cafeteria-bg.jpg` (también es la foto del menú del día) y `gastrosena.ico` (el ícono de las ventanas). Las imágenes se usan desde **Properties > Resources**.
